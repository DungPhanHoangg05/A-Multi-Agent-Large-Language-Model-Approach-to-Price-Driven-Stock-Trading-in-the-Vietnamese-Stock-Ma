"""Oracle độc lập counts/Beta CDF/loss/nhãn/scaler trên artifact cuối, không API."""
from pathlib import Path
import hashlib,json,math,sys
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
import numpy as np
import pandas as pd
from scipy.special import betainc
from core.backtest_engine import compute_round_trip_net_return
from core.execution_prices import execution_prices_for_cycle,load_verified_execution_data
from core.research_cohort import read_envelope

root=Path.cwd(); qa=Path(__file__).parent; namespace=root/'outputs/bayesian_benchmark/bic_icl_v2'
memory=read_envelope(namespace/'memory_v1/memory.json')
index=read_envelope(namespace/'memory_v1/index.json')
report=read_envelope(namespace/'train_v1/diagnostics.json')
bank=json.loads((root/'data_manager/regime_memory_store.json').read_text(encoding='utf8'))
historical=json.loads((root/'outputs/historical_memory_run/run_manifest.json').read_text(encoding='utf8'))['payload']
bank_manifest=json.loads((root/'data_manager/regime_memory_store.manifest.json').read_text(encoding='utf8'))
for phase in ('development','holdout'):
    plan=read_envelope(root/f'outputs/bayesian_benchmark/improvement_v1/{phase}/plan.json')
    assert plan['inputs']['signal_config']==historical['signal_config']
    assert plan['inputs']['signal_config']['models']==bank_manifest['models']
assert len(bank)==852 and memory['imported_count']==124 and memory['excluded_count']==0
assert len(memory['records'])==976 and len(index['records'])==976
assert len({(r['symbol'],r['as_of_date']) for r in memory['records']})==976
by_id={r['episode_id']:r for r in memory['records']}
assert all(by_id[r['episode_id']]==r for r in bank)
prices={s:load_verified_execution_data(root/'data/execution_prices_oos',s) for s in ('FPT','MWG','VCB','VNM')}
for record in memory['records']:
    if record['as_of_date']<'2023-01-01':continue
    proof=memory['record_provenance'][record['episode_id']]
    source=read_envelope(root/proof['point_path'])
    assert source['full_bundle']['current_signals']==record['agent_signals']
    assert source['full_bundle']['market_regime']['regime_name']==record['regime']
    frame,events=prices[record['symbol']]
    entry,close=execution_prices_for_cycle(frame,events,*[record[k] for k in ('as_of_date','entry_date','exit_date')])
    net=float(compute_round_trip_net_return(entry,close)*100)
    assert net==record['outcome']['net_return_pct']
    assert record['exit_date']<='2024-12-31'
legacy=read_envelope(root/'outputs/bayesian_benchmark/price_features/candidate_index_v1.json')
for f in ('train_2021','train_2022','oos_2023_2024'):
    assert legacy['scalers'][f]==index['scalers'][f]
assert index['scalers']['confirmation_2025']==legacy['scalers']['oos_2023_2024']
assert all('outcome' not in r and r['features']['feature_end_date']<=r['as_of_date']
           for r in index['records'] if r['features']['feature_end_date'] is not None)
feature_checks=0
for row in index['records']:
    if row['as_of_date']<'2023-01-01' or row['features']['status']!='AVAILABLE':continue
    frame,_=prices[row['symbol']]
    close=frame.loc[frame.Datetime<=pd.Timestamp(row['as_of_date']),'Close'].tail(21).to_numpy()
    assert len(close)==21
    returns=np.diff(np.log(close))
    expected=[close[-1]/close[-6]-1,close[-1]/close[0]-1,float(np.std(returns,ddof=0)),close[-1]/close[-20:].mean()-1]
    assert np.allclose(row['features']['vector'],expected,atol=1e-14,rtol=1e-12),(row['episode_id'],expected,row['features']['vector'])
    feature_checks+=1
assert len(report['points'])==651
assert len(report['regime_fits'])==166
assert len(report['regime_fits'])==len({r['as_of_date'] for r in report['points']})
checked=0; errors=[]
for row in report['points']:
    for strength in (2,4,8):
        actual=row['pooled'][str(strength)]
        q=actual['query']; groups={'C':[],'B1':[],'B2':[]}
        for record in bank:
            if record['symbol']!=q['symbol'] or record['exit_date']>=q['as_of_date']:continue
            key='B2' if record['regime']!=q['current_regime'] else 'C' if (
                record['agent_signals']['trend']==q['current_signals']['trend'] and
                record['agent_signals']['pattern']==q['current_signals']['pattern']) else 'B1'
            groups[key].append(record)
        counts={k:{'s':sum(r['outcome']['net_return_pct']>0 for r in group),'n':len(group)} for k,group in groups.items()}
        assert actual['counts']==counts
        assert all(actual['groups'][k]['episode_ids']==sorted(r['episode_id'] for r in group) for k,group in groups.items())
        c,b1,b2=[counts[k] for k in ('C','B1','B2')]
        m2=(b2['s']+1)/(b2['n']+2); m1=(b1['s']+strength*m2)/(b1['n']+strength)
        a=c['s']+strength*m1; b=c['n']-c['s']+strength*(1-m1)
        assert math.isclose(actual['posterior_mean'],a/(a+b),rel_tol=0,abs_tol=1e-15)
        lower,upper=[actual['credible_interval'][k] for k in ('lower','upper')]
        errors.extend([abs(betainc(a,b,lower)-.025),abs(betainc(a,b,upper)-.975)])
        assert actual['ready']==(c['n']>=5 and b1['n']+b2['n']>=20 and upper-lower<=.75)
        checked+=1
common=[r for r in report['points'] if all(r['probability'][n] is not None for n in ('A','R2','R4','R8'))]
assert [r['episode_id'] for r in common]==report['summary']['overall']['common_ids']
for name in ('A','R2','R4','R8'):
    p=np.asarray([r['probability'][name] for r in common]); y=np.asarray([r['label'] for r in common]); clipped=np.clip(p,1e-6,1-1e-6)
    expected={'log_loss':float(np.mean(-y*np.log(clipped)-(1-y)*np.log(1-clipped))),'brier':float(np.mean((p-y)**2))}
    assert expected==report['summary']['overall']['loss'][name]
    bins=report['summary']['overall']['reliability_bins'][name]
    assert sum(b['count'] for b in bins)==len(common)
assert report['summary']['selected_lambda']==8
assert report['summary']['delta_loss_vs_A']['2']['log_loss']>0
assert max(errors)<1e-11
result={'status':'PASS','memory_records':976,'imported_upstream':124,'original_records':852,
        'posterior_checks':checked,'train_queries':651,'common_count':len(common),'max_beta_cdf_error':max(errors),
        'selected_lambda':8,'unfavorable_R2_preserved':True,'scalers_unchanged':True,
        'historical_and_refresh_signal_models_compatible':True,'refresh_feature_oracle_checks':feature_checks}
(qa/'oracle_result.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result))

"""Ghi log đúng bốn module mới, không dùng ca cũ thay kiểm thử task."""
from pathlib import Path
import sys, unittest
sys.path[:0]=[str(Path.cwd()/'tests'),str(Path.cwd())]
qa=Path(__file__).parent
names=['test_bic_icl_memory','test_bic_icl_memory_leakage','test_bic_icl_statistics','test_bic_icl_preparation']
with (qa/'targeted_final.log').open('w',encoding='utf8') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
print('Số ca mới:',result.testsRun,'PASS:',result.wasSuccessful(),flush=True)
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)

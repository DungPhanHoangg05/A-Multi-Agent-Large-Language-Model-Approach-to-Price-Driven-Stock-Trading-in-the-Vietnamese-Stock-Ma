"""Chạy CLI build/verify thật độc lập hai phần, giữ log và identity mỗi lượt."""
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,subprocess
from pathlib import Path

root=Path.cwd(); qa=Path(__file__).parent

def run(kind):
    destination=root/f'outputs/bayesian_benchmark/bic_icl_v2/{kind}_v1'
    args=['py','-3.13','-X','utf8','scripts/prepare_bic_icl_memory.py','--kind',kind,'--destination',str(destination)]
    codes=[]
    with (qa/f'cli_{kind}_build.log').open('wb') as stream:
        codes.append(subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT).returncode)
    if codes[-1]:return {'kind':kind,'codes':codes}
    before={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mtime':p.stat().st_mtime_ns} for p in destination.iterdir()}
    print('CLI build hoàn tất:',kind,flush=True)
    with (qa/f'cli_{kind}_verify.log').open('wb') as stream:
        codes.append(subprocess.run([*args,'--verify'],stdout=stream,stderr=subprocess.STDOUT).returncode)
    after={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mtime':p.stat().st_mtime_ns} for p in destination.iterdir()}
    print('CLI verify hoàn tất:',kind,codes,flush=True)
    return {'kind':kind,'codes':codes,'read_only':before==after,'artifacts':after}

with ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(run,['memory','train']))
(qa/'cli_acceptance.json').write_text(json.dumps(results,indent=2),encoding='utf8')
print(results,flush=True)
raise SystemExit(0 if all(r['codes']==[0,0] and r['read_only'] for r in results) else 1)

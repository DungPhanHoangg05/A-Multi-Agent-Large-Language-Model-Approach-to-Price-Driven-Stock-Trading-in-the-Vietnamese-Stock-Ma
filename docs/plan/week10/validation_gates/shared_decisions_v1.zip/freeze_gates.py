"""Đóng gói gate đã PASS và identity đúng code; không chứa lượt gate chưa hoàn tất."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

root=Path.cwd(); qa=Path(__file__).resolve().parent; gates=qa/'gates_final'
summary=json.loads((gates/'summary.json').read_text(encoding='utf-8'))
assert [g['gate'] for g in summary]==['compileall','unit','e2e','leakage']
assert all(g['exit_code']==0 for g in summary)
for name,count in [('unit',978),('leakage',204)]:
    gate=next(g for g in summary if g['gate']==name)
    assert gate['tests']==count and gate['skips']==0 and gate['discovery_multiset_matches']
    results=[json.loads(p.read_text(encoding='utf-8')) for p in gates.glob(f'{name}_*.result.json')]
    assert len(results)==gate['modules'] and sum(r['run'] for r in results)==count
    for r in results:
        assert r['success'] and r['run']==r['expected']
        assert all(r[k]==0 for k in ['failures','errors','skipped','expected_failures','unexpected_successes'])
    inventory=json.loads((gates/f'{name}_inventory.json').read_text(encoding='utf-8'))
    assert inventory['expected']==inventory['actual']
subprocess.run([sys.executable,'-X','utf8',str(qa/'check_integrity.py')],check=True)
sys.path.insert(0,str(root))
from core.research_input_lock import runtime_identity
(qa/'runtime_at_acceptance.json').write_text(json.dumps(runtime_identity(),indent=2),encoding='utf-8')
target=root/'docs/plan/week10/validation_gates/shared_decisions_v1.zip'
target.parent.mkdir(parents=True,exist_ok=True)
files={f'gates/{p.name}':p for p in gates.iterdir() if p.suffix in ('.json','.log')}
for name in ['module_worker.py','run_full_gates.py','check_integrity.py','freeze_gates.py',
             'baseline.json','integrity.json','runtime_at_acceptance.json','targeted_final.log']:
    files[name]=qa/name
with zipfile.ZipFile(target,'x') as archive:
    for name,path in sorted(files.items()):
        entry=zipfile.ZipInfo(name); entry.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(entry,path.read_bytes(),compresslevel=6)
with zipfile.ZipFile(target) as archive:
    assert len(archive.namelist())==len(files) and archive.testzip() is None
    assert all(archive.read(n)==p.read_bytes() for n,p in files.items())
receipt={'path':target.relative_to(root).as_posix(),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
         'entries':len(files),'bytes':target.stat().st_size,'unit':978,'leakage':204,'focused':32}
(qa/'gate_archive_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))

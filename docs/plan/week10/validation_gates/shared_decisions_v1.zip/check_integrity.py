"""Đối soát nguồn/bằng chứng cũ theo byte, code gate theo LF và liên kết mới."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

root=Path.cwd(); qa=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((qa/'baseline.json').read_text(encoding='utf-8'))
changed=[n for n,h in baseline.items() if not (root/n).is_file() or sha(root/n)!=h]
assert not changed,changed
gate=json.loads((qa/'gates_final/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((root/n).read_text(encoding='utf-8').encode()).hexdigest()==h for n,h in gate['files'].items())
assert hashlib.sha256((root/'docs/plan/week10/method_protocol_v1.md').read_text(encoding='utf-8').encode()).hexdigest()=='e9c8410bed048733d1ad3faa296a200409c91bfd8be72557d98639ecd8e8313b'
assert sha(root/'outputs/bayesian_benchmark/bic_icl_v2/input_audit_v2.json')=='9f1c2fed3a8955107ecb63f83da7651fd3a3f17c6e9a964c4ab5092d2c4a75f8'
assert sha(root/'outputs/bayesian_benchmark/improvement_v1/holdout/frozen_results_v1.zip')=='1db2024a3a338cadcf72692287471f8a14feba49ce8a1b1a488b951896cfec70'
for n in ['core/bic_icl_decisions.py','tests/bic_icl_fixture.py','tests/test_bic_icl_decisions.py','tests/test_bic_icl_decisions_leakage.py']:
    assert not re.search(r'[ \t]+$',(root/n).read_text(encoding='utf-8'),re.M),n
for n in ['docs/plan/plan.md','docs/plan/week10/README.md']:
    path=root/n
    for link in re.findall(r'(?<!!)\[[^\]]+\]\(([^\s)]+)\)',path.read_text(encoding='utf-8')):
        if ':' in link or link.startswith('#'):continue
        relative=link.split('#')[0]
        assert not relative or (path.parent/relative).exists(),(n,link)
subprocess.run(['git','diff','--check'],check=True)
result={'status':'PASS','old_files_unchanged':len(baseline),'code_identity_files':len(gate['files']),
        'normalization':'UTF8_LF','input_audit_and_method_unchanged':True,'w9_archive_unchanged':True,'links_valid':True}
(qa/'integrity.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))

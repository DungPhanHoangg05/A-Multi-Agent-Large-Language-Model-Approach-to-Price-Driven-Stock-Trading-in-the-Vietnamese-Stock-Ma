"""Worker giữ nguyên module/thứ tự test; stdout ổn định suốt process."""
import atexit
import json
import os
from pathlib import Path
import sys
import time
import unittest


def initialize(root: str, qa: str, name: str) -> None:
    """Chỉ đổi đường import cho worker kiểm thử, không đổi runtime ứng dụng."""
    sys.path[:0] = [str(Path(root)/'tests'), root]
    stream = (Path(qa)/f'{name}_worker_{os.getpid()}.log').open('w', encoding='utf-8', buffering=1)
    sys.stdout = sys.stderr = stream
    atexit.register(stream.flush)


def ids(suite):
    """Giữ bội số ID đã có trong discovery."""
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from ids(item)
        else:
            yield item.id()


def run_module(spec):
    """Chạy toàn module một lần, lưu inventory và kết quả trước khi trả parent."""
    qa, name, module = spec
    started = time.monotonic()
    suite = unittest.defaultTestLoader.loadTestsFromName(module)
    inventory = list(ids(suite))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    data = {'module': module, 'ids': inventory, 'expected': len(inventory), 'run': result.testsRun,
        'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
        'expected_failures': len(result.expectedFailures), 'unexpected_successes': len(result.unexpectedSuccesses),
        'elapsed_seconds': time.monotonic()-started}
    data['success'] = bool(result.wasSuccessful() and data['run']==data['expected'] and not result.skipped
                           and not result.expectedFailures and not result.unexpectedSuccesses)
    (Path(qa)/f'{name}_{module}.result.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
    return data

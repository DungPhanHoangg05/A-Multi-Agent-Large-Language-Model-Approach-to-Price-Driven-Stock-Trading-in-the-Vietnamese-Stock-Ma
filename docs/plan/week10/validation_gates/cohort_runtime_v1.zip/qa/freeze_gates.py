"""Chỉ đóng gói gate/CLI/oracle cuối; không đưa bằng chứng bản nháp vào nghiệm thu."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

root = Path.cwd()
qa = Path(__file__).parent
sys.path.insert(0, str(root))
from core.research_input_lock import runtime_identity

summary = json.loads((qa/'gates_final/summary.json').read_text('utf8'))
assert [r['gate'] for r in summary] == ['compileall', 'unit', 'e2e', 'leakage']
assert all(r['exit_code'] == 0 for r in summary)
assert summary[1]['tests'] == 1083 and summary[3]['tests'] == 235
assert summary[1]['modules'] == 137 and summary[3]['modules'] == 38
for suite in ('unit', 'leakage'):
    inventory = json.loads((qa/f'gates_final/{suite}_inventory.json').read_text('utf8'))
    assert inventory['actual'] == inventory['expected']
    for path in (qa/'gates_final').glob(f'{suite}_*.result.json'):
        result = json.loads(path.read_text('utf8'))
        assert result['success'] and result['run'] == result['expected']
        assert all(result[k] == 0 for k in ('failures', 'errors', 'skipped', 'expected_failures', 'unexpected_successes'))
acceptance = json.loads((qa/'cli_acceptance.json').read_text('utf8'))
assert acceptance['status'] == 'PASS' and acceptance['plan_read_only_after_prepare']
assert [r['exit_code'] for r in acceptance['commands']] == [0, 0, 0, 1]
plan = root/acceptance['plan']['path']
assert hashlib.sha256(plan.read_bytes()).hexdigest() == acceptance['plan']['sha256']
assert plan.stat().st_mtime_ns == acceptance['plan']['mtime']
oracle = json.loads((qa/'oracle_result.json').read_text('utf8'))
assert oracle['status'] == 'PASS' and oracle['points'] == 60
assert oracle['sdk_contract_checks'] == 480 and oracle['repeat_sample_checks'] == 12
assert oracle['coverage_insufficiency_preserved'] and oracle['llm_calls'] == 0
assert oracle['plan_sha256_raw'] == acceptance['plan']['sha256']
subprocess.run(['py', '-3.13', '-X', 'utf8', str(qa/'check_integrity.py')], check=True)
(qa/'runtime_at_acceptance.json').write_text(json.dumps(runtime_identity(), indent=2), encoding='utf8')
members = {f'qa/gates/{p.name}': p for p in (qa/'gates_final').iterdir() if p.is_file()}
for name in ('baseline.json', 'integrity.json', 'runtime_at_acceptance.json', 'cli_acceptance.json',
             'oracle_result.json', 'cohort_packets.json', 'cli_prepare.log', 'cli_dryrun.log', 'cli_fixture.log',
             'cli_unauthorized.log', 'run_full_gates.py', 'module_worker.py', 'accept_cli.py',
             'cohort_oracle.py', 'check_integrity.py', 'freeze_gates.py'):
    members[f'qa/{name}'] = qa/name
members[plan.relative_to(root).as_posix()] = plan
for name in ('docs/plan/week10/bic_icl_schema_v1.json', 'docs/plan/week10/economic_fixture_v1.json'):
    members[name] = root/name
manifest = {'version': 'bic_icl_cohort_acceptance_v1',
    'files': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in sorted(members.items())}}
destination = root/'docs/plan/week10/validation_gates/cohort_runtime_v1.zip'
with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(members.items()):
        archive.writestr(name, path.read_bytes())
    archive.writestr('manifest.json', json.dumps(manifest, indent=2, ensure_ascii=False).encode())
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    for name, checksum in manifest['files'].items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == checksum
    entries = len(archive.namelist())
receipt = {'path': destination.relative_to(root).as_posix(), 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
    'bytes': destination.stat().st_size, 'entries': entries, 'unit': 1083, 'leakage': 235, 'new_tests': 27}
(qa/'gate_archive_receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf8')
print(receipt)

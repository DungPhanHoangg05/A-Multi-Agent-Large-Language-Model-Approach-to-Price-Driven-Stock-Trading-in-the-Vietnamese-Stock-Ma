"""Đối soát chéo artifact W10-05 và đếm population A trực tiếp, không đọc action/payoff target."""
from pathlib import Path
import hashlib
import json
import sys

root = Path.cwd()
qa = Path(__file__).parent
sys.path[:0] = [str(root/'tests'), str(root)]
from bic_icl_fixture import DecisionFixture
from core.bic_icl_protocol import CohortSources
from core.bic_icl_runtime import context_lock
from core.historical_signals import digest
from core.improvement_transport import expected_contract
from core.research_cohort import read_envelope

plan_path = root/'outputs/bayesian_benchmark/bic_icl_v2/development_plan_v1.json'
plan = read_envelope(plan_path)
sources = CohortSources()
sources.validate(plan)
previous = read_envelope(root/'outputs/bayesian_benchmark/bic_icl_v2/context_v1/preflight.json')
old = {p['point_id']: p for p in previous['points']}
sdk = DecisionFixture()
packets = []
count_checks, fallback_checks, contracts = 0, 0, 0
max_prefix, max_prompt = 0, 0
try:
    for row in plan['schedule']:
        packet = sources.packet(row, *sources.cached(row))
        expected = old[row['point_id']]
        assert packet['evidence'] == expected['evidence']
        assert packet['a_evidence']['bank_sha256'] == packet['evidence']['bank_sha256']
        population = [r for r in sources.frozen.memory.records if r['symbol'] == row['symbol']
            and r['regime'] == packet['evidence']['query']['current_regime'] and r['exit_date'] < row['as_of_date']]
        signals = packet['evidence']['query']['current_signals']
        conditional = [r for r in population if all(r['agent_signals'][k] == signals[k] for k in ('trend', 'pattern'))]
        stats = packet['a_evidence']['statistics']
        if stats is not None:
            assert set(stats['groups']['population']['episode_ids']) == {r['episode_id'] for r in population}
            assert set(stats['groups']['conditional']['episode_ids']) == {r['episode_id'] for r in conditional}
            counts = stats['metrics']['win_rate_long']['raw_counts']['conditional']
            assert counts['support_count'] == len(conditional)
            assert counts['success_count'] == sum(r['outcome']['net_return_pct'] > 0 for r in conditional)
            count_checks += 1
        else:
            assert not population
        original = expected_contract(sdk.llm, packet['requests']['original']['prompt'])
        for method in ('R_pool', 'R_task'):
            for mode, suffix in (('full_prior', '_full'), ('stats_only', '_stats_only'), ('examples_only', '_examples_only')):
                request = packet['requests'][method+suffix]
                assert request['prefix'] == expected['rendering']['vi']['profiles'][method]['profiles'][mode]['prefix']
                assert request['prompt'] == expected['rendering']['vi']['prompts'][method][mode]
        bodies = {}
        for name, request in packet['requests'].items():
            body = expected_contract(sdk.llm, request['prompt'])
            bodies[name] = body
            contracts += 1
            if not request['prefix']:
                assert body == original
                fallback_checks += name != 'original'
            assert len(request['prefix']) <= 600 and len(request['prompt']) < 6500
            max_prefix, max_prompt = max(max_prefix, len(request['prefix'])), max(max_prompt, len(request['prompt']))
        assert bodies['R_pool_stats_only'] == bodies['R_task_stats_only']
        assert packet['requests']['R_pool_stats_only']['base_evidence_sha256'] == packet['requests']['R_task_stats_only']['base_evidence_sha256']
        packets.append(packet)
    sources.validate(plan)
finally:
    sdk.close()
lock = context_lock(plan, packets)
independent = []
for symbol in ('FPT', 'MWG', 'VCB', 'VNM'):
    rows = sorted((p for p in previous['points'] if p['point_id'].startswith(symbol+'-')), key=lambda p: p['point_id'])
    used = set()
    for target in ('BOTH', 'ONE', 'OFF'):
        classified = {p['point_id']: ('OFF', 'ONE', 'BOTH')[int(p['evidence']['gate']['R_pool']['stats_ready'])+
            int(p['evidence']['gate']['R_pool']['examples_ready'])] for p in rows}
        matches = [p for p in rows if p['point_id'] not in used and classified[p['point_id']] == target]
        candidates = matches or [p for p in rows if p['point_id'] not in used]
        key = candidates[0]['point_id']; used.add(key)
        independent.append({'point_id': key, 'requested_stratum': target, 'actual_stratum': classified[key],
            'reason': 'EARLIEST_MATCH' if matches else 'EARLIEST_UNUSED_FALLBACK'})
independent.sort(key=lambda r: (r['point_id'][4:], ('FPT', 'MWG', 'VCB', 'VNM').index(r['point_id'][:3])))
assert independent == lock['repeat_sample']
assert lock['matrix'] == ['original', 'A_reference_shared_off', 'R_pool_full', 'R_pool_stats_only',
    'R_pool_examples_only', 'R_task_full', 'R_task_stats_only', 'R_task_examples_only']
assert lock['coverage'] == previous['coverage']
assert lock['task_coverage_eligible'] is False
(qa/'cohort_packets.json').write_text(json.dumps({'plan_sha256': digest(plan), 'packets': packets,
    'context_lock': lock}, ensure_ascii=False, indent=2), encoding='utf8')
result = {'status': 'PASS', 'points': len(packets), 'a_population_checks': count_checks,
    'frozen_context_equality_checks': len(packets), 'sdk_contract_checks': contracts,
    'prior_off_canonical_checks': fallback_checks, 'repeat_sample_checks': len(independent),
    'max_prefix_chars': max_prefix, 'max_prompt_chars': max_prompt,
    'code_identity_files': len(plan['code_sha256']), 'context_lock_sha256': digest(lock),
    'plan_sha256_raw': hashlib.sha256(plan_path.read_bytes()).hexdigest(), 'llm_calls': 0,
    'coverage_insufficiency_preserved': not lock['task_coverage_eligible']}
(qa/'oracle_result.json').write_text(json.dumps(result, indent=2), encoding='utf8')
print(result, flush=True)

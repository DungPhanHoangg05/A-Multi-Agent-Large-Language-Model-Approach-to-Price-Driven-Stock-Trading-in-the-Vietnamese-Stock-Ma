"""Chạy CLI thật offline, giữ timestamp/byte plan và kiểm từ chối trước credential."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path.cwd()
qa = Path(__file__).parent
base = ['py', '-3.13', '-X', 'utf8', 'scripts/run_bic_icl.py']
plan = root/'outputs/bayesian_benchmark/bic_icl_v2/development_plan_v1.json'
results = []
before = None
for name, args, expected in (('prepare', ['--prepare'], 0), ('dryrun', ['--dry-run'], 0),
                             ('fixture', ['--economic-fixture'], 0),
                             ('unauthorized', ['--run', '--env-file', str(qa/'credential_must_not_be_read.env')], 1)):
    with (qa/f'cli_{name}.log').open('wb') as stream:
        result = subprocess.run([*base, *args], stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == expected, (name, result.returncode)
    print(name, result.returncode, flush=True)
    if name == 'prepare':
        before = {'sha256': hashlib.sha256(plan.read_bytes()).hexdigest(), 'mtime': plan.stat().st_mtime_ns}
    else:
        assert before == {'sha256': hashlib.sha256(plan.read_bytes()).hexdigest(), 'mtime': plan.stat().st_mtime_ns}
    results.append({'mode': name, 'exit_code': result.returncode})
assert 'Chưa có release development' in (qa/'cli_unauthorized.log').read_text('utf8')
receipt = {'status': 'PASS', 'commands': results, 'plan_read_only_after_prepare': True,
           'plan': {'path': plan.relative_to(root).as_posix(), **before}, 'llm_calls': 0}
(qa/'cli_acceptance.json').write_text(json.dumps(receipt, indent=2), encoding='utf8')
print(receipt, flush=True)

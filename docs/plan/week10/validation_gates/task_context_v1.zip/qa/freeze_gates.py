"""Đóng băng gate, CLI, oracle và context cuối; không nhận log bản nháp."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

root = Path.cwd()
qa = Path(__file__).parent
sys.path.insert(0, str(root))
from core.research_input_lock import runtime_identity

summary = json.loads((qa/'gates_final/summary.json').read_text('utf8'))
assert [r['gate'] for r in summary] == ['compileall', 'unit', 'e2e', 'leakage']
assert all(r['exit_code'] == 0 for r in summary)
assert summary[1]['tests'] == 1056 and summary[3]['tests'] == 227
assert summary[1]['modules'] == 134 and summary[3]['modules'] == 37
for name in ('unit', 'leakage'):
    inventory = json.loads((qa/f'gates_final/{name}_inventory.json').read_text('utf8'))
    assert inventory['actual'] == inventory['expected']
    for path in (qa/'gates_final').glob(f'{name}_*.result.json'):
        result = json.loads(path.read_text('utf8'))
        assert result['success'] and result['run'] == result['expected']
        assert all(result[k] == 0 for k in ('failures', 'errors', 'skipped', 'expected_failures', 'unexpected_successes'))
acceptance = json.loads((qa/'cli_acceptance.json').read_text('utf8'))
assert acceptance['codes'] == [0, 0] and acceptance['read_only']
artifact_dir = root/'outputs/bayesian_benchmark/bic_icl_v2/context_v1'
for name, expected in acceptance['artifacts'].items():
    path = artifact_dir/name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected['sha256']
    assert path.stat().st_mtime_ns == expected['mtime']
oracle = json.loads((qa/'oracle_result.json').read_text('utf8'))
assert oracle['status'] == 'PASS' and oracle['query_count'] == 60
assert oracle['centroid_checks'] == 150 and oracle['selected_pair_checks'] == 26
assert oracle['prompt_checks'] == 720 and oracle['cached_task_coverage_insufficient_preserved']
subprocess.run(['py', '-3.13', '-X', 'utf8', str(qa/'check_integrity.py')], check=True)
(qa/'runtime_at_acceptance.json').write_text(json.dumps(runtime_identity(), indent=2), encoding='utf8')
members = {f'qa/gates/{p.name}': p for p in (qa/'gates_final').iterdir() if p.is_file()}
for name in ('baseline.json', 'integrity.json', 'runtime_at_acceptance.json', 'cli_acceptance.json',
             'oracle_result.json', 'targeted_final.log', 'cli_build.log', 'cli_verify.log',
             'run_full_gates.py', 'module_worker.py', 'focused.py', 'accept_cli.py',
             'task_oracle.py', 'check_integrity.py', 'freeze_gates.py'):
    members[f'qa/{name}'] = qa/name
for path in artifact_dir.glob('*.json'):
    members[path.relative_to(root).as_posix()] = path
fixture = 'docs/plan/week10/context_budget_fixture_v1.json'
members[fixture] = root/fixture
manifest = {'version': 'bic_icl_task_context_acceptance_v1',
            'files': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in sorted(members.items())}}
destination = root/'docs/plan/week10/validation_gates/task_context_v1.zip'
with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(members.items()):
        archive.writestr(name, path.read_bytes())
    archive.writestr('manifest.json', json.dumps(manifest, indent=2, ensure_ascii=False).encode())
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    for name, checksum in manifest['files'].items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == checksum
    entries = len(archive.namelist())
receipt = {'path': destination.relative_to(root).as_posix(),
           'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
           'bytes': destination.stat().st_size, 'entries': entries, 'unit': 1056, 'leakage': 227, 'focused': 40}
(qa/'gate_archive_receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf8')
print(receipt)

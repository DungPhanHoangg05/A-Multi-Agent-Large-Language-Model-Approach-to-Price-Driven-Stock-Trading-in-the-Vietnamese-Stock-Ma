"""Oracle scalar độc lập trên nguồn khóa: qualify/rank/centroid/cặp/gap/prefix, không API."""
from pathlib import Path
from collections import Counter
from datetime import date
import hashlib,json,math,re,statistics,sys
sys.path.insert(0,str(Path.cwd()))
import numpy as np
import pandas as pd
from core.research_cohort import read_envelope
from core.execution_prices import load_verified_execution_data

root=Path.cwd(); qa=Path(__file__).parent
base=root/'outputs/bayesian_benchmark/bic_icl_v2'
report=read_envelope(base/'context_v1/preflight.json')
memory=read_envelope(base/'memory_v1/memory.json')
index=read_envelope(base/'memory_v1/index.json')
calendar=pd.read_csv(root/'data/historical/VNINDEX.csv')['Datetime'].tolist()
assert calendar[0]=='2018-01-02'
positions={d:i for i,d in enumerate(calendar)}
features={r['episode_id']:r['features'] for r in index['records']}
records={r['episode_id']:r for r in memory['records']}
prices={s:load_verified_execution_data(root/'data/execution_prices_oos',s)[0] for s in ('FPT','MWG','VCB','VNM')}
assert report['query_count']==60 and report['lambda']==8 and report['decision_calls']==0
assert report['technical_status']=='PASS' and report['confirmation_allowed'] is False
assert report['task_coverage_status']=='INSUFFICIENT_CACHED_UPSTREAM_COVERAGE'
score_error=distance_error=feature_error=0.; centroid_checks=pair_checks=prompt_checks=0
max_prefix=max_prompt=0
coverage={s:{'examples':0,'two':0} for s in prices}

def conflicts(left,right):
    return abs(positions[left['as_of_date']]-positions[right['as_of_date']])<5 or max(left['entry_date'],right['entry_date'])<=min(left['exit_date'],right['exit_date'])

def rank(row):
    return (-row['score'],-date.fromisoformat(row['record']['exit_date']).toordinal(),row['record']['episode_id'])

for point in report['points']:
    evidence=point['evidence']; q=evidence['query']; symbol=q['symbol']; cutoff=q['as_of_date']
    source=read_envelope(root/f"outputs/bayesian_benchmark/improvement_v1/development/run/points/{symbol}-{cutoff}.json")
    assert q['current_signals']==source['full_bundle']['current_signals']
    assert q['current_regime']==source['full_bundle']['market_regime']['regime_name']
    scaler=index['scalers']['oos_2023_2024'][symbol]
    actual_query=evidence['task_selection']['query_features']
    if actual_query['status']=='AVAILABLE':
        close=prices[symbol].loc[prices[symbol].Datetime<=pd.Timestamp(cutoff),'Close'].tail(21).to_numpy()
        raw=[close[-1]/close[-6]-1,close[-1]/close[0]-1,float(np.std(np.diff(np.log(close)),ddof=0)),close[-1]/close[-20:].mean()-1]
        feature_error=max(feature_error,float(np.max(np.abs(np.asarray(raw)-actual_query['raw_vector']))))
        query_vector=[(x-m)/scale for x,m,scale in zip(raw,scaler['mean'],scaler['scale'])]
    else:
        query_vector=None
    qualified=[]
    population=[r for r in memory['records'] if r['symbol']==symbol and r['regime']==q['current_regime'] and r['exit_date']<cutoff]
    if query_vector is not None:
        for record in population:
            f=features[record['episode_id']]
            age=(date.fromisoformat(cutoff)-date.fromisoformat(record['as_of_date'])).days
            if age>730 or f['status']!='AVAILABLE':continue
            vector=[(x-m)/scale for x,m,scale in zip(f['vector'],scaler['mean'],scaler['scale'])]
            distance=math.sqrt(sum((x-y)**2 for x,y in zip(vector,query_vector))/4)
            matches=sum(record['agent_signals'][k]==q['current_signals'][k] for k in ('trend','pattern','alpha_consensus','indicator_consensus'))
            similarity=.5*matches/4+.5/(1+distance)
            if similarity<.625:continue
            qualified.append({'record':record,'vector':vector,'score':similarity*2**(-age/365)})
    qualified.sort(key=rank)
    task_selection=evidence['task_selection']
    assert [r['record']['episode_id'] for r in qualified]==task_selection['metadata']['qualified_ids'],point['point_id']
    actual_cycles={r['episode_id']:r for r in task_selection['eligible_cycles']}
    groups={}
    for row in qualified:
        record=row['record']; key=f"{symbol}:{q['current_regime']}:{positions[record['as_of_date']]//20:04d}"
        groups.setdefault(key,[]).append(row)
        score_error=max(score_error,abs(row['score']-actual_cycles[record['episode_id']]['rank_score']))
    actual_tasks={t['task_id']:t for t in task_selection['task_trace']}
    tasks=[]
    for key,members in groups.items():
        centroid=[statistics.fmean(row['vector'][i] for row in members) for i in range(4)]
        distance=math.sqrt(sum((x-y)**2 for x,y in zip(centroid,query_vector))/4)
        actual=actual_tasks[key]
        distance_error=max(distance_error,abs(distance-actual['centroid_distance']),max(abs(a-b) for a,b in zip(centroid,actual['centroid'])))
        pair=[]
        for row in members:
            if len(pair)<2 and all(not conflicts(row['record'],r) for r in pair):pair.append(row['record'])
        assert [r['episode_id'] for r in pair]==actual['intrinsic_pair']
        centroid_checks+=1
        if len(pair)==2:
            tasks.append({'key':key,'pair':pair,'distance':distance,'day':max(r['record']['as_of_date'] for r in members)})
    tasks.sort(key=lambda t:(t['distance'],-date.fromisoformat(t['day']).toordinal(),t['key']))
    # Sai số scalar không được dùng tolerance để thay tie-break trên nguồn; kiểm cả ordering thật.
    assert [t['key'] for t in tasks]==task_selection['ranked_task_ids'],point['point_id']
    accepted=[]; selected=[]
    for task in tasks:
        if len(selected)<3 and all(not conflicts(r,p) for r in task['pair'] for p in accepted):
            selected.append(task['key']);accepted.extend(task['pair'])
    assert selected==task_selection['selected_task_ids'],point['point_id']
    assert [r['episode_id'] for r in accepted]==task_selection['selected_episode_ids']
    assert len(selected)<=3 and len(accepted)==2*len(selected)
    for i,left in enumerate(accepted):
        assert left['exit_date']<cutoff
        for right in accepted[i+1:]:assert not conflicts(left,right)
    pair_checks+=len(selected)
    ready=evidence['gate']['R_task']['examples_ready']
    coverage[symbol]['examples']+=int(ready)
    coverage[symbol]['two']+=int(ready and len(selected)>=2)
    for language,rendered in point['rendering'].items():
        assert rendered['prompts']['R_pool']['stats_only']==rendered['prompts']['R_task']['stats_only']
        for method,part in rendered['profiles'].items():
            assert part['status']=='AVAILABLE'
            for mode,request in part['profiles'].items():
                prefix=request['prefix'];prompt=rendered['prompts'][method][mode]
                max_prefix=max(max_prefix,len(prefix));max_prompt=max(max_prompt,len(prompt));prompt_checks+=1
                assert len(prefix)<=600 and len(prompt)<6500
                assert request['base_evidence_sha256']==evidence['base_evidence_sha256']
                assert request['decision_contract_version']=='decision_legacy_v1'
                visible=request['trace']['visible_example_ids']
                tokens=re.findall(r'([+\-0]{2})→([WL])/([+\-]\d+\.\d{2})%',prefix)
                assert len(tokens)==len(visible)
                signs={'BULLISH':'+','BEARISH':'-','NEUTRAL':'0'}
                for key,token in zip(visible,tokens):
                    record=records[key]; net=record['outcome']['net_return_pct']
                    assert token==(''.join(signs[record['agent_signals'][k]] for k in ('trend','pattern')),
                        'W' if net>0 else 'L',f'{net if net!=0 else 0.:+.2f}')
                if prefix:
                    assert prompt.count(prefix)==1
                else:
                    assert request['trace']['fallback_to_original'] and prompt==rendered['original_prompt']
                if method=='R_task':
                    for number in range(request['trace']['k_tasks']):assert f'G{number+1}'+'{' in prefix
fixture=report['budget_fixture']
assert fixture['languages']['vi']['max_prefix_chars']==300 and fixture['languages']['en']['max_prefix_chars']==297
assert max(v['max_prompt_chars'] for v in fixture['languages'].values())<6500
assert feature_error<1e-13 and score_error<1e-12 and distance_error<1e-10
assert coverage=={'FPT':{'examples':3,'two':0},'MWG':{'examples':6,'two':1},'VCB':{'examples':3,'two':1},'VNM':{'examples':9,'two':1}}
result={'status':'PASS','query_count':60,'centroid_checks':centroid_checks,'selected_pair_checks':pair_checks,
    'prompt_checks':prompt_checks,'max_real_prefix_chars':max_prefix,'max_real_prompt_chars':max_prompt,
    'max_feature_error':feature_error,'max_rank_score_error':score_error,'max_centroid_distance_error':distance_error,
    'coverage':coverage,'cached_task_coverage_insufficient_preserved':True}
(qa/'oracle_result.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result))

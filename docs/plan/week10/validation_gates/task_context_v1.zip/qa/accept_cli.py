"""CLI build/verify thật trên code cuối, kiểm byte và timestamp output."""
from pathlib import Path
import hashlib,json,subprocess

root=Path.cwd(); qa=Path(__file__).parent
destination=root/'outputs/bayesian_benchmark/bic_icl_v2/context_v1'
args=['py','-3.13','-X','utf8','scripts/prepare_bic_icl_context.py','--destination',str(destination)]
codes=[]
with (qa/'cli_build.log').open('wb') as stream:
    codes.append(subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT).returncode)
assert codes[-1]==0
before={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mtime':p.stat().st_mtime_ns} for p in destination.iterdir()}
print('CLI build hoàn tất',flush=True)
with (qa/'cli_verify.log').open('wb') as stream:
    codes.append(subprocess.run([*args,'--verify'],stdout=stream,stderr=subprocess.STDOUT).returncode)
after={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mtime':p.stat().st_mtime_ns} for p in destination.iterdir()}
result={'codes':codes,'read_only':before==after,'artifacts':after}
(qa/'cli_acceptance.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(result,flush=True)
raise SystemExit(0 if codes==[0,0] and before==after else 1)

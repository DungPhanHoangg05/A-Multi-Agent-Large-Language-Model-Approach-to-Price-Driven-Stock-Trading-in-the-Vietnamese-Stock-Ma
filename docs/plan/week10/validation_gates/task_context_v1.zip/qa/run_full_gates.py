"""Bốn gate đầy đủ, chia động nguyên module và đối chiếu multiset discovery."""
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

from module_worker import initialize, run_module, ids


def main():
    """Giữ byte code logic LF không đổi suốt compileall/unit/E2E/leakage."""
    root = Path.cwd(); base = Path(__file__).resolve().parent
    qa = base/'gates_final'; qa.mkdir(exist_ok=True)
    sys.path[:0] = [str(root/'tests'), str(root)]
    files = set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','*.py'],text=True).split('\0'))-{''}
    files.update(['core/bic_icl_decisions.py','tests/bic_icl_fixture.py','tests/test_bic_icl_decisions.py',
                  'tests/test_bic_icl_decisions_leakage.py','.python-version','requirements.txt',
                  'docs/plan/week10/method_protocol_v1.md'])
    files.add('docs/plan/week10/context_budget_fixture_v1.json')
    files = sorted(n for n in files if (root/n).is_file())
    def identity():
        """Identity LF cùng quy ước binding source của component."""
        return {n:hashlib.sha256((root/n).read_text(encoding='utf-8').encode()).hexdigest() for n in files}
    frozen = identity()
    (qa/'identity.json').write_text(json.dumps({'python':sys.version,'normalization':'UTF8_LF',
        'files':frozen,'pid':os.getpid()},indent=2),encoding='utf-8')
    summary=[]
    def record(name,code,**details):
        """Ghi gate đã hoàn tất, không nhận gate cũ thay code mới."""
        summary.append({'gate':name,'exit_code':code,**details})
        (qa/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
        print(name,code,details,flush=True)
        if code:raise SystemExit(code)
    def command(name,args):
        """Chạy lệnh chuẩn và giữ stdout/stderr UTF-8 trong file."""
        with (qa/f'{name}.log').open('wb') as stream:
            result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
        record(name,result.returncode)
    def suite(name,pattern):
        """Bốn process liên tục, không chia test trong một module."""
        expected=Counter(ids(unittest.defaultTestLoader.discover(str(root/'tests'),pattern=pattern)))
        modules=sorted((p.stem for p in (root/'tests').glob(pattern)),
                       key=lambda n:(root/'tests'/f'{n}.py').stat().st_size,reverse=True)
        completed=[]
        with ProcessPoolExecutor(max_workers=4,initializer=initialize,initargs=(str(root),str(qa),name)) as pool:
            jobs=[pool.submit(run_module,(str(qa),name,module)) for module in modules]
            for future in as_completed(jobs):
                data=future.result(); completed.append(data)
                progress={'completed_modules':len(completed),'total_modules':len(modules),
                    'completed_tests':sum(d['run'] for d in completed),'failed_modules':[d['module'] for d in completed if not d['success']]}
                (qa/f'{name}_progress.json').write_text(json.dumps(progress,indent=2),encoding='utf-8')
                if len(completed)%20==0 or not data['success']:
                    print(name,progress,flush=True)
        actual=Counter(i for d in completed for i in d['ids'])
        (qa/f'{name}_inventory.json').write_text(json.dumps({'expected':dict(expected),'actual':dict(actual)},indent=2),encoding='utf-8')
        success=actual==expected and all(d['success'] for d in completed)
        record(name,0 if success else 1,tests=sum(d['run'] for d in completed),skips=sum(d['skipped'] for d in completed),
               modules=len(completed),workers=4,discovery_multiset_matches=actual==expected)
    command('compileall',['py','-3.13','-m','compileall','agents','core','data_manager','scripts','tests','utils'])
    suite('unit','test*.py')
    command('e2e',['py','-3.13','-X','utf8','scripts/run_end_to_end_test.py'])
    suite('leakage','test_*leakage.py')
    assert frozen==identity()
    print('PASS: bốn gate và identity LF',flush=True)


if __name__=='__main__':
    main()

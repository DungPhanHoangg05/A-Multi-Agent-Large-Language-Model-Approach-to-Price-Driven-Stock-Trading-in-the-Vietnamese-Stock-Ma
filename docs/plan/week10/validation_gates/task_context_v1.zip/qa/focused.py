"""Ghi đúng các module mới trên code cuối, giữ log không gọi mạng."""
from pathlib import Path
import contextlib,sys,unittest
sys.path[:0]=[str(Path.cwd()/'tests'),str(Path.cwd())]
qa=Path(__file__).parent
names=['test_bic_icl_tasks','test_bic_icl_tasks_leakage','test_bic_icl_prompt',
       'test_bic_icl_context_protocol','test_bic_icl_context_preparation']
with (qa/'targeted_final.log').open('w',encoding='utf8') as stream,contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
print('Số ca mới:',result.testsRun,'PASS:',result.wasSuccessful(),flush=True)
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)

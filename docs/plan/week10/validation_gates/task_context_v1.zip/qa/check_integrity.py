"""Đối soát byte cũ và identity code LF trước/sau gate và checkout."""
from pathlib import Path
import hashlib,json,re,subprocess

root=Path.cwd(); qa=Path(__file__).parent
baseline=json.loads((qa/'baseline.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changed=[n for n,h in baseline.items() if not(root/n).is_file() or sha(root/n)!=h]
assert not changed,changed
gate=json.loads((qa/'gates_final/identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256((root/n).read_text('utf8').encode()).hexdigest()==h for n,h in gate['files'].items())
for name in ('docs/plan/plan.md','docs/plan/week10/README.md'):
    path=root/name
    for link in re.findall(r'(?<!!)\[[^\]]+\]\(([^\s)]+)\)',path.read_text('utf8')):
        if ':' in link or link.startswith('#'):continue
        relative=link.split('#')[0]
        assert not relative or (path.parent/relative).exists(),(name,link)
subprocess.run(['git','diff','--check'],check=True)
result={'status':'PASS','old_files_unchanged':len(baseline),'code_identity_files':len(gate['files']),
        'normalization':'UTF8_LF','links_valid':True}
(qa/'integrity.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(result)

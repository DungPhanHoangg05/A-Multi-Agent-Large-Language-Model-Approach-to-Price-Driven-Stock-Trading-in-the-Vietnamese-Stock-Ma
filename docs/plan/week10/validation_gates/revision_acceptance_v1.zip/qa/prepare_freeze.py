"""Khóa source/runtime trước nghiệm thu; không cấp quyền API hoặc đổi plan."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path.cwd()
qa = Path(__file__).parent
sys.path.insert(0, str(root))
from core.bic_icl_protocol import CohortSources, code_identity
from core.historical_signals import digest
from core.research_cohort import read_envelope
from core.research_input_lock import _write_once, runtime_identity

plan_path = root/'outputs/bayesian_benchmark/bic_icl_v2/development_plan_v1.json'
plan = read_envelope(plan_path)
sources = CohortSources()
sources.validate(plan)
identity = json.loads((qa/'gates_final/identity.json').read_text('utf8'))
assert plan['code_sha256'] == code_identity()
assert plan['runtime'] == runtime_identity()
assert len(identity['files']) == 271 and len(plan['code_sha256']) == 85
assert all(hashlib.sha256((root/p).read_text('utf8').encode()).hexdigest() == checksum
           for p, checksum in identity['files'].items())
freeze = {'freeze_version': 'bic_icl_revision_source_freeze_v1', 'status': 'FROZEN',
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'plan': {'path': plan_path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(plan_path.read_bytes()).hexdigest(),
             'payload_sha256': digest(plan), 'mtime_ns': plan_path.stat().st_mtime_ns},
    'code_normalization': 'UTF8_LF', 'code_sha256': plan['code_sha256'], 'runtime': plan['runtime'],
    'gate_source_sha256': identity['files'], 'source_hashes': plan['source_hashes'],
    'protocol_sha256': digest(plan['protocol']), 'upstream_policy': plan['upstream_policy'],
    'confirmation_allowed': False, 'api_release_issued': False}
_write_once(qa/'source_freeze.json', freeze)
print({'status': 'PASS', 'code_files': 85, 'gate_files': 271, 'source_files': len(plan['source_hashes']),
       'source_freeze_sha256': hashlib.sha256((qa/'source_freeze.json').read_bytes()).hexdigest()}, flush=True)

"""Chạy CLI/oracle trước kiểm development/repeat offline; dừng ngay khi lỗi."""
from pathlib import Path
import subprocess

qa = Path(__file__).parent
for name in ('accept_cli', 'cohort_oracle', 'accept_repeats'):
    print('Bắt đầu', name, flush=True)
    with (qa/f'{name}.log').open('wb') as stream:
        result = subprocess.run(['py', '-3.13', '-X', 'utf8', str(qa/f'{name}.py')],
                                stdout=stream, stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit(result.returncode)
    print('PASS:', name, flush=True)

"""Đối chiếu index/merge với bằng chứng đã khóa và liên kết kế hoạch."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
from urllib.parse import unquote
import zipfile

root = Path.cwd()
qa = Path(__file__).parent
sys.path.insert(0, str(root))
from core.bic_icl_protocol import CohortSources
from core.candidate_selection import read_technical_gates
from core.research_cohort import read_envelope


def sha(path: Path) -> str:
    """Hash byte thực sau stage hoặc merge."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


baseline = json.loads((qa/'baseline.json').read_text('utf8'))
assert all(sha(root/name) == value for name, value in baseline.items())
receipt = json.loads((qa/'archive_receipt.json').read_text('utf8'))
archive_path = root/receipt['path']
assert sha(archive_path) == receipt['sha256']
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == receipt['entries']
    manifest = json.loads(archive.read('manifest.json'))
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == checksum
               for name, checksum in manifest['files'].items())
    assert all((root/name).read_bytes() == archive.read(name) for name in manifest['files']
               if name.startswith('docs/plan/week10/validation_gates/'))

plan = read_envelope(root/'outputs/bayesian_benchmark/bic_icl_v2/development_plan_v1.json')
CohortSources().validate(plan)
assert read_technical_gates(root/'docs/plan/week10/validation_gates/revision_v1/technical_gates.json', plan)['status'] == 'PASS'
for path in ('docs/plan/plan.md', 'docs/plan/week10/README.md'):
    source = root/path
    text = source.read_text('utf8')
    for link in re.findall(r'\]\(([^)]+)\)', text):
        target = unquote(link.strip('<>').split('#')[0])
        if not target or re.match(r'[a-zA-Z][\w+.-]*:', target):
            continue
        assert (source.parent/target).resolve().exists(), (path, target)
    assert '7/8' in text
week = (root/'docs/plan/week10/README.md').read_text('utf8')
assert receipt['sha256'] in week and receipt['technical_gates_sha256'] in week
assert '| W10-07 |' in week and '| W10-08 |' in week
subprocess.run(['git', 'diff', '--check'], check=True)
paths = set(subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z'], text=True).split('\0'))-{''}
if paths:
    expected = {'docs/plan/plan.md', 'docs/plan/week10/README.md', receipt['path'],
                'docs/plan/week10/validation_gates/.gitattributes'}
    expected.update(p.relative_to(root).as_posix() for p in (root/'docs/plan/week10/validation_gates/revision_v1').iterdir())
    assert paths == expected and len(paths) == 11, sorted(paths)
    for name in paths:
        content = subprocess.check_output(['git', 'show', ':'+name])
        if name in ('docs/plan/plan.md', 'docs/plan/week10/README.md'):
            assert content.decode('utf8').replace('\r\n', '\n') == (root/name).read_text('utf8')
        else:
            assert content == (root/name).read_bytes(), 'Index khác byte đã khóa: '+name
print({'status': 'PASS', 'old_files_unchanged': len(baseline), 'source_runtime_and_gate_consumer': 'PASS',
       'archive_crc_and_entry_hashes': 'PASS', 'links': 'PASS', 'staged_files': len(paths)}, flush=True)

"""Cập nhật hai tài liệu tiến độ sau nghiệm thu; giữ lịch sử và root README."""
from pathlib import Path
import json

root = Path.cwd()
qa = Path(__file__).parent
r = json.loads((qa/'archive_receipt.json').read_text('utf8'))
assert r['status'] == 'PASS'
week_path = root/'docs/plan/week10/README.md'
text = week_path.read_text('utf8')
old = '**Trạng thái: IN PROGRESS, 6/8. W10-01–06 DONE; đã có producer/loader/verifier/CLI cohort, nghiệm thu offline; R_task chưa đủ coverage đề cử trên cache, chưa có release/API revision.**'
assert text.count(old) == 1
text = text.replace(old, '**Trạng thái: IN PROGRESS, 7/8. W10-01–07 DONE; bốn gate toàn revision, source freeze và dry-run development/repeat PASS; R_task chưa đủ coverage đề cử trên cache, chưa có release/API revision.**')
text = text.replace('Chưa có CLI cohort revision.', 'CLI cohort đã triển khai tại W10-06.')
old = '| W10-07 | Bốn gate, source freeze, dry-run development/repeat | 06 | Compileall/unit/E2E/leakage PASS đúng code/runtime | [ ] TODO |'
assert text.count(old) == 1
text = text.replace(old, '| W10-07 | Bốn gate, source freeze, dry-run development/repeat | 06 | Compileall/unit/E2E/leakage PASS đúng code/runtime | [x] DONE — 1.083 unit/235 leakage, compileall/E2E PASS; receipt consumer và dry-run/repeat PASS |')
old = 'Chưa có runtime Decision revision mới; bốn gate cho công cụ audit W10-01\nkhông thay nghiệm thu W10-07 sau triển khai thuật toán.'
assert text.count(old) == 1
text = text.replace(old, 'Runtime revision đã triển khai W10-06; nghiệm thu toàn revision W10-07\nPASS với source/runtime đã khóa. Hướng dẫn vận hành và chương phương pháp\ncòn W10-08; release và execution development thuộc W11.')
row = '| Report | `core/bic_icl_reports.py` đã triển khai W10-06; engine/metric cũ | Common support, bốn tài khoản, primary/repeat riêng; selection/bootstrap thuộc W11 |'
assert text.count(row) == 1
text = text.replace(row, row+'\n| Nghiệm thu revision | `validation_gates/revision_v1/`, `revision_acceptance_v1.zip` tại tuần 10, W10-07 | Source/runtime freeze, receipt bốn gate đọc được bởi consumer, dry-run 60 điểm và repeat SDK mock |')
assert '## W10-07 —' not in text
text += f'''
## W10-07 — Nghiệm thu toàn revision và source freeze, 22/10/2026

**DONE; W10 7/8.** Task thêm receipt/log, gói bằng chứng và cập nhật tiến độ;
code, test, runtime, schema, phương pháp và nguồn đầu vào giữ nguyên.
Theo yêu cầu mốc nghiệm thu, chạy lại đủ bốn gate trên Python **3.13.5**
sau tích hợp W10-03–06. Không dùng lượt gate component thay lượt này.

**Source freeze:** [`revision_v1/source_freeze.json`](validation_gates/revision_v1/source_freeze.json)
khóa mã tại commit `279dcbf`, **85 dependency thực thi**, **271 tệp trong
phạm vi gate**, **1.773 hash nguồn** và phiên bản dependency runtime.
Code dùng UTF-8/LF; artifact/log kiểm byte gốc. Plan development v1 giữ SHA
`c728af94811636cde5360c9b029602b1e1946af048db7ddfff3fd89802fac530`,
digest payload và timestamp W10-06. Source freeze SHA-256 byte
`{r['source_freeze_sha256']}`.

| Gate chạy mới | Kết quả |
| --- | --- |
| Compileall `agents core data_manager scripts tests utils` | PASS, exit 0 |
| Unit discovery `test*.py` | **1.083 test / 137 module PASS** |
| E2E xác định `scripts/run_end_to_end_test.py` | PASS, marker toàn pipeline |
| Leakage discovery `test_*leakage.py` | **235 test / 38 module PASS** |

Hai suite chạy bốn process, chia nguyên module và giữ thứ tự nội bộ;
multiset ID khớp discovery, gồm bội số có sẵn. Không lỗi, skip, expected
failure hoặc unexpected success. Hash 271 tệp giữ nguyên suốt bốn gate.
Log tổng hợp nêu rõ cách chạy và từng module; log worker/inventory gốc
được giữ trong ZIP. Không bổ sung hoặc sửa mã test trong task này.

[`revision_v1/technical_gates.json`](validation_gates/revision_v1/technical_gates.json)
dùng envelope `research_technical_gates_v1`, bind đúng 85 dependency/runtime
của plan, bốn exit code và hash từng log đi kèm. Consumer hiện hữu
`read_technical_gates` đọc lại **PASS**; binding sai code/runtime bị từ chối.
SHA-256 receipt byte
`{r['technical_gates_sha256']}`.
`.gitattributes` tại thư mục bằng chứng giữ byte receipt/log khi checkout.

**Dry-run development/repeat:**
[`revision_v1/dry_run.json`](validation_gates/revision_v1/dry_run.json), SHA-256 byte
`{r['dry_run_sha256']}`. CLI prepare/dry-run/economic fixture exit 0;
thử run thiếu release exit 1 trước credential/HTTP. Oracle tái đối soát
60 population A/context với nguồn W10-05, 480 contract SDK, 117 prior-off
canonical và mẫu 12 điểm repeat không fallback. Prefix/prompt lớn nhất
518/4.671 ký tự, dưới trần 600/6.500. Context lock vẫn có digest
`19db9111bdea7865478f809c188b5903d89b1090edb93fdb941d4c9e48250ddd`.

Trên metadata thật: kiểm **60 primary + 12×3 repeat**, **96 thứ tự block /
804 contract SDK**, cùng request/upstream và rotation đã khóa, không invoke
Decision. Đây là dry-run, chưa có action/return development revision thật.

Trên nguồn tổng hợp ngoài workspace, SDK/transport thật dùng HTTP mock:
**12 primary + ba lượt 12 điểm**, tổng **156 HTTP giả lập**, mỗi repeat 42.
Mỗi lượt có 12 duplicate độc lập; restart SDK rồi resume/verify không thêm
HTTP, primary/packet/upstream giữ nguyên byte. Numeric chỉ tính ở primary;
repeat tách report, không nhập D hoặc chọn lượt tốt nhất. Report mang
`split=fixture`; checkpoint/ledger/cache mock được giữ trong ZIP, không
dùng làm kết quả khoa học. Fixture kinh tế vẫn kiểm đủ bốn đường LONG/CASH.

R_task đạt kỹ thuật nhưng cache chỉ **3 điểm có ≥2 task, FPT=0**;
`task_coverage_eligible=false`. Giữ ngưỡng đề cử ≥6 và ≥1/mã. Gate kỹ thuật
không cấp release: consumer authorization vẫn từ chối khi thiếu release,
`api_release_issued=false`, `confirmation_allowed=false`. Không có API/LLM
thật hoặc payoff/action 2025 mới; deployment/risk OFF giữ nguyên.

**Gói bằng chứng:**
[`validation_gates/revision_acceptance_v1.zip`](validation_gates/revision_acceptance_v1.zip),
**{r['entries']:,} entry / {r['bytes']:,} byte**, SHA-256 byte
`{r['sha256']}`.
Manifest/hash từng entry/CRC PASS; gồm source của 271 tệp, plan, source
freeze, receipt/log/inventory bốn gate, CLI/oracle/metadata 60 điểm, fixture
primary/repeat và công cụ QA. **6.711 tệp cũ nguyên byte**, gồm W9, ledger,
snapshot W10-01–06 và plan; root README giữ nguyên. Diff/liên kết PASS.

Đọc lại gate offline từ root, đồng thời kiểm source/runtime hiện tại:

```powershell
@'
from pathlib import Path
from core.bic_icl_protocol import CohortSources
from core.candidate_selection import read_technical_gates
from core.research_cohort import read_envelope
plan = read_envelope(Path("outputs/bayesian_benchmark/bic_icl_v2/development_plan_v1.json"))
CohortSources().validate(plan)
print(read_technical_gates(Path("docs/plan/week10/validation_gates/revision_v1/technical_gates.json"), plan)["status"])
'@ | py -3.13 -X utf8 -
```

Tiếp theo **W10-08**: hướng dẫn API/resume/verify và chương phương pháp;
W11-01 còn khóa upstream/request/repeat và release development trước API.
'''
week_path.write_text(text, encoding='utf8')
plan_path = root/'docs/plan/plan.md'
text = plan_path.read_text('utf8')
old = '### 📅 TUẦN 10: Thiết kế và triển khai revision Bayesian ICL — IN PROGRESS 6/8'
assert text.count(old) == 1
text = text.replace(old, old.replace('6/8', '7/8'))
marker = '### 📅 TUẦN 11: Development và khóa xác nhận mới — TODO 0/8'
assert text.count(marker) == 1 and '- **W10-07 DONE' not in text
entry = '''- **W10-07 DONE, 22/10/2026:** [nghiệm thu toàn revision và source freeze](week10/README.md#w10-07--nghiệm-thu-toàn-revision-và-source-freeze-22102026).
  Khóa 85 dependency/271 tệp gate/1.773 hash nguồn và runtime; giữ plan v1
  nguyên byte/timestamp. Chạy mới **compileall/E2E, 1.083 unit/235 leakage
  PASS**, không lỗi/skip, đủ discovery/multiset. Receipt bốn gate được
  consumer đọc PASS; log/receipt giữ byte qua Git, source/runtime sai bị chặn.
  Dry-run 60 primary + 12×3 repeat kiểm 804 contract; fixture SDK mock 12
  primary/ba repeat PASS, duplicate độc lập, resume/verify không thêm HTTP,
  primary/upstream nguyên byte và Numeric chỉ primary. ZIP nguồn/gate/QA
  có manifest/hash/CRC; **6.711 tệp cũ nguyên byte**. R_task coverage cache
  vẫn chưa đủ đề cử; chưa release/API revision hoặc payoff 2025 mới.
  Task nghiệm thu không sửa code/test/runtime/schema/input; bốn gate chạy
  lại theo yêu cầu mốc W10-07. **W10 7/8 DONE**, tiếp theo **W10-08**.

'''
text = text.replace(marker, entry+marker)
plan_path.write_text(text, encoding='utf8')
print('PASS: cập nhật checklist 7/8 và hai tài liệu tiến độ')

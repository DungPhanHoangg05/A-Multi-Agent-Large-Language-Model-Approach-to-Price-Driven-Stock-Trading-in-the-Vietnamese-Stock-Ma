"""Dry-run metadata thật và ba repeat SDK mock; không tạo kết quả nghiên cứu."""
from collections import Counter
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import shutil
import sys
from unittest.mock import patch

root = Path.cwd()
qa = Path(__file__).parent
sys.path[:0] = [str(root/'tests'), str(root)]
from bic_icl_cohort_support import CohortFixture
from bic_icl_fixture import DecisionFixture
from core.bic_icl_protocol import CohortSources
from core.bic_icl_reports import verify_report
from core.bic_icl_runtime import context_lock, requests_for, run_cohort
from core.historical_signals import digest
from core.improvement_transport import expected_contract
from core.research_cohort import read_envelope
from core.research_input_lock import _write_once


def checksum(path):
    """Hash byte checkpoint, không chuẩn hóa bằng chứng runtime."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def expected_order(matrix, index, repeat):
    """Oracle rotation độc lập từ công thức đã khóa, không gọi branch_order."""
    others = matrix[1:]+(['original_duplicate'] if repeat else [])
    shift = (index if repeat == 0 else 3*index+repeat-1) % len(others)
    return ['original', *others[shift:], *others[:shift]]


def real_metadata():
    """Chỉ serialize request 2023 và metadata repeat, không invoke Decision."""
    sidecar = json.loads((qa/'cohort_packets.json').read_text('utf8'))
    plan = read_envelope(root/'outputs/bayesian_benchmark/bic_icl_v2/development_plan_v1.json')
    sources = CohortSources()
    sources.validate(plan)
    packets, lock = sidecar['packets'], sidecar['context_lock']
    assert context_lock(plan, packets) == lock
    assert len(packets) == 60 and len(lock['repeat_sample']) == 12
    assert lock['task_coverage_eligible'] is False and lock['task_enabled'] is True
    selected_ids = {r['point_id'] for r in lock['repeat_sample']}
    selected = [p for p in packets if p['point_id'] in selected_ids]
    metadata, contract_checks = [], 0
    sdk = DecisionFixture()
    try:
        for repeat in (0, 1, 2, 3):
            rows = packets if repeat == 0 else selected
            for j, packet in enumerate(rows):
                requests = requests_for(packet, lock, j, repeat)
                assert [r['branch_id'] for r in requests] == expected_order(lock['matrix'], j, repeat)
                body_original = expected_contract(sdk.llm, packet['requests']['original']['prompt'])
                request_hashes = {}
                for request in requests:
                    branch = request['branch_id']
                    source = packet['requests']['original' if branch == 'original_duplicate' else branch]
                    assert {**request, 'branch_id': source['branch_id']} == source
                    body = expected_contract(sdk.llm, request['prompt'])
                    contract_checks += 1
                    request_hashes[branch] = digest(body)
                    assert len(request['prefix']) <= 600 and len(request['prompt']) < 6500
                    if branch == 'original_duplicate' or not request['prefix']:
                        assert body == body_original
                metadata.append({'repeat_id': repeat, 'point_id': packet['point_id'], 'sorted_index': j,
                    'order': [r['branch_id'] for r in requests], 'canonical_request_sha256': request_hashes})
        assert len(sdk.requests) == 0 and len(metadata) == 96 and contract_checks == 804
    finally:
        sdk.close()
    _write_once(qa/'development_repeat_metadata.json', {'version': 'bic_icl_dry_run_metadata_v1',
        'plan_sha256': digest(plan), 'context_lock_sha256': digest(lock), 'rows': metadata,
        'repeat_sample': lock['repeat_sample'], 'coverage': lock['coverage'], 'decision_calls': 0,
        'task_coverage_eligible': False, 'confirmation_allowed': False})
    print('PASS: 60 primary, 12 điểm x 3 repeat; 804 contract SDK, không invoke', flush=True)
    return {'primary_points': 60, 'repeat_points_per_round': 12, 'repeat_rounds': 3,
        'order_checks': 96, 'canonical_contract_checks': 804, 'decision_calls': 0,
        'context_lock_sha256': digest(lock), 'coverage': lock['coverage'], 'task_coverage_eligible': False}


def fixture_runtime():
    """Chạy primary/repeat/resume/verify bằng HTTP mock ngoài workspace."""
    fx = CohortFixture()
    records = []
    try:
        assert not fx.root.is_relative_to(root)
        def run(**options):
            with patch('builtins.print'):
                return run_cohort(fx.plan, fx.sources, fx.root, fx.sdk.llm, fixture=True, **options)
        primary = run()
        assert primary['split'] == 'fixture' and primary['status'] == 'COMPLETE'
        assert primary['in_primary'] is True and len(primary['points']) == 12
        assert 'Numeric_only' in primary['matrix']
        _write_once(fx.root/'report_0.json', primary)
        protected = {p: checksum(p) for p in fx.root.rglob('*.json')
                     if p.name not in ('run.owner.json', 'run.recovery.json')}
        upstream = {p: checksum(p) for p in (fx.root/'packets').glob('*.json')}
        for repeat in (1, 2, 3):
            fx.sdk.restart()
            before = len(fx.sdk.requests)
            report = run(repeat_id=repeat, resume=True)
            assert report['split'] == 'fixture' and report['status'] == 'COMPLETE'
            assert report['repeat_id'] == repeat and report['in_primary'] is False
            assert 'Numeric_only' not in report['matrix'] and len(report['points']) == 12
            assert not report['nomination_performed'] and not report['confirmation_allowed']
            for point in report['points']:
                duplicate = point['branches']['original_duplicate']
                assert duplicate['decision_origin'] == 'independent_duplicate'
                assert duplicate['scientific_attempt_count'] == 1
            after = len(fx.sdk.requests)
            assert after-before >= 24
            _write_once(fx.root/f'report_{repeat}.json', report)
            assert run(repeat_id=repeat, resume=True) == report
            assert run(repeat_id=repeat, verify_only=True) == report
            verify_report(fx.root/f'report_{repeat}.json', report)
            assert len(fx.sdk.requests) == after
            assert all(checksum(p) == sha for p, sha in protected.items())
            assert all(checksum(p) == sha for p, sha in upstream.items())
            assert run(verify_only=True) == primary
            verify_report(fx.root/'report_0.json', primary)
            assert len(fx.sdk.requests) == after
            records.append({'repeat_id': repeat, 'status': 'PASS', 'points': 12,
                'mock_http_attempts': after-before, 'duplicate_independent': 12,
                'resume_and_verify_extra_http': 0, 'primary_and_upstream_unchanged': True})
            print('PASS: repeat mock', repeat, 'và resume/verify, primary nguyên byte', flush=True)
        assert all(p['confirmation_allowed'] is False for p in (primary,))
        destination = qa/'fixture_runtime'
        assert not destination.exists()
        shutil.copytree(fx.sdk.root, destination)
        return {'split': 'fixture', 'primary_points': 12, 'numeric_primary_only': True,
            'repeat': records, 'mock_http_attempts_total': len(fx.sdk.requests),
            'real_http_calls': 0, 'scientific_decision_calls': 0, 'confirmation_allowed': False}
    finally:
        fx.close()


real = real_metadata()
mock = fixture_runtime()
_write_once(qa/'dry_run_acceptance.json', {'acceptance_version': 'bic_icl_dry_run_acceptance_v1',
    'status': 'PASS', 'real_cached_metadata': real, 'synthetic_sdk_execution': mock,
    'nomination_performed': False, 'api_release_issued': False, 'confirmation_allowed': False})
print({'status': 'PASS', 'metadata_contracts': 804, 'mock_http_attempts': mock['mock_http_attempts_total'],
       'real_http_calls': 0}, flush=True)

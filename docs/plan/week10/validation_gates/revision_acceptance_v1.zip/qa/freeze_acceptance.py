"""Đóng băng nghiệm thu toàn revision sau bốn gate và dry-run offline."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile

root = Path.cwd()
qa = Path(__file__).parent
sys.path.insert(0, str(root))
from core.bic_icl_protocol import CohortSources, code_identity, read_authorization
from core.candidate_selection import read_technical_gates
from core.historical_signals import digest
from core.research_cohort import read_envelope
from core.research_input_lock import _write_once, runtime_identity


def sha(path: Path) -> str:
    """Băm byte thật của artifact và log."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy_once(source: Path, target: Path) -> None:
    """Bằng chứng đã tồn tại chỉ được chấp nhận khi cùng byte."""
    if target.exists():
        assert target.read_bytes() == source.read_bytes(), target
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(source.read_bytes())


baseline = json.loads((qa/'baseline.json').read_text('utf8'))
assert len(baseline) == 6711
assert all(sha(root/p) == value for p, value in baseline.items())
freeze = read_envelope(qa/'source_freeze.json')
assert freeze['code_sha256'] == code_identity()
assert freeze['runtime'] == runtime_identity()
assert all(hashlib.sha256((root/p).read_text('utf8').encode()).hexdigest() == value
           for p, value in freeze['gate_source_sha256'].items())
plan_path = root/freeze['plan']['path']
plan = read_envelope(plan_path)
assert sha(plan_path) == freeze['plan']['sha256'] and digest(plan) == freeze['plan']['payload_sha256']
assert plan_path.stat().st_mtime_ns == freeze['plan']['mtime_ns']
sources = CohortSources()
sources.validate(plan)

summary = json.loads((qa/'gates_final/summary.json').read_text('utf8'))
assert [r['gate'] for r in summary] == ['compileall', 'unit', 'e2e', 'leakage']
assert all(r['exit_code'] == 0 for r in summary)
assert (summary[1]['tests'], summary[1]['modules']) == (1083, 137)
assert (summary[3]['tests'], summary[3]['modules']) == (235, 38)
cli = json.loads((qa/'cli_acceptance.json').read_text('utf8'))
oracle = json.loads((qa/'oracle_result.json').read_text('utf8'))
dry = read_envelope(qa/'dry_run_acceptance.json')
assert cli['status'] == oracle['status'] == dry['status'] == 'PASS'
assert cli['plan_read_only_after_prepare'] and cli['llm_calls'] == 0
assert [r['exit_code'] for r in cli['commands']] == [0, 0, 0, 1]
assert oracle['points'] == 60 and oracle['sdk_contract_checks'] == 480
assert oracle['prior_off_canonical_checks'] == 117 and oracle['repeat_sample_checks'] == 12
assert oracle['context_lock_sha256'] == dry['real_cached_metadata']['context_lock_sha256']
assert dry['real_cached_metadata']['canonical_contract_checks'] == 804
assert dry['real_cached_metadata']['task_coverage_eligible'] is False
assert dry['synthetic_sdk_execution']['real_http_calls'] == 0
assert len(dry['synthetic_sdk_execution']['repeat']) == 3

target = root/'docs/plan/week10/validation_gates/revision_v1'
target.mkdir(parents=True, exist_ok=True)
copy_once(qa/'source_freeze.json', target/'source_freeze.json')
copy_once(qa/'dry_run_acceptance.json', target/'dry_run.json')
checks = {}
suite_results = {}
for gate in summary:
    name = gate['gate']
    if name in ('compileall', 'e2e'):
        source = qa/'gates_final'/f'{name}.log'
    else:
        inventory = json.loads((qa/f'gates_final/{name}_inventory.json').read_text('utf8'))
        assert inventory['expected'] == inventory['actual']
        results = sorted((json.loads(p.read_text('utf8'))
                          for p in (qa/'gates_final').glob(f'{name}_*.result.json')), key=lambda r: r['module'])
        assert len(results) == gate['modules']
        assert sum(r['run'] for r in results) == gate['tests']
        assert Counter(i for r in results for i in r['ids']) == Counter(inventory['expected'])
        assert all(r['success'] and r['run'] == r['expected']
                   and all(r[k] == 0 for k in ('failures', 'errors', 'skipped', 'expected_failures', 'unexpected_successes'))
                   for r in results)
        lines = ['Tổng hợp lần chạy hiện tại: bốn process, chia nguyên module, giữ thứ tự nội bộ.',
                 'Đã đối soát multiset ID với unittest discover, giữ nguyên bội số.',
                 'Log worker và inventory nguyên byte nằm trong revision_acceptance_v1.zip.',
                 'SHA-256 inventory: '+sha(qa/f'gates_final/{name}_inventory.json'),
                 'Số module: '+str(gate['modules'])]
        lines.extend(f"{r['module']}: PASS, {r['run']} tests, {r['elapsed_seconds']:.6f}s" for r in results)
        lines.extend(['', f"Ran {gate['tests']} tests in {gate['elapsed_seconds']:.6f}s", '', 'OK', ''])
        source = qa/f'{name}_aggregate.log'
        source.write_text('\n'.join(lines), encoding='utf8')
        suite_results[name] = {'tests': gate['tests'], 'modules': gate['modules'],
            'workers': 4, 'discovery_multiset_matches': True, 'failures': 0, 'errors': 0,
            'skips': 0, 'expected_failures': 0, 'unexpected_successes': 0}
    copy_once(source, target/f'{name}.log')
    checks[name] = {'status': 'PASS', 'exit_code': 0,
                   'log': {'path': f'{name}.log', 'sha256': sha(target/f'{name}.log')}}

gates_path = target/'technical_gates.json'
_write_once(gates_path, {'gate_version': 'research_technical_gates_v1',
    'code_sha256': plan['code_sha256'], 'runtime': plan['runtime'], 'checks': checks})
consumer = read_technical_gates(gates_path, plan)
assert consumer['status'] == 'PASS'
try:
    read_authorization(None, gates_path, plan)
except ValueError as error:
    assert 'Chưa có release development' in str(error)
else:
    raise AssertionError('Receipt gate tự mở release')

# Consumer phải từ chối receipt đúng log nhưng sai code/runtime.
for key, bad in (('code_sha256', {'wrong': 'a'*64}), ('runtime', {'python': '0.0.0'})):
    try:
        read_technical_gates(gates_path, {**plan, key: bad})
    except ValueError:
        pass
    else:
        raise AssertionError('Consumer nhận binding sai: '+key)

subprocess.run(['git', 'diff', '--check'], check=True)
integrity = {'status': 'PASS', 'old_files_unchanged': len(baseline), 'gate_source_files': 271,
    'runtime_dependency_files': 85, 'frozen_source_files': len(freeze['source_hashes']),
    'runtime_matches': True, 'plan_bytes_and_mtime_unchanged': True,
    'four_gate_receipt_consumer': consumer['status'], 'gate_receipt_is_not_release': True,
    'wrong_code_and_runtime_rejected': True, 'suites': suite_results}
(qa/'integrity.json').write_text(json.dumps(integrity, indent=2), encoding='utf8')

members = {}
for subdir in ('gates_final', 'fixture_runtime'):
    for path in (qa/subdir).rglob('*'):
        if path.is_file():
            members['qa/'+path.relative_to(qa).as_posix()] = path
for path in qa.iterdir():
    if path.is_file() and path.suffix in ('.py', '.json', '.log'):
        members['qa/'+path.name] = path
for path in target.iterdir():
    assert path.is_file()
    members[path.relative_to(root).as_posix()] = path
members[plan_path.relative_to(root).as_posix()] = plan_path
attributes = root/'docs/plan/week10/validation_gates/.gitattributes'
members[attributes.relative_to(root).as_posix()] = attributes
# Lưu đúng byte source đã kiểm; hash LF chỉ dành cho binding code.
for name in freeze['gate_source_sha256']:
    members['source/'+name] = root/name
manifest = {'version': 'bic_icl_revision_acceptance_v1', 'base_commit': freeze['base_commit'],
    'gate_summary': summary, 'integrity': integrity,
    'files': {name: sha(path) for name, path in sorted(members.items())},
    'api_release_issued': False, 'confirmation_allowed': False}
archive_path = target.parent/'revision_acceptance_v1.zip'
with zipfile.ZipFile(archive_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(members.items()):
        archive.writestr(name, path.read_bytes())
    archive.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2).encode())
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(manifest['files'])+1
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == value for name, value in manifest['files'].items())
    entries = len(archive.namelist())
receipt = {'status': 'PASS', 'path': archive_path.relative_to(root).as_posix(), 'sha256': sha(archive_path),
    'bytes': archive_path.stat().st_size, 'entries': entries, 'technical_gates_sha256': sha(gates_path),
    'source_freeze_sha256': sha(target/'source_freeze.json'), 'dry_run_sha256': sha(target/'dry_run.json'),
    'unit': 1083, 'leakage': 235, 'old_files_unchanged': len(baseline), 'api_release_issued': False}
(qa/'archive_receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf8')
print(receipt, flush=True)

"""Kiểm oracle trên các biên đã khóa rồi đóng băng quyết định selection thật."""

from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import subprocess
import zipfile
from build_selection import policy

ROOT = Path.cwd(); QA = Path(__file__).parent
selection_path = ROOT / 'docs/plan/week11/development_selection_v1.json'
selection = json.loads(selection_path.read_text('utf8'))['payload']
rules = json.loads((ROOT / 'outputs/bayesian_benchmark/bic_icl_v2/development_plan_release_v2.json').read_text('utf8'))['payload']['protocol']['selection']
SYMBOLS = ('FPT', 'MWG', 'VCB', 'VNM')


def sha(p):
    """Hash byte artifact và công cụ QA, không chứa credential."""
    return hashlib.sha256(p.read_bytes()).hexdigest()


def template():
    """Fixture giả để kiểm rule, tách hoàn toàn khỏi input và Decision thật."""
    return [{'candidate_id': n, 'gates_passed': True, 'primary_complete': True, 'repeats_verified': True,
             'visible_by_symbol': dict(zip(SYMBOLS, (2, 2, 1, 1))),
             'two_tasks_by_symbol': dict(zip(SYMBOLS, (2, 2, 1, 1))),
             'delta_return_by_symbol_pp': dict.fromkeys(SYMBOLS, 1.),
             'delta_mdd_by_symbol_pp': dict.fromkeys(SYMBOLS, 1.), 'delta_vs_a_pp': 0.}
            for n in ('R_pool', 'R_task')]


cases, expected = {}, {}


def add(name, winner, mutate):
    """Kỳ vọng winner được ghi riêng để tránh hai implementation cùng sai."""
    f = template(); mutate(f); cases[name] = f; expected[name] = winner


def disable_task(f):
    f[1]['delta_return_by_symbol_pp'] = dict.fromkeys(SYMBOLS, -1.)


add('tie_same_D_same_MDD_pool', 'R_pool', lambda f: None)
add('no_promotable_no_fallback', None, lambda f: [x.update(delta_return_by_symbol_pp=dict.fromkeys(SYMBOLS, 0.)) for x in f])
add('D_strictly_positive', 'R_task', lambda f: f[0].update(delta_return_by_symbol_pp=dict.fromkeys(SYMBOLS, 0.)))
add('positive_symbols_strict_zero', 'R_task', lambda f: f[0].update(delta_return_by_symbol_pp=dict(zip(SYMBOLS, (2., 2., 0., 0.)))))
add('MDD_boundaries_inclusive', 'R_pool', lambda f: (disable_task(f), f[0].update(delta_mdd_by_symbol_pp=dict(zip(SYMBOLS, (5., 1., 1., 1.))))))
add('mean_MDD_above_boundary', None, lambda f: (disable_task(f), f[0].update(delta_mdd_by_symbol_pp=dict(zip(SYMBOLS, (5., 1., 1., 1.000000004))))))
add('max_MDD_above_boundary', None, lambda f: (disable_task(f), f[0].update(delta_mdd_by_symbol_pp=dict(zip(SYMBOLS, (5.000000001, -2., -2., -2.))))))
add('versus_A_zero_inclusive', 'R_pool', lambda f: disable_task(f))
add('versus_A_negative_reject', None, lambda f: (disable_task(f), f[0].update(delta_vs_a_pp=-1e-12)))
add('visible_total_below_six', None, lambda f: (disable_task(f), f[0].update(visible_by_symbol=dict(zip(SYMBOLS, (2, 1, 1, 1))))))
add('visible_each_symbol_missing', None, lambda f: (disable_task(f), f[0].update(visible_by_symbol=dict(zip(SYMBOLS, (6, 0, 1, 1))))))
add('task_total_below_six', None, lambda f: (f[0].update(delta_return_by_symbol_pp=dict.fromkeys(SYMBOLS, -1.)), f[1].update(two_tasks_by_symbol=dict(zip(SYMBOLS, (2, 1, 1, 1))))))
add('task_each_symbol_missing', None, lambda f: (f[0].update(delta_return_by_symbol_pp=dict.fromkeys(SYMBOLS, -1.)), f[1].update(two_tasks_by_symbol=dict(zip(SYMBOLS, (4, 0, 1, 1))))))
add('gates_missing', None, lambda f: [x.update(gates_passed=False) for x in f])
add('primary_incomplete', None, lambda f: [x.update(primary_complete=False) for x in f])
add('repeat_missing', None, lambda f: [x.update(repeats_verified=False) for x in f])
add('tie_inclusive_at_one_e_minus_nine', 'R_pool', lambda f: (f[0].update(delta_mdd_by_symbol_pp=dict.fromkeys(SYMBOLS, 0.)), f[1].update(delta_return_by_symbol_pp=dict.fromkeys(SYMBOLS, 1.000000001))))
add('outside_D_tie_choose_larger', 'R_task', lambda f: (f[0].update(delta_mdd_by_symbol_pp=dict.fromkeys(SYMBOLS, 0.)), f[1].update(delta_return_by_symbol_pp=dict.fromkeys(SYMBOLS, 1.0000000011))))
add('equal_D_lower_MDD_task', 'R_task', lambda f: f[1].update(delta_mdd_by_symbol_pp=dict.fromkeys(SYMBOLS, .5)))
path = QA / 'boundary_fixtures.json'
path.write_text(json.dumps(cases, indent=2, allow_nan=False), encoding='utf8')
oracle = json.loads(subprocess.check_output(['py', '-3.13', '-X', 'utf8', str(QA / 'oracle.py'), '--fixtures', str(path)], text=True, encoding='utf8'))
for name, facts in cases.items():
    actual = policy(facts, rules)
    other = oracle[name]
    assert actual['status'] == other['status'] and actual['selected_candidate'] == other['selected_candidate'], name
    for candidate, values in actual['candidates'].items():
        independent = other['candidates'][candidate]
        for key in ('eligibility_conditions', 'promotion_conditions', 'eligible', 'promotable'):
            assert values[key] == independent[key], (name, candidate, key)
        for key in ('D_pp', 'mean_delta_mdd_pp', 'max_delta_mdd_pp'):
            assert math.isclose(values[key], independent[key], abs_tol=1e-12, rel_tol=0), (name, candidate, key)
    assert actual['selected_candidate'] == expected[name], (name, actual, expected[name])
invalid = template(); invalid[0]['candidate_id'] = 'R_pool_stats_only'
try:
    policy(invalid, rules)
except AssertionError:
    pass
else:
    raise AssertionError('Producer nhận ablation làm candidate')
invalid_path = QA / 'invalid_candidate_fixture.json'
invalid_path.write_text(json.dumps({'excluded_ablation': invalid}, indent=2), encoding='utf8')
rejected = subprocess.run(['py', '-3.13', '-X', 'utf8', str(QA / 'oracle.py'), '--fixtures', str(invalid_path)], capture_output=True)
assert rejected.returncode != 0
assert selection['status'] == 'STOP_NO_IMPROVEMENT' and selection['selected_candidate'] is None
assert selection['eligible_candidates'] == ['R_pool'] and selection['promotable_candidates'] == []
assert not selection['confirmation_allowed'] and not selection['new_confirmation_release_allowed']
for n, h in selection['binding']['files_sha256'].items():
    assert sha(ROOT / n) == h, n
assert sha(QA / 'build_selection.py') == selection['binding']['producer_sha256']
assert sha(QA / 'oracle.py') == selection['binding']['oracle_sha256']
baseline = json.loads((QA / 'baseline.json').read_text('utf8'))
assert all(sha(ROOT / n) == h for n, h in baseline.items())
summary = {'status': 'PASS', 'real_selection': selection['status'], 'selected_candidate': None,
           'independent_actual_oracle': 'PASS', 'boundary_fixtures': len(cases),
           'excluded_ablation_rejected_by_both': True, 'numeric_tolerance_pp': 1e-9,
           'selection_sha256': sha(selection_path), 'preserved_files': len(baseline),
           'suites_rerun': False, 'new_api_calls': 0, 'code_runtime_changed': False}
(QA / 'qa.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf8')
members = {'qa/' + n: QA / n for n in ('build_selection.py', 'oracle.py', 'check_fixtures_and_freeze.py',
           'baseline.json', 'producer_result.json', 'oracle_result.json', 'boundary_fixtures.json',
           'invalid_candidate_fixture.json', 'qa.json')}
members[selection_path.relative_to(ROOT).as_posix()] = selection_path
manifest = {'version': 'bic_icl_development_selection_freeze_v1', 'summary': summary,
            'files': {n: sha(p) for n, p in members.items()},
            'reproduce': 'Giải nén QA ngoài repo; từ root cùng workspace chạy py -3.13 -X utf8 <qa>/build_selection.py. Producer dựng lại và chỉ nhận selection cũ nếu payload/binding còn khớp; oracle đọc giá/action độc lập. Fixture không là thực nghiệm.'}
target = ROOT / 'docs/plan/week11/validation_gates/development_selection_v1.zip'
with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n, p in members.items(): z.writestr(n, p.read_bytes())
    z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2).encode())
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == len(members) + 1
    assert all(hashlib.sha256(z.read(n)).hexdigest() == h for n, h in manifest['files'].items())
assert all(sha(ROOT / n) == h for n, h in baseline.items())
receipt = {'status': 'PASS', 'path': target.relative_to(ROOT).as_posix(), 'sha256': sha(target),
           'entries': len(members) + 1, 'bytes': target.stat().st_size, 'summary': summary}
(QA / 'archive_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps(receipt, ensure_ascii=False), flush=True)

"""Oracle stdlib độc lập: tự ghép vốn Decimal từ giá/action và dùng ngưỡng đăng ký trước."""

from decimal import Decimal, getcontext
import hashlib
import json
import math
from pathlib import Path
import sys

getcontext().prec = 45
ROOT = Path.cwd()
RUN = ROOT / 'outputs/bayesian_benchmark/bic_icl_v2/development_run_release_v2'
STOCKS = ('FPT', 'MWG', 'VCB', 'VNM')


def policy(facts):
    """Predicate độc lập với producer; chỉ hai full, không fallback sang eligible thua."""
    output = {}
    for f in facts:
        name = f['candidate_id']
        assert name in ('R_pool', 'R_task') and name not in output
        vals = list(f['delta_return_by_symbol_pp'].values())
        mdds = list(f['delta_mdd_by_symbol_pp'].values())
        D = sum(vals) / 4
        mean_mdd = sum(mdds) / 4
        max_mdd = max(mdds)
        e = {'technical_gates_pass': f['gates_passed'], 'primary_60_complete': f['primary_complete'],
             'finite_return_mdd': all(math.isfinite(v) for v in vals + mdds + [f['delta_vs_a_pp']]),
             'visible_total_ge_6': sum(f['visible_by_symbol'].values()) >= 6,
             'visible_each_symbol_ge_1': min(f['visible_by_symbol'].values()) >= 1,
             'three_repeats_verified': f['repeats_verified']}
        if name == 'R_task':
            e['task_two_total_ge_6'] = sum(f['two_tasks_by_symbol'].values()) >= 6
            e['task_two_each_symbol_ge_1'] = min(f['two_tasks_by_symbol'].values()) >= 1
        p = {'D_positive': D > 0, 'positive_symbols_ge_3': sum(v > 0 for v in vals) >= 3,
             'mean_delta_mdd_le_2': mean_mdd <= 2, 'max_delta_mdd_le_5': max_mdd <= 5,
             'D_vs_A_ge_0': f['delta_vs_a_pp'] >= 0}
        output[name] = {'D_pp': float(D), 'mean_delta_mdd_pp': float(mean_mdd), 'max_delta_mdd_pp': float(max_mdd),
                        'eligibility_conditions': e, 'promotion_conditions': p,
                        'eligible': all(e.values()), 'promotable': all(e.values()) and all(p.values())}
    winners = [n for n in output if output[n]['promotable']]
    chosen = None
    if winners:
        best = max(output[n]['D_pp'] for n in winners)
        tied = [n for n in winners if Decimal(str(best)) - Decimal(str(output[n]['D_pp'])) <= Decimal('0.000000001')]
        chosen = min(tied, key=lambda n: (output[n]['mean_delta_mdd_pp'], n != 'R_pool'))
    return {'candidates': output, 'selected_candidate': chosen,
            'status': 'SELECTED' if chosen else 'STOP_NO_IMPROVEMENT'}


def account(rows, name):
    """Tự tính cổ phiếu lẻ/phí/trượt giá, giữ CASH và drawdown từng chu kỳ."""
    capital = peak = Decimal(50000000)
    mdd = Decimal(0)
    for row in rows:
        decision = row['branches'][name]['decision']['action']
        assert decision in ('LONG', 'SHORT')
        if decision == 'LONG':
            e = row['evaluation']
            shares = capital / (e['entry_open'] * 1000 * Decimal('1.001') * Decimal('1.0025'))
            capital = shares * e['exit_close'] * 1000 * Decimal('0.999') * Decimal('0.9975')
        peak = max(peak, capital)
        mdd = max(mdd, (peak - capital) / peak * 100)
    return ((capital / Decimal(50000000) - 1) * 100, mdd)


def actual():
    """Không nhập producer/engine/analysis; đọc lại giá/action và prefix request frozen."""
    reports = {i: json.loads((RUN / f'report_{i}.json').read_text('utf8'), parse_float=Decimal)['payload'] for i in range(4)}
    plan = json.loads((RUN.parent / 'development_plan_release_v2.json').read_text('utf8'), parse_float=Decimal)['payload']
    locked = {'prior_visible_total': 6, 'prior_visible_per_symbol': 1, 'task_two_groups_total': 6,
              'task_two_groups_per_symbol': 1, 'positive_symbols': 3, 'mean_delta_mdd_max_pp': 2,
              'max_delta_mdd_max_pp': 5, 'delta_vs_a_min_pp': 0,
              'tie_tolerance_pp': Decimal('0.000000001'), 'tie': ['LOWER_MEAN_DELTA_MDD', 'R_pool']}
    assert plan['protocol']['selection'] == locked
    assert plan['protocol']['nomination_order'] == ['R_pool', 'R_task']
    rows = reports[0]['points']
    assert [r['point_id'] for r in rows] == [r['point_id'] for r in plan['schedule']]
    complete = len(rows) == 60 and reports[0]['status'] == 'COMPLETE' and all(
        r['context']['as_of_date'].startswith('2023-') and all(b['status'] == 'complete' for b in r['branches'].values()) for r in rows)
    gates_path = ROOT / 'docs/plan/week11/validation_gates/development_v1/technical_gates.json'
    receipt = json.loads(gates_path.read_text('utf8'))['payload']
    gates = all(c['status'] == 'PASS' and c['exit_code'] == 0 and
                hashlib.sha256((gates_path.parent / c['log']['path']).read_bytes()).hexdigest() == c['log']['sha256']
                for c in receipt['checks'].values()) and set(receipt['checks']) == {'compileall', 'unit', 'e2e', 'leakage'}
    lock = json.loads((RUN / 'context_lock.json').read_text('utf8'))['payload']
    ids = [r['point_id'] for r in lock['repeat_sample']]
    repeats = all(reports[i]['status'] == 'COMPLETE' and [r['point_id'] for r in reports[i]['points']] == ids
                  and all(b['status'] == 'complete' for r in reports[i]['points'] for b in r['branches'].values())
                  for i in (1, 2, 3))
    facts = []
    for name in ('R_pool', 'R_task'):
        visible, two, deltas, mdds, versus_a = {}, {}, {}, {}, []
        for s in STOCKS:
            stock_rows = [r for r in rows if r['context']['symbol'] == s]
            assert len(stock_rows) == (12 if s == 'FPT' else 16)
            candidate, orig, reference = (account(stock_rows, n) for n in (name + '_full', 'original', 'A_reference_shared_off'))
            deltas[s], mdds[s] = candidate[0] - orig[0], candidate[1] - orig[1]
            versus_a.append(candidate[0] - reference[0])
            packets = [json.loads((RUN / 'packets' / (r['point_id'] + '.json')).read_text('utf8'))['payload'] for r in stock_rows]
            visible[s] = sum(bool(p['requests'][name + '_full']['prefix']) for p in packets)
            two[s] = sum(len(p['evidence']['content_views']['R_task']['full_prior']['visible_task_ids']) >= 2 for p in packets)
        facts.append({'candidate_id': name, 'gates_passed': gates, 'primary_complete': complete,
                      'repeats_verified': repeats, 'visible_by_symbol': visible, 'two_tasks_by_symbol': two,
                      'delta_return_by_symbol_pp': deltas, 'delta_mdd_by_symbol_pp': mdds,
                      'delta_vs_a_pp': sum(versus_a) / 4})
    return {'decision': policy(facts), 'facts': facts}


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--fixtures':
        cases = json.loads(Path(sys.argv[2]).read_text('utf8'), parse_float=Decimal)
        result = {name: policy(facts) for name, facts in cases.items()}
    else:
        result = actual()
    print(json.dumps(result, ensure_ascii=False, allow_nan=False,
                     default=lambda value: float(value) if isinstance(value, Decimal) else str(value)))

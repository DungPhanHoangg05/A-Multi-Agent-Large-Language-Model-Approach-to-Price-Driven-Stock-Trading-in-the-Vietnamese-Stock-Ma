"""Khóa selection từ report frozen và rule preregistered; không sửa runtime hoặc gọi LLM."""

from copy import deepcopy
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path.cwd(); QA = Path(__file__).parent
sys.path.insert(0, str(ROOT))
from core.bic_icl_protocol import code_identity, protocol
from core.candidate_selection import read_technical_gates
from core.historical_signals import digest
from core.research_cohort import read_envelope
from core.research_input_lock import _write_once, runtime_identity

RUN = ROOT / 'outputs/bayesian_benchmark/bic_icl_v2/development_run_release_v2'
PLAN = RUN.parent / 'development_plan_release_v2.json'
GATES = ROOT / 'docs/plan/week11/validation_gates/development_v1/technical_gates.json'
TARGET = ROOT / 'docs/plan/week11/development_selection_v1.json'
SYMBOLS = ('FPT', 'MWG', 'VCB', 'VNM')
ORDER = ('R_pool', 'R_task')


def sha(p):
    """Hash byte bằng chứng, không đọc credential."""
    return hashlib.sha256(p.read_bytes()).hexdigest()


def policy(facts, rules):
    """Áp riêng eligibility/promotion và chỉ xếp các candidate promotable."""
    assert [f['candidate_id'] for f in facts] == list(ORDER)
    out = {}
    for f in facts:
        name = f['candidate_id']; v = f['delta_return_by_symbol_pp']; m = f['delta_mdd_by_symbol_pp']
        D = math.fsum(v.values()) / 4
        mean_mdd = math.fsum(m.values()) / 4
        max_mdd = max(m.values())
        eligible = {'technical_gates_pass': f['gates_passed'], 'primary_60_complete': f['primary_complete'],
            'finite_return_mdd': all(math.isfinite(x) for x in [*v.values(), *m.values(), f['delta_vs_a_pp']]),
            'visible_total_ge_6': sum(f['visible_by_symbol'].values()) >= rules['prior_visible_total'],
            'visible_each_symbol_ge_1': all(x >= rules['prior_visible_per_symbol'] for x in f['visible_by_symbol'].values()),
            'three_repeats_verified': f['repeats_verified']}
        if name == 'R_task':
            eligible.update(task_two_total_ge_6=sum(f['two_tasks_by_symbol'].values()) >= rules['task_two_groups_total'],
                task_two_each_symbol_ge_1=all(x >= rules['task_two_groups_per_symbol'] for x in f['two_tasks_by_symbol'].values()))
        promote = {'D_positive': D > 0,
            'positive_symbols_ge_3': sum(x > 0 for x in v.values()) >= rules['positive_symbols'],
            'mean_delta_mdd_le_2': mean_mdd <= rules['mean_delta_mdd_max_pp'],
            'max_delta_mdd_le_5': max_mdd <= rules['max_delta_mdd_max_pp'],
            'D_vs_A_ge_0': f['delta_vs_a_pp'] >= rules['delta_vs_a_min_pp']}
        out[name] = {'D_pp': D, 'mean_delta_mdd_pp': mean_mdd, 'max_delta_mdd_pp': max_mdd,
                     'eligibility_conditions': eligible, 'promotion_conditions': promote,
                     'eligible': all(eligible.values()), 'promotable': all(eligible.values()) and all(promote.values())}
    winners = [n for n in ORDER if out[n]['promotable']]
    selected = None
    if winners:
        top = max(out[n]['D_pp'] for n in winners)
        tied = [n for n in winners if Decimal(str(top)) - Decimal(str(out[n]['D_pp'])) <= Decimal(str(rules['tie_tolerance_pp']))]
        selected = sorted(tied, key=lambda n: (out[n]['mean_delta_mdd_pp'], ORDER.index(n)))[0]
    return {'candidates': out, 'selected_candidate': selected, 'status': 'SELECTED' if selected else 'STOP_NO_IMPROVEMENT'}


def main():
    """Kiểm binding, đối chiếu oracle riêng rồi mới ghi selection một lần."""
    analysis_zip = ROOT / 'docs/plan/week11/validation_gates/development_analysis_v1.zip'
    repeat_zip = ROOT / 'docs/plan/week11/validation_gates/development_repeats_v1.zip'
    assert sha(analysis_zip) == '3df42b45c1a0960da24f08a61b9bcc20494abbbbe517e307b44098f891ffff7d'
    assert sha(repeat_zip) == 'd124b09c85ee86d5656101b0118eeaed6dba553c84313668678d7f27371d0c30'
    with zipfile.ZipFile(analysis_zip) as z:
        assert z.testzip() is None
        index = json.loads(z.read('manifest.json'))
        assert all(hashlib.sha256(z.read(n)).hexdigest() == h for n, h in index['files'].items())
        analysis = json.loads(z.read('qa/analysis.json'))
        old = json.loads(z.read('qa/baseline.json'))
    names = set(old) | set(subprocess.check_output(['git', 'ls-files', '-z'], text=True).split('\0'))
    names -= {'', 'docs/plan/plan.md', 'docs/plan/week11/README.md'}
    names = {n for n in names if not Path(n).name.startswith('.env')}
    baseline = {n: sha(ROOT / n) for n in sorted(names)}
    (QA / 'baseline.json').write_text(json.dumps(baseline, indent=2), encoding='utf8')
    with zipfile.ZipFile(repeat_zip) as z:
        assert z.testzip() is None
        index = json.loads(z.read('manifest.json'))
        assert all(hashlib.sha256(z.read(n)).hexdigest() == h for n, h in index['files'].items())
        frozen = {n: h for n, h in index['files'].items() if not n.startswith('qa/')}
        assert all(sha(ROOT / n) == h for n, h in frozen.items())
        repeated_proof = index['summary']
    plan = read_envelope(PLAN)
    assert plan['protocol'] == protocol() and plan['protocol']['nomination_order'] == list(ORDER)
    assert plan['code_sha256'] == code_identity() and plan['runtime'] == runtime_identity()
    assert all(sha(ROOT / n) == h for n, h in plan['source_hashes'].items())
    gates = read_technical_gates(GATES, plan)
    assert gates['status'] == 'PASS'
    with zipfile.ZipFile(ROOT / 'docs/plan/week11/validation_gates/development_release_v1.zip') as z:
        freeze = json.loads(z.read('qa/source_freeze.json'))['payload']
        assert all(hashlib.sha256((ROOT / n).read_text('utf8').encode()).hexdigest() == h
                   for n, h in freeze['gate_source_sha256'].items())
    reports = {i: read_envelope(RUN / f'report_{i}.json') for i in range(4)}
    primary = reports[0]
    assert primary['repeat_id'] == 0 and primary['in_primary'] is True and primary['status'] == 'COMPLETE'
    assert [p['point_id'] for p in primary['points']] == [p['point_id'] for p in plan['schedule']]
    assert primary['matrix'] == plan['protocol']['development_matrix']
    assert all(p['context']['as_of_date'].startswith('2023-') and p['evaluation'] is not None
               and all(b['status'] == 'complete' for b in p['branches'].values()) for p in primary['points'])
    lock = read_envelope(RUN / 'context_lock.json')
    sample = [p['point_id'] for p in lock['repeat_sample']]
    assert len(set(sample)) == 12
    for i, report in reports.items():
        assert report['status'] == 'COMPLETE' and report['repeat_id'] == i
        assert report['binding']['code_sha256'] == plan['code_sha256'] and report['binding']['runtime'] == plan['runtime']
        assert all(sha(RUN / n) == h for n, h in report['binding']['checkpoint_sha256'].items())
        if i:
            assert [p['point_id'] for p in report['points']] == sample
            assert all(s['common_count'] == s['planned_count'] == 3 and s['excluded_point_ids'] == [] for s in report['stocks'].values())
    verified = repeated_proof['status'] == 'VERIFIED_COMPLETE' and [r['repeat_id'] for r in repeated_proof['cli_verifications']] == [1, 2, 3]
    assert verified and all(r['exit_code'] == 0 for r in repeated_proof['cli_verifications'])
    facts = []
    for name in ORDER:
        visible, two, delta, mdd, delta_a = {}, {}, {}, {}, {}
        for s in SYMBOLS:
            stock = primary['stocks'][s]; count = 12 if s == 'FPT' else 16
            assert stock['planned_count'] == stock['common_count'] == count and stock['excluded_point_ids'] == []
            a, o, ref = (stock['metrics'][n]['account_metrics'] for n in (name + '_full', 'original', 'A_reference_shared_off'))
            assert all(math.isfinite(x) for a0 in (a, o, ref) for x in (a0['total_return_pct'], a0['max_drawdown_pct']))
            delta[s] = a['total_return_pct'] - o['total_return_pct']
            mdd[s] = a['max_drawdown_pct'] - o['max_drawdown_pct']
            delta_a[s] = a['total_return_pct'] - ref['total_return_pct']
            packets = [read_envelope(RUN / 'packets' / (p['point_id'] + '.json')) for p in primary['points'] if p['context']['symbol'] == s]
            views = [p['evidence']['content_views'][name]['full_prior'] for p in packets]
            visible[s] = sum(bool(v['visible_metric_ids'] or v['visible_example_ids']) for v in views)
            two[s] = sum(p['evidence']['gate']['R_task']['examples_ready']
                         and p['evidence']['task_selection']['metadata']['k_tasks'] >= 2 for p in packets)
            assert visible[s] == analysis['coverage'][name][s]['visible']
        facts.append({'candidate_id': name, 'gates_passed': True, 'primary_complete': True,
                      'repeats_verified': verified, 'visible_by_symbol': visible, 'two_tasks_by_symbol': two,
                      'delta_return_by_symbol_pp': delta, 'delta_mdd_by_symbol_pp': mdd,
                      'delta_vs_a_pp': math.fsum(delta_a.values()) / 4})
    result = policy(facts, plan['protocol']['selection'])
    raw = subprocess.check_output(['py', '-3.13', '-X', 'utf8', str(QA / 'oracle.py')], text=True, encoding='utf8')
    oracle = json.loads(raw)
    (QA / 'oracle_result.json').write_text(json.dumps(oracle, ensure_ascii=False, indent=2), encoding='utf8')
    assert result['status'] == oracle['decision']['status'] and result['selected_candidate'] == oracle['decision']['selected_candidate']
    for f, independent in zip(facts, oracle['facts']):
        assert f['candidate_id'] == independent['candidate_id']
        for key in ('visible_by_symbol', 'two_tasks_by_symbol'):
            assert f[key] == independent[key]
        for key in ('delta_return_by_symbol_pp', 'delta_mdd_by_symbol_pp'):
            assert all(math.isclose(f[key][s], independent[key][s], abs_tol=1e-9, rel_tol=0) for s in SYMBOLS)
        assert math.isclose(f['delta_vs_a_pp'], independent['delta_vs_a_pp'], abs_tol=1e-9, rel_tol=0)
        name = f['candidate_id']
        for key in ('eligibility_conditions', 'promotion_conditions', 'eligible', 'promotable'):
            assert result['candidates'][name][key] == oracle['decision']['candidates'][name][key]
        for key in ('D_pp', 'mean_delta_mdd_pp', 'max_delta_mdd_pp'):
            assert math.isclose(result['candidates'][name][key], oracle['decision']['candidates'][name][key], abs_tol=1e-9, rel_tol=0)
    for f in facts:
        c = result['candidates'][f['candidate_id']]
        c['facts'] = f
        c['eligibility_failure_reasons'] = [k for k, passed in c['eligibility_conditions'].items() if not passed]
        c['promotion_failure_reasons'] = [k for k, passed in c['promotion_conditions'].items() if not passed]
    (QA / 'producer_result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf8')
    assert result['status'] == 'STOP_NO_IMPROVEMENT' and result['selected_candidate'] is None
    rules = {**deepcopy(plan['protocol']['selection']), 'candidate_order': list(ORDER),
             'primary_counts': {'FPT': 12, 'MWG': 16, 'VCB': 16, 'VNM': 16},
             'D_vs_original_strictly_positive': True, 'repeat_in_primary': False,
             'selection_population': 'ELIGIBLE_AND_PROMOTABLE_ONLY',
             'no_promotable_status': 'STOP_NO_IMPROVEMENT'}
    binding_paths = [PLAN, GATES, ROOT / 'docs/plan/week10/method_protocol_v1.md',
                     ROOT / 'docs/plan/week11/development_release_v1.json', analysis_zip, repeat_zip,
                     ROOT / 'outputs/oos_pilot/api_usage.json', *(RUN / f'report_{i}.json' for i in range(4)),
                     RUN / 'cohort.json', RUN / 'context_lock.json', RUN / 'request_manifest.json']
    payload = {'selection_version': 'bic_icl_development_selection_v1', 'split': 'development_2023',
        'status': result['status'], 'selected_candidate': result['selected_candidate'],
        'eligible_candidates': [n for n in ORDER if result['candidates'][n]['eligible']],
        'promotable_candidates': [n for n in ORDER if result['candidates'][n]['promotable']],
        'candidates': result['candidates'], 'rules': rules, 'risk_policy': 'OFF', 'selected_lambda': 8,
        'deployment_choice': 'original', 'development_closed': True, 'confirmation_allowed': False,
        'new_confirmation_release_allowed': False, 'selection_evaluated': True,
        'continuation': {'confirmation': 'NOT_APPLICABLE_NO_PROMOTABLE_CANDIDATE',
                         'more_development_tuning_allowed': False, 'legacy_evidence_preserved': True,
                         'holdout_2025_outcomes_opened': False},
        'verification': {'independent_decimal_oracle': 'PASS', 'technical_gates': gates,
                         'repeat_verification': 'W11-03_VERIFIED_COMPLETE', 'suites_rerun': False, 'new_api_calls': 0},
        'binding': {'files_sha256': {p.relative_to(ROOT).as_posix(): sha(p) for p in binding_paths},
                    'plan_payload_sha256': digest(plan), 'method_sha256': plan['method_sha256'],
                    'protocol_sha256': digest(plan['protocol']), 'code_sha256': plan['code_sha256'], 'runtime': plan['runtime'],
                    'run_signature': primary['binding']['run_signature'],
                    'producer_sha256': sha(QA / 'build_selection.py'), 'oracle_sha256': sha(QA / 'oracle.py')}}
    assert all(sha(ROOT / n) == h for n, h in baseline.items())
    _write_once(TARGET, payload)
    assert read_envelope(TARGET) == payload
    print(json.dumps({'status': payload['status'], 'selected_candidate': None, 'oracle': 'PASS',
        'preserved_files': len(baseline), 'path': TARGET.relative_to(ROOT).as_posix(), 'sha256': sha(TARGET),
        'candidates': result['candidates']}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()

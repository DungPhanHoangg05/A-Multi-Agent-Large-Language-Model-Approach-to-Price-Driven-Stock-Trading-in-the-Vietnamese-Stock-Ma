"""Nghiệm thu primary thật bằng consumer hiện hữu, không credential/HTTP hoặc sửa source."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

root=Path.cwd()
qa=Path(__file__).parent
sys.path.insert(0,str(root))
from core.bic_icl_protocol import code_identity
from core.candidate_selection import read_technical_gates
from core.historical_signals import digest
from core.research_cohort import read_envelope
from core.research_input_lock import runtime_identity

def sha(path: Path) -> str:
    """Kiểm byte artifact thực, không dùng checksum tự khai."""
    return hashlib.sha256(path.read_bytes()).hexdigest()

plan_path=root/'outputs/bayesian_benchmark/bic_icl_v2/development_plan_release_v2.json'
run=root/'outputs/bayesian_benchmark/bic_icl_v2/development_run_release_v2'
report_path=run/'report_0.json'
release_path=root/'docs/plan/week11/development_release_v1.json'
gate_path=root/'docs/plan/week11/validation_gates/development_v1/technical_gates.json'
ledger_path=root/'outputs/oos_pilot/api_usage.json'
baseline=json.loads((qa/'baseline.json').read_text('utf8'))
assert all(sha(root/n)==h for n,h in baseline.items())
args=['py','-3.13','-X','utf8','scripts/run_bic_icl.py','--verify-report',
    '--plan',str(plan_path),'--output-dir',str(run),'--env-file',str(qa/'absent.env')]
log=qa/'verify_report.log'
print('Đang chạy verifier report chính thức, transport từ chối mạng...',flush=True)
with log.open('wb') as stream:
    result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
content=log.read_text('utf-8-sig')
assert result.returncode==0,(result.returncode,content[-3000:])
assert json.loads(content.strip().splitlines()[-1])=={'status':'COMPLETE','repeat_id':0,'confirmation_allowed':False}
print('CLI --verify-report: PASS; đang đối soát inventory và nguồn đã khóa...',flush=True)
assert all(sha(root/n)==h for n,h in baseline.items())
plan,release,report=read_envelope(plan_path),read_envelope(release_path),read_envelope(report_path)
lock=read_envelope(run/'context_lock.json')
requests=read_envelope(run/'request_manifest.json')
assert plan['code_sha256']==code_identity() and plan['runtime']==runtime_identity()
assert read_technical_gates(gate_path,plan)['status']=='PASS'
previous=root/'docs/plan/week11/validation_gates/development_release_v1.zip'
with zipfile.ZipFile(previous) as archive:
    frozen=json.loads(archive.read('qa/source_freeze.json'))['payload']
    assert all(hashlib.sha256((root/n).read_text('utf8').encode()).hexdigest()==h
        for n,h in frozen['gate_source_sha256'].items())
    for p in (plan_path,release_path,gate_path):
        assert p.read_bytes()==archive.read(p.relative_to(root).as_posix())
assert all(sha(run/n)==h for n,h in release['snapshot_sha256'].items())
assert report['status']=='COMPLETE' and report['repeat_id']==0 and report['in_primary'] is True
assert report['nomination_performed'] is False and report['confirmation_allowed'] is False
assert [p['point_id'] for p in report['points']]==[p['point_id'] for p in plan['schedule']]
assert report['matrix']==[*lock['matrix'],'Numeric_only'] and len(report['matrix'])==9
assert len(report['points'])==60 and all(p['evaluation'] is not None for p in report['points'])
expected_counts={'FPT':12,'MWG':16,'VCB':16,'VNM':16}
for s,count in expected_counts.items():
    stock=report['stocks'][s]
    assert stock['planned_count']==stock['common_count']==count and stock['excluded_point_ids']==[]
assert report['binding']['plan_sha256']==digest(plan)==release['plan_sha256']
assert report['binding']['context_lock_sha256']==digest(lock)==release['decision_context_lock_sha256']
assert digest(requests)==release['request_manifest_sha256']
assert all(sha(run/n)==h for n,h in report['binding']['checkpoint_sha256'].items())
assert len(report['binding']['checkpoint_sha256'])==243
statuses=Counter();origins=Counter();attempt_ids=set();physical=0;scientific_resumes=0
for row in report['points']:
    block=read_envelope(run/'decision_blocks/0'/row['point_id']/'state.json')
    assert list(block['branches'])==[r['branch_id'] for r in block['binding']['requests']]
    for name,branch in block['branches'].items():
        statuses[branch['status']]+=1;origins[branch['decision_origin']]+=1
        assert branch['status']=='complete'
        scientific_resumes+=len(branch['resumes'])
        if branch['attempts']:
            assert len(branch['attempts'])==1
            aid=branch['attempts'][0]['attempt_id']
            assert aid not in attempt_ids
            attempt_ids.add(aid);physical+=1
        else:
            assert branch['decision_origin'] in ('shared_original','stats_alias') and branch['source'] is not None
    numeric=row['branches']['Numeric_only']
    assert numeric['status']=='complete' and numeric['scientific_attempt_count']==0
    assert numeric['decision_origin']=='numeric'
ledger=json.loads(ledger_path.read_text('utf8'))
signature=release['run_binding']['run_signature']
rows=[r for r in ledger['requests'] if r.get('run_signature')==signature]
assert len({r['id'] for r in rows})==len(rows)
assert {r['id']:digest(r) for r in rows}==report['binding']['http_record_sha256']
assert {r['checkpoint_attempt_id'] for r in rows}==attempt_ids
http_statuses=Counter(str(r['status']) for r in rows)
assert not any(r['status']=='unknown' for r in rows)
assert all(sum(r['status']==200 for r in rows if r['checkpoint_attempt_id']==aid)==1 for aid in attempt_ids)
successes=[r for r in rows if r['status']==200]
for r in successes:
    cached=run/'http_cache'/(r['id']+'.json')
    assert r['durable_response']=={'sha256':sha(cached)}
assert physical==317 and dict(origins)=={'llm':317,'stats_alias':46,'shared_original':117}
assert len(successes)==317 and sum(statuses.values())==480
assert not list(run.glob('report_[123].json'))
assert {p.name for p in (run/'decision_blocks').iterdir() if p.is_dir()}=={'0'}
preflight=ledger['preflight']
assert preflight['status']=='PASS' and preflight['plan_sha256']==digest(plan)
preflight_rows=[r for r in ledger['requests'] if r['id'] in preflight['request_ids']]
assert len(preflight_rows)==2 and all(r['status']==200 for r in preflight_rows)
assert {r['model'] for r in preflight_rows}=={'openai/gpt-oss-20b','qwen/qwen3.8-27b'}
assert all(r['credential_scope']==preflight['credential_scope'] for r in preflight_rows)
summary={'verification_version':'bic_icl_development_primary_verification_v1','status':'VERIFIED_COMPLETE',
    'verified_at':datetime.now(timezone.utc).isoformat(),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'command':args,'exit_code':result.returncode,'log_sha256':sha(log),
    'primary_points':60,'common_support':expected_counts,'excluded_points':[],
    'matrix':report['matrix'],'llm_logical_slots':480,'numeric_offline_slots':60,
    'slot_statuses':dict(statuses),'slot_origins':dict(origins),'scientific_attempts':physical,
    'scientific_resumes':scientific_resumes,'http_requests':len(rows),'http_statuses':dict(http_statuses),
    'unresolved_unknown':0,'successful_durable_cache_files':len(successes),
    'preflight_status':'PASS','source_runtime_gate_receipt':'PASS','reused_gate_tests':{'unit':1103,'leakage':249},
    'suites_rerun':False,'new_api_calls_by_agent':0,'preserved_files':len(baseline),
    'report_sha256':sha(report_path),'report_payload_sha256':digest(report),
    'run_signature':signature,'plan_sha256':sha(plan_path),'plan_payload_sha256':digest(plan),
    'release_sha256':sha(release_path),'technical_gates_sha256':sha(gate_path),
    'context_lock_sha256':digest(lock),'request_manifest_sha256':digest(requests),
    'ledger_snapshot_sha256':sha(ledger_path),'report_checkpoint_files':len(report['binding']['checkpoint_sha256']),
    'repeat_executed':False,'analysis_performed':False,'nomination_performed':False,'confirmation_allowed':False}
(qa/'primary_verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
members={}
for p in run.rglob('*'):
    if p.is_file() and p.suffix=='.json' and p.name not in ('run.owner.json','run.recovery.json'):
        members[p.relative_to(root).as_posix()]=p
for p in (plan_path,release_path,ledger_path,gate_path,root/'docs/plan/week11/.gitattributes'):
    members[p.relative_to(root).as_posix()]=p
for p in gate_path.parent.glob('*.log'):
    members[p.relative_to(root).as_posix()]=p
for name in ('baseline.json','verify_and_freeze.py','verify_report.log','primary_verification.json'):
    members['qa/'+name]=qa/name
manifest={'version':'bic_icl_development_primary_freeze_v1','summary':summary,
    'release_evidence':{'path':previous.relative_to(root).as_posix(),'sha256':sha(previous)},
    'files':{n:sha(p) for n,p in sorted(members.items())}}
target=root/'docs/plan/week11/validation_gates/development_primary_v1.zip'
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for n,p in sorted(members.items()):archive.writestr(n,p.read_bytes())
    archive.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist()))==len(members)+1
    assert all(hashlib.sha256(archive.read(n)).hexdigest()==h for n,h in manifest['files'].items())
assert all(sha(root/n)==h for n,h in baseline.items())
receipt={'status':'PASS','path':target.relative_to(root).as_posix(),'sha256':sha(target),
    'entries':len(members)+1,'bytes':target.stat().st_size,'summary':summary}
(qa/'archive_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(receipt,ensure_ascii=False),flush=True)

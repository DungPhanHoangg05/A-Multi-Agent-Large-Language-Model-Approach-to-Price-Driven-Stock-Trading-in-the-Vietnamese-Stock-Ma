"""Vẽ point estimate development, không thêm CI hoặc diễn giải thành selection."""

import json
from pathlib import Path
import unicodedata
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

qa = Path(__file__).parent
data = json.loads((qa / 'analysis.json').read_text('utf8'))
names = list(data['primary']['stocks']['FPT']['metrics'])
labels = {'original': 'Original', 'A_reference_shared_off': 'A reference',
          'R_pool_full': 'R_pool full', 'R_pool_stats_only': 'R_pool stats-only',
          'R_pool_examples_only': 'R_pool examples-only', 'R_task_full': 'R_task full',
          'R_task_stats_only': 'R_task stats-only', 'R_task_examples_only': 'R_task examples-only',
          'Numeric_only': 'Numeric_only'}
values = [0. if n == 'original' else data['contrasts'][n + '__original']['economics']['D_pp'] for n in names]
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11, 'svg.hashsalt': 'bic-development-analysis-v1'})
fig, ax = plt.subplots(figsize=(10.5, 6.2))
fig.subplots_adjust(left=.25, right=.94, top=.81, bottom=.18)
ax.barh(range(len(names)), values, color=['#6b7280' if n == 'original' else '#336a9f' if v >= 0 else '#b96939'
                                        for n, v in zip(names, values)], height=.62)
ax.set_yticks(range(len(names)), [labels[n] for n in names]); ax.invert_yaxis()
ax.axvline(0, color='#4b5563', linewidth=.9)
ax.set_xlim(-2.8, .9)
ax.set_xlabel(unicodedata.normalize('NFC', 'D = trung bình đều bốn chênh return tài khoản (điểm phần trăm)'))
ax.grid(axis='x', color='#e5e7eb', linewidth=.7); ax.set_axisbelow(True)
for i, v in enumerate(values):
    ax.text(v + (.05 if v >= 0 else -.05), i, f'{v:+.4f}', va='center', ha='left' if v >= 0 else 'right', fontsize=10)
for side in ('top', 'right', 'left'):
    ax.spines[side].set_visible(False)
fig.suptitle(unicodedata.normalize('NFC', 'Development 2023: chênh lệch return với Original'), y=.96, fontsize=15, weight='bold')
fig.text(.25, .875, unicodedata.normalize('NFC', 'G=60 điểm; FPT=12, MWG/VCB/VNM=16; hợp đồng T+2.5, risk OFF'), fontsize=10, color='#374151')
fig.text(.25, .055, unicodedata.normalize('NFC', 'Phân tích thăm dò; point estimate, chưa có CI. Repeat được báo riêng.\nStats/examples/Numeric không thuộc tập nomination.'), fontsize=9, color='#4b5563')
fig.savefig(qa / 'development_analysis_v1.png', dpi=180, metadata={'Software': 'Matplotlib'})
fig.savefig(qa / 'development_analysis_v1.svg', metadata={'Date': None})
plt.close(fig)
print('Đã vẽ PNG/SVG từ analysis.json, không đổi report hoặc source.', flush=True)

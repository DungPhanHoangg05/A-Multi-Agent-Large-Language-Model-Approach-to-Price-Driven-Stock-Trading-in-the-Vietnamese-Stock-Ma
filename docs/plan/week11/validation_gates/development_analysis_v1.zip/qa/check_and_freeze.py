"""Kiểm tra chéo bảng phân tích và đóng gói công cụ/bảng/biểu đồ cùng hash đầu vào."""

from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import zipfile

root = Path.cwd(); qa = Path(__file__).parent
d = json.loads((qa / 'analysis.json').read_text('utf8'))
baseline = json.loads((qa / 'baseline.json').read_text('utf8'))


def sha(p):
    """Hash byte cho bằng chứng và biểu đồ, không đọc credential."""
    return hashlib.sha256(p.read_bytes()).hexdigest()


assert d['status'] == 'COMPLETE' and not d['nomination_performed'] and not d['confirmation_allowed']
assert all(sha(root / n) == h for n, h in baseline.items())
assert all(sha(root / n) == h for n, h in d['input_sha256'].items())
run = root / 'outputs/bayesian_benchmark/bic_icl_v2/development_run_release_v2'
reports = {i: json.loads((run / f'report_{i}.json').read_text('utf8'))['payload'] for i in range(4)}
for name in reports[0]['matrix']:
    if name != 'original':
        value = d['contrasts'][name + '__original']['economics']['D_pp']
        assert math.isclose(value, reports[0]['delta_vs_original'][name]['mean_four_accounts_pp'], abs_tol=1e-12)
    counts = Counter(('UP_' if p['evaluation']['net_return_long'] > 0 else 'DOWN_') +
                     ('LONG' if p['branches'][name]['decision']['action'] == 'LONG' else 'CASH') for p in reports[0]['points'])
    c = d['classification_pooled_points'][name]
    assert c['confusion'] == dict(counts)
    assert sum(counts.values()) == 60
    assert d['failures'][name]['loss_making_long'] == counts['DOWN_LONG']
    assert d['failures'][name]['missed_profitable_long'] == counts['UP_CASH']
assert d['coverage']['R_pool']['ALL']['visible'] == 51
assert d['coverage']['R_task']['ALL']['visible'] == 48
assert d['coverage']['A_reference_shared_off']['ALL']['visible'] == 50
assert d['coverage']['R_task']['ALL']['visible_at_least_two_tasks'] == 3
assert d['coverage']['R_task']['FPT']['visible_at_least_two_tasks'] == 0
for base in ('R_pool', 'R_task'):
    t = [p for p in reports[0]['points'] if all(p['prior']['gate'][base][k] for k in ('stats_ready', 'examples_ready'))]
    assert [p['point_id'] for p in t] == d['ablation'][base]['T']['point_ids']
assert d['ablation']['R_pool']['T']['count'] == 36 and d['ablation']['R_task']['T']['count'] == 19
assert d['losses']['train_frozen_summary']['overall']['common_count'] == 598
assert d['losses']['development']['common'] == 58
assert set(d['losses']['development']['models']['A']['missing_ids']) == {'VNM-2023-03-30', 'FPT-2023-05-11'}
for name in ('A', 'R8'):
    assert sum(b['count'] for b in d['losses']['development']['models'][name]['bins']) == 58
assert d['subgroups']['regime']['BEAR']['count'] == 0
assert d['subgroups']['regime']['BEAR']['contrasts']['R_pool_full__original']['D_pp'] is None
assert d['subgroups']['quarter']['Q1']['contrasts']['R_task_full__original']['D_pp'] is None
for r in (1, 2, 3):
    assert d['repeat']['duplicates'][str(r)]['disagreement']['denominator'] == 12
    assert d['repeat']['duplicates'][str(r)]['disagreement']['numerator'] == 0
for v in d['repeat']['action_disagreement'].values():
    assert v['three_pairwise_repeats'] == {'numerator': 0, 'denominator': 36, 'value': 0.0}
chart = root / 'docs/plan/week11/development_analysis_v1.png'
assert not chart.exists()
shutil.copyfile(qa / chart.name, chart)
summary = {'status': 'PASS', 'checks': ['SOURCE_RUNTIME_RECEIPT', 'FROZEN_REPORTS', 'ACCOUNT_PAYOFF_MDD_ORACLE',
           'G_T_SUPPORT', 'LOSS_COMMON_MASK_BINS', 'CLASSIFICATION_CONFUSION', 'FAILURE_INVENTORY',
           'REPEAT_DENOMINATORS', 'EMPTY_GROUP_NULL', 'PRIOR_OFF_INVARIANCE', 'CHART_VISUAL_REVIEW'],
           'preserved_files': len(baseline), 'inputs': d['input_sha256'], 'analysis_sha256': sha(qa / 'analysis.json'),
           'chart_sha256': sha(chart), 'code_runtime_changed': False, 'suites_rerun': False,
           'agent_api_calls': 0, 'nomination_performed': False, 'confirmation_allowed': False}
(qa / 'qa.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf8')
members = {'qa/' + n: qa / n for n in ('analyze.py', 'chart.py', 'check_and_freeze.py', 'baseline.json',
            'analysis.json', 'qa.json', 'development_analysis_v1.png', 'development_analysis_v1.svg')}
index = {'version': 'bic_icl_development_analysis_freeze_v1', 'summary': summary,
         'files': {n: sha(p) for n, p in members.items()},
         'reproduce': 'Giải nén QA ngoài repo; từ root repo cùng workspace chạy py -3.13 -X utf8 <qa>/analyze.py, rồi <qa>/chart.py. Giữ nguyên nguồn ignored và các ZIP đã bind.'}
target = root / 'docs/plan/week11/validation_gates/development_analysis_v1.zip'
with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n, p in members.items(): z.writestr(n, p.read_bytes())
    z.writestr('manifest.json', json.dumps(index, ensure_ascii=False, indent=2).encode())
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == len(members) + 1
    assert all(hashlib.sha256(z.read(n)).hexdigest() == h for n, h in index['files'].items())
assert all(sha(root / n) == h for n, h in baseline.items())
receipt = {'status': 'PASS', 'path': target.relative_to(root).as_posix(), 'sha256': sha(target),
           'entries': len(members) + 1, 'bytes': target.stat().st_size, 'summary': summary}
(qa / 'archive_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps(receipt, ensure_ascii=False), flush=True)

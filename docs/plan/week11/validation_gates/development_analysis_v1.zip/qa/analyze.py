"""Phân tích mô tả development đã đóng băng; không thay code nghiên cứu hoặc chọn ứng viên."""

from collections import Counter
from datetime import datetime, timezone
from itertools import combinations
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import zipfile
import numpy as np

ROOT = Path.cwd()
QA = Path(__file__).parent
sys.path.insert(0, str(ROOT))
from core.bic_icl_protocol import code_identity
from core.bic_icl_diagnostics import score_rows
from core.candidate_selection import read_technical_gates
from core.historical_signals import digest
from core.improvement_reports import _metric
from core.research_cohort import read_envelope
from core.research_input_lock import runtime_identity

RUN = ROOT / 'outputs/bayesian_benchmark/bic_icl_v2/development_run_release_v2'
PLAN = RUN.parent / 'development_plan_release_v2.json'
ARCHIVE = ROOT / 'docs/plan/week11/validation_gates/development_repeats_v1.zip'
TRAIN = RUN.parent / 'train_v1/diagnostics.json'
SYMBOLS = ('FPT', 'MWG', 'VCB', 'VNM')


def sha(path):
    """Hash artifact theo byte, không đọc tệp credential."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def preserve():
    """Bảo toàn nguồn và bằng chứng cũ qua toàn lượt phân tích."""
    assert all(sha(ROOT / n) == h for n, h in baseline.items())


def ratio(n, d):
    """Nhóm rỗng có null và mẫu số rõ ràng."""
    return {'numerator': int(n), 'denominator': int(d), 'value': float(n / d) if d else None}


assert sha(ARCHIVE) == 'd124b09c85ee86d5656101b0118eeaed6dba553c84313668678d7f27371d0c30'
with zipfile.ZipFile(ARCHIVE) as archive:
    previous = json.loads(archive.read('qa/baseline.json'))
names = set(previous) | set(subprocess.check_output(['git', 'ls-files', '-z'], text=True).split('\0'))
names -= {'', 'docs/plan/plan.md', 'docs/plan/week11/README.md'}
names = {n for n in names if not Path(n).name.startswith('.env')}
baseline = {n: sha(ROOT / n) for n in sorted(names)}
(QA / 'baseline.json').write_text(json.dumps(baseline, indent=2), encoding='utf8')
assert sha(ARCHIVE) == 'd124b09c85ee86d5656101b0118eeaed6dba553c84313668678d7f27371d0c30'
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    index = json.loads(archive.read('manifest.json'))
    assert all(hashlib.sha256(archive.read(n)).hexdigest() == h for n, h in index['files'].items())
    frozen = {n: h for n, h in index['files'].items() if not n.startswith('qa/')}
    assert all(sha(ROOT / n) == h for n, h in frozen.items())
plan = read_envelope(PLAN)
assert plan['code_sha256'] == code_identity() and plan['runtime'] == runtime_identity()
assert all(sha(ROOT / n) == h for n, h in plan['source_hashes'].items())
gate = ROOT / 'docs/plan/week11/validation_gates/development_v1/technical_gates.json'
assert read_technical_gates(gate, plan)['status'] == 'PASS'
with zipfile.ZipFile(ROOT / 'docs/plan/week11/validation_gates/development_release_v1.zip') as archive:
    source_freeze = json.loads(archive.read('qa/source_freeze.json'))['payload']
    assert all(hashlib.sha256((ROOT / n).read_text('utf8').encode()).hexdigest() == h
               for n, h in source_freeze['gate_source_sha256'].items())
reports = {i: read_envelope(RUN / f'report_{i}.json') for i in range(4)}
assert all(r['status'] == 'COMPLETE' for r in reports.values())
primary = reports[0]['points']
packets = {p['point_id']: read_envelope(RUN / 'packets' / (p['point_id'] + '.json')) for p in primary}
lock = read_envelope(RUN / 'context_lock.json')
matrix = reports[0]['matrix']
sample = [p['point_id'] for p in lock['repeat_sample']]
assert len(sample) == 12 and len(primary) == 60
train = read_envelope(TRAIN)
assert train['summary'] == score_rows(train['points'])
assert train['summary']['selected_lambda'] == 8
print('Nguồn/report/train/receipt/hash PASS; bắt đầu dựng bảng mô tả.', flush=True)


def action(row, name):
    """SHORT được biểu diễn CASH ở mọi bảng hành động."""
    raw = row['branches'][name]['decision']['action']
    assert raw in ('LONG', 'SHORT')
    return 'LONG' if raw == 'LONG' else 'CASH'


def metric(rows, name):
    """Dùng engine hiện hữu và đối soát oracle vector hóa độc lập."""
    if not rows:
        return None
    result = _metric(rows, name)
    net = np.asarray([p['evaluation']['net_return_long'] for p in rows])
    entry = np.asarray([p['evaluation']['entry_open'] for p in rows])
    close = np.asarray([p['evaluation']['exit_close'] for p in rows])
    oracle_net = close * (1 - .001) * (1 - .0025) / (entry * (1 + .001) * (1 + .0025)) - 1
    assert np.allclose(net, oracle_net, atol=1e-14, rtol=0)
    long = np.asarray([action(p, name) == 'LONG' for p in rows])
    returns = np.where(long, net, 0.)
    path = np.r_[1., np.cumprod(1. + returns)]
    total, mdd = float((path[-1] - 1) * 100), float(np.max(1 - path / np.maximum.accumulate(path)) * 100)
    account = result['account_metrics']
    assert math.isclose(total, account['total_return_pct'], abs_tol=1e-9, rel_tol=0)
    assert math.isclose(mdd, account['max_drawdown_pct'], abs_tol=1e-9, rel_tol=0)
    assert np.allclose(account['period_returns'], returns, atol=1e-14, rtol=0)
    assert result['long_count'] == int(long.sum()) and result['sample_count'] == len(rows)
    return result


def group(rows, names):
    """G, T và subgroup đều ghép tài khoản riêng từng mã theo ngày gốc."""
    return {'point_ids': [p['point_id'] for p in rows], 'count': len(rows),
            'stocks': {s: {'count': sum(p['context']['symbol'] == s for p in rows),
                'metrics': {n: metric([p for p in rows if p['context']['symbol'] == s], n) for n in names}}
                for s in SYMBOLS}}


def contrast(g, a, b):
    """D dùng đều bốn tài khoản; thiếu một mã giữ null, không bù bằng zero."""
    per = {}
    for s in SYMBOLS:
        ma, mb = (g['stocks'][s]['metrics'][n] for n in (a, b))
        per[s] = None if ma is None or mb is None else {
            'delta_return_pp': float(ma['account_metrics']['total_return_pct'] - mb['account_metrics']['total_return_pct']),
            'delta_mdd_pp': float(ma['account_metrics']['max_drawdown_pct'] - mb['account_metrics']['max_drawdown_pct'])}
    complete = all(v is not None for v in per.values())
    return {'per_symbol': per, 'D_pp': float(sum(v['delta_return_pp'] for v in per.values()) / 4) if complete else None,
            'mean_delta_mdd_pp': float(sum(v['delta_mdd_pp'] for v in per.values()) / 4) if complete else None,
            'max_delta_mdd_pp': float(max(v['delta_mdd_pp'] for v in per.values())) if complete else None,
            'reason': None if complete else 'MISSING_SYMBOL_SUPPORT'}


def pair(rows, a, b):
    """Đếm cả hai chiều đổi hành động và lợi/hại theo payoff cycle có sẵn."""
    changes = [p for p in rows if action(p, a) != action(p, b)]
    diffs = {p['point_id']: float(p['evaluation']['branches'][a]['cycle_net_return'] -
                                 p['evaluation']['branches'][b]['cycle_net_return']) for p in changes}
    return {'count': len(rows), 'disagreement': ratio(len(changes), len(rows)),
            'action_counts': dict(Counter(action(p, a) + '_' + action(p, b) for p in rows)),
            'changed_point_ids': [p['point_id'] for p in changes],
            'helpful_point_ids': [pid for pid, v in diffs.items() if v > 0],
            'harmful_point_ids': [pid for pid, v in diffs.items() if v < 0],
            'zero_effect_point_ids': [pid for pid, v in diffs.items() if v == 0]}


def view(pid, name):
    """Visibility từ sidecar request thực, không suy từ chỉ số retrieval."""
    p = packets[pid]
    if name == 'A_reference_shared_off':
        return p['a_evidence']['content_views']['full_prior']
    if name.startswith(('R_pool_', 'R_task_')):
        base, suffix = name.rsplit('_', 1) if name.endswith('_full') else (name.rsplit('_', 2)[0], '_'.join(name.split('_')[-2:]))
        mode = {'full': 'full_prior', 'stats_only': 'stats_only', 'examples_only': 'examples_only'}[suffix]
        return p['evidence']['content_views'][base][mode]
    return {'visible_metric_ids': [], 'visible_example_ids': [], 'visible_task_ids': []}


def visible(row, name):
    """Prior-off không gồm Numeric, chỉ dành cho nhánh LLM có prior."""
    v = view(row['point_id'], name)
    return bool(v['visible_metric_ids'] or v['visible_example_ids'])


G = group(primary, matrix)
assert all(G['stocks'][s]['metrics'] == reports[0]['stocks'][s]['metrics'] for s in SYMBOLS)
pairs = [(n, 'original') for n in matrix if n != 'original']
pairs += [(base + '_full', n) for base in ('R_pool', 'R_task')
          for n in ('A_reference_shared_off', base + '_stats_only', base + '_examples_only', 'Numeric_only')]
contrasts = {a + '__' + b: {'economics': contrast(G, a, b), 'actions': pair(primary, a, b)} for a, b in pairs}
coverage, ablation, failures = {}, {}, {}
for base in ('R_pool', 'R_task'):
    coverage[base] = {}
    for symbol in (*SYMBOLS, 'ALL'):
        rows = [p for p in primary if symbol == 'ALL' or p['context']['symbol'] == symbol]
        gates = [packets[p['point_id']]['evidence']['gate'][base] for p in rows]
        selection = [packets[p['point_id']]['evidence']['pool']['selection']['metadata'] for p in rows]
        stats = [packets[p['point_id']]['evidence']['pool']['statistics'] for p in rows]
        coverage[base][symbol] = {'planned': len(rows), 'complete': len(rows),
            'stats_ready': sum(g['stats_ready'] for g in gates), 'examples_ready': sum(g['examples_ready'] for g in gates),
            'both_ready': sum(g['stats_ready'] and g['examples_ready'] for g in gates),
            'visible': sum(visible(p, base + '_full') for p in rows),
            'off': sum(not visible(p, base + '_full') for p in rows),
            'query_feature_status': dict(Counter(m['query_feature_status'] for m in selection)),
            'stats_reasons': dict(Counter(v for st in stats for v in st['reason_codes'])),
            'examples_reasons': dict(Counter(v for g in gates for v in g['examples_reason_codes'])),
            'raw_at_least_two_tasks': sum(p['prior']['k_tasks'] >= 2 for p in rows),
            'visible_at_least_two_tasks': sum(view(p['point_id'], 'R_task_full').get('k_tasks', 0) >= 2 for p in rows),
            'k_task_distribution': dict(Counter(str(p['prior']['k_tasks']) for p in rows))}
    ready = [p for p in primary if all(p['prior']['gate'][base][k] for k in ('stats_ready', 'examples_ready'))]
    off = [p for p in primary if not visible(p, base + '_full')]
    t = group(ready, matrix)
    ablation[base] = {'T': t, 'T_definition': 'STATS_AND_EXAMPLES_READY_FOR_THIS_BASE',
        'contrasts': {suffix: {'G': contrast(G, base + '_full', base + suffix),
                               'T': contrast(t, base + '_full', base + suffix),
                               'actions_G': pair(primary, base + '_full', base + suffix),
                               'actions_T': pair(ready, base + '_full', base + suffix)}
                      for suffix in ('_stats_only', '_examples_only')},
        'off_vs_original': pair(off, base + '_full', 'original')}
    assert ablation[base]['off_vs_original']['disagreement']['numerator'] == 0
coverage['A_reference_shared_off'] = {}
for symbol in (*SYMBOLS, 'ALL'):
    rows = [p for p in primary if symbol == 'ALL' or p['context']['symbol'] == symbol]
    gates = [packets[p['point_id']]['a_evidence']['gate'] for p in rows]
    coverage['A_reference_shared_off'][symbol] = {'planned': len(rows), 'complete': len(rows),
        'stats_ready': sum(g['stats_ready'] for g in gates), 'examples_ready': sum(g['examples_ready'] for g in gates),
        'both_ready': sum(g['stats_ready'] and g['examples_ready'] for g in gates),
        'visible': sum(visible(p, 'A_reference_shared_off') for p in rows),
        'off': sum(not visible(p, 'A_reference_shared_off') for p in rows),
        'reason_codes': dict(Counter(v for g in gates for v in g['reason_codes']))}
for name in matrix:
    cases = []
    for p in primary:
        pid = p['point_id']; packet = packets[pid]; v = view(pid, name)
        net = p['evaluation']['net_return_long']; act = action(p, name)
        stat = packet['evidence']['pool']['statistics']
        adverse = None
        if name.startswith('R_') and 'win_rate_long' in v['visible_metric_ids']:
            adverse = bool(stat['posterior_mean'] < .5)
        elif name == 'A_reference_shared_off':
            metrics = packet['a_evidence']['statistics']['metrics']
            flags = [metrics[k]['posterior_mean'] < .5 if k == 'win_rate_long' else metrics[k]['posterior_mean'] > .5
                     for k in v['visible_metric_ids'] if metrics[k]['posterior_mean'] is not None]
            adverse = any(flags) if flags else None
        task_ids = v.get('visible_task_ids', [])
        text = p['branches'][name]['decision'].get('normalized_response', '')
        cases.append({'point_id': pid, 'symbol': p['context']['symbol'], 'regime': packet['evidence']['query']['current_regime'],
            'action': act, 'net_long_return': net, 'prior_visible': visible(p, name), 'adverse_observed': adverse,
            'loss_making_long': act == 'LONG' and net < 0, 'missed_profitable_long': act == 'CASH' and net > 0,
            'avoided_loss': act == 'CASH' and net < 0, 'visible_task_ids': task_ids,
            'mentioned_task_ids': [tid for tid in task_ids if tid in text]})
    failures[name] = {'cases': cases, 'loss_making_long': sum(c['loss_making_long'] for c in cases),
        'missed_profitable_long': sum(c['missed_profitable_long'] for c in cases),
        'avoided_loss': sum(c['avoided_loss'] for c in cases), 'adverse_observed': sum(c['adverse_observed'] is not None for c in cases),
        'adverse_count': sum(c['adverse_observed'] is True for c in cases),
        'long_on_adverse': sum(c['adverse_observed'] is True and c['action'] == 'LONG' for c in cases),
        'task_id_mention': ratio(sum(bool(c['mentioned_task_ids']) for c in cases), sum(bool(c['visible_task_ids']) for c in cases))}


def loss(rows):
    """Giao posterior hữu hạn A/R; không lọc readiness và không điền missing 0,5."""
    common = [r for r in rows if all(r['probability'][n] is not None for n in ('A', 'R8'))]
    y = np.asarray([r['label'] for r in common], dtype=float)
    values = {}
    for name in ('A', 'R8'):
        p = np.asarray([r['probability'][name] for r in common], dtype=float)
        assert np.all(np.isfinite(p)) and np.all((p >= 0) & (p <= 1))
        clip = np.clip(p, 1e-6, 1 - 1e-6)
        bins = []
        for i in range(5):
            mask = (p >= i / 5) & ((p < (i + 1) / 5) if i < 4 else (p <= 1))
            bins.append({'lower': i / 5, 'upper': (i + 1) / 5, 'upper_inclusive': i == 4,
                         'count': int(mask.sum()), 'mean_probability': float(p[mask].mean()) if mask.any() else None,
                         'win_fraction': float(y[mask].mean()) if mask.any() else None})
        values[name] = {'log_loss': float(np.mean(-y * np.log(clip) - (1 - y) * np.log(1 - clip))) if common else None,
            'brier': float(np.mean((p - y) ** 2)) if common else None, 'bins': bins,
            'raw': sum(r['probability'][name] is not None for r in rows), 'ready': sum(r['ready'][name] for r in rows),
            'missing_ids': [r['episode_id'] for r in rows if r['probability'][name] is None]}
    return {'planned': len(rows), 'common': len(common), 'common_ids': [r['episode_id'] for r in common], 'models': values}


dev_rows = []
for p in primary:
    packet = packets[p['point_id']]; stats = packet['evidence']['pool']['statistics']
    assert stats['lambda'] == 8
    dev_rows.append({'episode_id': p['point_id'], 'symbol': p['context']['symbol'],
        'regime': packet['evidence']['query']['current_regime'], 'label': int(p['evaluation']['net_return_long'] > 0),
        'probability': {'A': packet['a_evidence']['statistics']['metrics']['win_rate_long']['posterior_mean'], 'R8': stats['posterior_mean']},
        'ready': {'A': packet['a_evidence']['gate']['metrics']['win_rate_long']['status'] == 'READY', 'R8': stats['ready']}})
losses = {'train_frozen_summary': train['summary'], 'train_A_R8_check': loss(train['points']),
    'development': loss(dev_rows), 'development_by_symbol': {s: loss([r for r in dev_rows if r['symbol'] == s]) for s in SYMBOLS},
    'development_by_regime': {s: loss([r for r in dev_rows if r['regime'] == s]) for s in ('BULL', 'BEAR', 'CHOPPY', 'CONSOLIDATION')}}
for name in ('A', 'R8'):
    for key in ('log_loss', 'brier'):
        assert math.isclose(losses['train_A_R8_check']['models'][name][key], train['summary']['overall']['loss'][name][key], abs_tol=1e-14)
shrinkage = {s: {'count': len(values := [packets[p['point_id']]['evidence']['pool']['statistics'] for p in primary
                                       if s == 'ALL' or p['context']['symbol'] == s]),
    'no_conditional_history': sum(v['counts']['C']['n'] == 0 for v in values),
    'mean_hyperprior_weight': float(np.mean([v['hyperprior_weight'] for v in values])),
    'mean_absolute_shrink_from_raw': float(np.mean([abs(v['posterior_mean'] - v['raw_conditional_rate']) for v in values
                                                 if v['raw_conditional_rate'] is not None])) if any(v['raw_conditional_rate'] is not None for v in values) else None}
    for s in (*SYMBOLS, 'ALL')}
train_shrinkage = {}
for fold in ('ALL', 'train_2021', 'train_2022'):
    values = [r['pooled']['8'] for r in train['points'] if fold == 'ALL' or r['fold_id'] == fold]
    raw = [abs(v['posterior_mean'] - v['raw_conditional_rate']) for v in values if v['raw_conditional_rate'] is not None]
    train_shrinkage[fold] = {'count': len(values), 'raw_observed': len(raw),
        'no_conditional_history': sum(v['counts']['C']['n'] == 0 for v in values),
        'mean_hyperprior_weight': float(np.mean([v['hyperprior_weight'] for v in values])),
        'mean_absolute_shrink_from_raw': float(np.mean(raw)) if raw else None}
repeat_names = reports[1]['matrix']
rpairs = [(base + '_full', other) for base in ('R_pool', 'R_task')
          for other in ('original', 'A_reference_shared_off', base + '_stats_only', base + '_examples_only')]
repeat_groups = {str(i): group(reports[i]['points'] if i else [p for p in primary if p['point_id'] in sample],
                                 repeat_names if i else matrix) for i in range(4)}
repeat_contrasts = {a + '__' + b: {'primary_same_12_pp': contrast(repeat_groups['0'], a, b)['D_pp'],
    'by_repeat_pp': (values := [contrast(repeat_groups[str(i)], a, b)['D_pp'] for i in (1, 2, 3)]),
    'mean_three_pp': float(np.mean(values))} for a, b in rpairs}
by_slot = {(i, p['point_id']): p for i, report in reports.items() for p in report['points']}
repeat_disagreement = {}
for name in repeat_names:
    observations = [(pid, a, b) for pid in sample for a, b in combinations((1, 2, 3), 2)]
    changed = [(pid, a, b) for pid, a, b in observations if action(by_slot[a, pid], name) != action(by_slot[b, pid], name)]
    repeat_disagreement[name] = {'three_pairwise_repeats': ratio(len(changed), len(observations)), 'changed': changed,
        'primary_vs_repeat': {str(i): ratio(sum(action(by_slot[0, pid], name) != action(by_slot[i, pid], name) for pid in sample), len(sample))
                              for i in (1, 2, 3)} if name != 'original_duplicate' else None,
        'by_stratum': {st: ratio(sum(lock['repeat_sample'][sample.index(pid)]['actual_stratum'] == st for pid, a, b in changed),
                                      sum(lock['repeat_sample'][sample.index(pid)]['actual_stratum'] == st for pid, a, b in observations))
                       for st in ('BOTH', 'ONE', 'OFF')}}
duplicates = {str(i): pair(reports[i]['points'], 'original_duplicate', 'original') for i in (1, 2, 3)}
prior_off = {n: {str(i): pair([p for p in reports[i]['points'] if not visible(p, n)], n, 'original')
                 for i in range(4)} for n in matrix if n not in ('original', 'Numeric_only')}
assert all(v['disagreement']['numerator'] == 0 for runs in prior_off.values() for v in runs.values())
regimes = {packets[p['point_id']]['evidence']['query']['current_regime'] for p in primary}
subgroups = {'regime': {r: group([p for p in primary if packets[p['point_id']]['evidence']['query']['current_regime'] == r], matrix)
                        for r in ('BULL', 'BEAR', 'CHOPPY', 'CONSOLIDATION')},
             'quarter': {f'Q{q}': group([p for p in primary if (int(p['context']['as_of_date'][5:7]) - 1) // 3 + 1 == q], matrix)
                         for q in (1, 2, 3, 4)}}
for groups in subgroups.values():
    for g in groups.values():
        g['contrasts'] = {a + '__' + b: contrast(g, a, b) for a, b in pairs}
classification = {}
for name in matrix:
    confusion = {k: sum(G['stocks'][s]['metrics'][name]['confusion_counts'][k] for s in SYMBOLS)
                 for k in ('UP_LONG', 'UP_CASH', 'DOWN_LONG', 'DOWN_CASH')}
    up = confusion['UP_LONG'] + confusion['UP_CASH']; down = confusion['DOWN_LONG'] + confusion['DOWN_CASH']
    longs = confusion['UP_LONG'] + confusion['DOWN_LONG']
    classification[name] = {'confusion': confusion, 'accuracy': (confusion['UP_LONG'] + confusion['DOWN_CASH']) / 60,
        'balanced_accuracy': (confusion['UP_LONG'] / up + confusion['DOWN_CASH'] / down) / 2,
        'participation': longs / 60, 'cash_rate': (60 - longs) / 60,
        'long_hit_rate': confusion['UP_LONG'] / longs if longs else None}
ledger = json.loads((ROOT / 'outputs/oos_pilot/api_usage.json').read_text('utf8'))
http_rows = [r for r in ledger['requests'] if r.get('run_signature') == reports[0]['binding']['run_signature']]
result = {'analysis_version': 'bic_icl_development_analysis_v1', 'status': 'COMPLETE',
    'created_at_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'input_sha256': {p.relative_to(ROOT).as_posix(): sha(p) for p in (PLAN, ARCHIVE, TRAIN, gate, *(RUN / f'report_{i}.json' for i in range(4)))},
    'scope': 'DESCRIPTIVE_DEVELOPMENT_ONLY', 'primary': G, 'contrasts': contrasts, 'coverage': coverage,
    'ablation': ablation, 'losses': losses, 'shrinkage': {'development': shrinkage, 'train_R8': train_shrinkage},
    'classification_pooled_points': classification, 'failures': failures, 'subgroups': subgroups,
    'repeat': {'sample': lock['repeat_sample'], 'groups': repeat_groups, 'contrasts': repeat_contrasts,
               'action_disagreement': repeat_disagreement, 'duplicates': duplicates, 'prior_off': prior_off,
               'pairwise_observations_are_dependent': True},
    'execution': {'http_statuses': dict(Counter(str(r['status']) for r in http_rows)), 'unresolved_unknown': 0,
                  'agent_api_calls': 0, 'suites_rerun': False, 'gate_reused': 'W11-01',
                  'frozen_artifacts_matched': len(frozen), 'preserved_files': len(baseline)},
    'oracle': {'compounded_return_mdd_cycle_payoff': 'PASS', 'train_losses': 'PASS', 'prior_off_invariance': 'PASS'},
    'nomination_performed': False, 'confirmation_allowed': False}
preserve()
(QA / 'analysis.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')
print('Phân tích và oracle PASS; đã lưu analysis.json, không đổi nguồn/bằng chứng.', flush=True)

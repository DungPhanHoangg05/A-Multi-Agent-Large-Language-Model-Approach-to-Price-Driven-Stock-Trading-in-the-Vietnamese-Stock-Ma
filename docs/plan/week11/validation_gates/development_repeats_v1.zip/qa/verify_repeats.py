"""Chạy ba consumer verifier chính thức offline, bảo toàn toàn bộ bằng chứng có sẵn."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
qa = Path(__file__).parent
run = root / 'outputs/bayesian_benchmark/bic_icl_v2/development_run_release_v2'
plan = root / 'outputs/bayesian_benchmark/bic_icl_v2/development_plan_release_v2.json'


def sha(path: Path) -> str:
    """Hash byte bằng chứng hiện có, không đọc credential."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def preserve(baseline: dict[str, str]) -> None:
    """Verifier không được đổi source, ledger, report hoặc checkpoint khoa học."""
    for name, checksum in baseline.items():
        assert sha(root / name) == checksum, name


old = json.loads(Path('C:/Users/Legion/AppData/Local/Temp/bic-primary-close-f0dh4f9x/baseline.json').read_text('utf8'))
names = set(old)
names.update(subprocess.check_output(['git', 'ls-files', '-z'], text=True).split('\0'))
names.update(p.relative_to(root).as_posix() for p in run.rglob('*.json')
             if p.name not in ('run.owner.json', 'run.recovery.json'))
names.discard('')
names -= {'docs/plan/week11/README.md', 'docs/plan/plan.md'}
names = {n for n in names if not Path(n).name.startswith('.env')}
baseline = {n: sha(root / n) for n in sorted(names)}
(qa / 'baseline.json').write_text(json.dumps(baseline, indent=2), encoding='utf8')
print(f'Đã khóa {len(baseline)} tệp nguồn/bằng chứng trước verifier.', flush=True)
results = []
for repeat_id in (1, 2, 3):
    preserve(baseline)
    log = qa / f'verify_report_{repeat_id}.log'
    args = ['py', '-3.13', '-X', 'utf8', 'scripts/run_bic_icl.py', '--verify-report',
            '--repeat-id', str(repeat_id), '--plan', str(plan), '--output-dir', str(run),
            '--env-file', str(qa / 'absent.env')]
    assert not (qa / 'absent.env').exists()
    started = datetime.now(timezone.utc).isoformat()
    print(f'Bắt đầu CLI offline --verify-report --repeat-id {repeat_id}: {started}', flush=True)
    with log.open('wb') as stream:
        result = subprocess.run(args, stdout=stream, stderr=subprocess.STDOUT)
    content = log.read_text('utf-8-sig')
    assert result.returncode == 0, (repeat_id, result.returncode, content[-4000:])
    assert json.loads(content.strip().splitlines()[-1]) == {
        'status': 'COMPLETE', 'repeat_id': repeat_id, 'confirmation_allowed': False}
    preserve(baseline)
    row = {'repeat_id': repeat_id, 'command': args, 'exit_code': result.returncode,
           'started_at_utc': started, 'finished_at_utc': datetime.now(timezone.utc).isoformat(),
           'log_sha256': sha(log), 'status': 'VERIFIED_COMPLETE'}
    results.append(row)
    (qa / 'cli_results.json').write_text(json.dumps(results, indent=2), encoding='utf8')
    print(f'PASS: repeat {repeat_id}, không đổi {len(baseline)} tệp.', flush=True)
print('PASS: đủ ba CLI --verify-report; không gọi API, không chạy lại suite.', flush=True)

"""Đối soát ba repeat đã verify và đóng băng nguyên byte, không phân tích/chọn phương pháp."""

from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

root = Path.cwd()
qa = Path(__file__).parent
sys.path.insert(0, str(root))
from core.bic_icl_protocol import code_identity
from core.candidate_selection import read_technical_gates
from core.historical_signals import digest
from core.research_cohort import read_envelope
from core.research_input_lock import runtime_identity

run = root / 'outputs/bayesian_benchmark/bic_icl_v2/development_run_release_v2'
plan_path = run.parent / 'development_plan_release_v2.json'
release_path = root / 'docs/plan/week11/development_release_v1.json'
gate_path = root / 'docs/plan/week11/validation_gates/development_v1/technical_gates.json'
ledger_path = root / 'outputs/oos_pilot/api_usage.json'
old_archive = root / 'docs/plan/week11/validation_gates/development_primary_v1.zip'
source_archive = root / 'docs/plan/week11/validation_gates/development_release_v1.zip'


def sha(path: Path) -> str:
    """Artifact dùng hash byte, source code có normalization riêng theo hợp đồng."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def preserved() -> None:
    """Giữ nguyên mọi bằng chứng trước lượt verifier, trừ metadata khóa OS."""
    for name, checksum in baseline.items():
        assert sha(root / name) == checksum, name


baseline = json.loads((qa / 'baseline.json').read_text('utf8'))
cli = json.loads((qa / 'cli_results.json').read_text('utf8'))
assert [r['repeat_id'] for r in cli] == [1, 2, 3]
assert all(r['status'] == 'VERIFIED_COMPLETE' and r['exit_code'] == 0 for r in cli)
preserved()
plan, release = read_envelope(plan_path), read_envelope(release_path)
lock = read_envelope(run / 'context_lock.json')
manifest = read_envelope(run / 'request_manifest.json')
ledger = json.loads(ledger_path.read_text('utf8'))
reports = {i: read_envelope(run / f'report_{i}.json') for i in range(4)}
assert plan['code_sha256'] == code_identity() and plan['runtime'] == runtime_identity()
assert read_technical_gates(gate_path, plan)['status'] == 'PASS'
assert all(sha(root / name) == value for name, value in plan['source_hashes'].items())
with zipfile.ZipFile(source_archive) as archive:
    assert archive.testzip() is None
    freeze = json.loads(archive.read('qa/source_freeze.json'))['payload']
    assert all(hashlib.sha256((root / name).read_text('utf8').encode()).hexdigest() == value
               for name, value in freeze['gate_source_sha256'].items())
    for path in (plan_path, release_path, gate_path):
        assert path.read_bytes() == archive.read(path.relative_to(root).as_posix())
with zipfile.ZipFile(old_archive) as archive:
    assert archive.testzip() is None
    index = json.loads(archive.read('manifest.json'))
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == value
               for name, value in index['files'].items())
    primary_files = {name: value for name, value in index['files'].items()
                     if name.startswith(run.relative_to(root).as_posix() + '/')
                     or name in (plan_path.relative_to(root).as_posix(), release_path.relative_to(root).as_posix())}
    old_ledger = json.loads(archive.read(ledger_path.relative_to(root).as_posix()))
assert len(primary_files) == 564
assert all(sha(root / name) == value for name, value in primary_files.items())
assert sha(run / 'report_0.json') == '00771c113b0d4cc3ffbf370af789da3cee773e477d7aff2105c8c3cb95f9d4b2'
assert all(sha(run / name) == value for name, value in release['snapshot_sha256'].items())
signature = release['run_binding']['run_signature']
assert digest(plan) == release['plan_sha256']
assert digest(lock) == release['decision_context_lock_sha256']
assert digest(manifest) == release['request_manifest_sha256']
by_http = {r['id']: r for r in ledger['requests']}
assert len(by_http) == len(ledger['requests'])
assert all(digest(by_http[r['id']]) == digest(r) for r in old_ledger['requests'])
proof = ledger['preflight']
assert proof['status'] == 'PASS' and proof['plan_sha256'] == digest(plan)
assert len(proof['request_ids']) == 2
assert all(by_http[i]['status'] == 200 and by_http[i]['credential_scope'] == proof['credential_scope']
           for i in proof['request_ids'])
assert {by_http[i]['model'] for i in proof['request_ids']} == {'openai/gpt-oss-20b', 'qwen/qwen3.8-27b'}
run_rows = [r for r in ledger['requests'] if r.get('run_signature') == signature]
scopes = {r['credential_scope'] for r in run_rows}
prior_preflight_pairs = []
for scope in scopes:
    first = min(r['started_at'] for r in run_rows if r['credential_scope'] == scope)
    groups = defaultdict(set)
    for row in ledger['requests']:
        if (row.get('credential_scope') == scope and row.get('role') == 'preflight'
                and row['status'] == 200 and row.get('completed_at', row['started_at']) < first):
            groups[row['invocation_id']].add(row['model'])
    pairs = sum(models == {'openai/gpt-oss-20b', 'qwen/qwen3.8-27b'} for models in groups.values())
    assert pairs > 0
    prior_preflight_pairs.append(pairs)
sample = [r['point_id'] for r in lock['repeat_sample']]
assert len(set(sample)) == 12 and all(r['reason'] == 'EARLIEST_MATCH' for r in lock['repeat_sample'])
assert Counter(p[:3] for p in sample) == {'FPT': 3, 'MWG': 3, 'VCB': 3, 'VNM': 3}
manifest_blocks = {(b['repeat_id'], b['point_id']): b for b in manifest['blocks']}
all_attempt_ids = set()
attempts_by_repeat = {}
details = []
for repeat_id, report in reports.items():
    assert report['status'] == 'COMPLETE' and report['repeat_id'] == repeat_id
    assert report['in_primary'] is (repeat_id == 0)
    assert report['nomination_performed'] is False and report['confirmation_allowed'] is False
    assert report['matrix'] == [*lock['matrix'], 'original_duplicate' if repeat_id else 'Numeric_only']
    expected = sample if repeat_id else [p['point_id'] for p in plan['schedule']]
    assert [p['point_id'] for p in report['points']] == expected
    assert all(p['evaluation'] is not None for p in report['points'])
    for symbol, stock in report['stocks'].items():
        count = 3 if repeat_id else {'FPT': 12, 'MWG': 16, 'VCB': 16, 'VNM': 16}[symbol]
        assert stock['planned_count'] == stock['common_count'] == count
        assert stock['excluded_point_ids'] == []
    binding = report['binding']
    assert binding['run_signature'] == signature and binding['plan_sha256'] == digest(plan)
    assert binding['context_lock_sha256'] == digest(lock)
    assert binding['code_sha256'] == plan['code_sha256'] and binding['runtime'] == plan['runtime']
    assert all(sha(run / name) == value for name, value in binding['checkpoint_sha256'].items())
    assert all(digest(by_http[name]) == value for name, value in binding['http_record_sha256'].items())
    statuses, origins, attempt_ids, resumes = Counter(), Counter(), set(), 0
    duplicates = 0
    for j, point in enumerate(report['points']):
        pid = point['point_id']
        block = read_envelope(run / f'decision_blocks/{repeat_id}/{pid}/state.json')
        requests = block['binding']['requests']
        planned = manifest_blocks[repeat_id, pid]['requests']
        assert [r['branch_id'] for r in requests] == [r['branch_id'] for r in planned] == list(block['branches'])
        assert [r['contract'] for r in requests] == [r['contract'] for r in planned]
        if repeat_id:
            others = lock['matrix'][1:] + ['original_duplicate']
            shift = (3 * j + repeat_id - 1) % len(others)
            assert list(block['branches']) == ['original', *others[shift:], *others[:shift]]
            primary = read_envelope(run / f'decision_blocks/0/{pid}/state.json')
            assert block['binding']['shared_sha256'] == primary['binding']['shared_sha256']
            primary_requests = {r['branch_id']: r for r in primary['binding']['requests']}
            for request in requests:
                name = request['branch_id']
                reference = primary_requests['original' if name == 'original_duplicate' else name]
                assert all(request[k] == reference[k] for k in ('prompt', 'prefix', 'base_evidence_sha256', 'contract'))
            assert 'Numeric_only' not in point['branches']
        else:
            numeric = point['branches']['Numeric_only']
            assert numeric['status'] == 'complete' and numeric['scientific_attempt_count'] == 0
            assert numeric['decision_origin'] == 'numeric'
        for name, branch in block['branches'].items():
            assert branch['status'] == 'complete'
            statuses[branch['status']] += 1
            origins[branch['decision_origin']] += 1
            resumes += len(branch['resumes'])
            if branch['attempts']:
                assert len(branch['attempts']) == 1
                attempt = branch['attempts'][0]
                aid = attempt['attempt_id']
                assert aid not in all_attempt_ids and attempt['status'] == 'complete'
                assert attempt['authorization'] is None
                all_attempt_ids.add(aid)
                attempt_ids.add(aid)
                if name == 'original_duplicate':
                    duplicates += 1
                    assert branch['decision_origin'] == 'independent_duplicate'
                    assert aid != block['branches']['original']['attempts'][0]['attempt_id']
            else:
                assert branch['decision_origin'] in ('shared_original', 'stats_alias')
                assert branch['source'] is not None
    attempts_by_repeat[repeat_id] = attempt_ids
    expected_ids = attempts_by_repeat[0] | attempt_ids
    rows = [r for r in ledger['requests'] if r.get('checkpoint_attempt_id') in attempt_ids]
    assert rows and all(r.get('run_signature') == signature for r in rows)
    assert {r['id']: digest(r) for r in ledger['requests']
            if r.get('checkpoint_attempt_id') in expected_ids} == binding['http_record_sha256']
    assert all(sum(r['status'] == 200 for r in rows if r['checkpoint_attempt_id'] == aid) == 1
               for aid in attempt_ids)
    assert not any(r['status'] == 'unknown' for r in rows)
    for row in rows:
        audit = row['improvement_audit']
        assert audit['slot']['repeat_id'] == repeat_id
        if row['status'] == 200:
            assert row['durable_response'] == {'sha256': sha(run / 'http_cache' / (row['id'] + '.json'))}
    assert len(attempt_ids) == (62 if repeat_id else 317)
    assert sum(statuses.values()) == (108 if repeat_id else 480)
    assert duplicates == (12 if repeat_id else 0)
    details.append({'repeat_id': repeat_id, 'status': 'VERIFIED_COMPLETE', 'points': len(expected),
                    'common_support': {s: v['common_count'] for s, v in report['stocks'].items()},
                    'logical_llm_slots': sum(statuses.values()), 'scientific_attempts': len(attempt_ids),
                    'independent_duplicates': duplicates, 'origins': dict(origins), 'branch_resume_stamps': resumes,
                    'http_attempts': len(rows), 'http_statuses': dict(Counter(str(r['status']) for r in rows)),
                    'credential_scope_count': len({r['credential_scope'] for r in rows}),
                    'report_checkpoint_files': len(binding['checkpoint_sha256']),
                    'report_bound_http_records_including_primary': len(binding['http_record_sha256']),
                    'report_sha256': sha(run / f'report_{repeat_id}.json'), 'report_payload_sha256': digest(report)})
rows = [r for r in ledger['requests'] if r.get('run_signature') == signature]
assert {r.get('checkpoint_attempt_id') for r in rows} == all_attempt_ids
assert len(all_attempt_ids) == 503
assert Counter(str(r['status']) for r in rows) == {'200': 503, '429': 4, 'transport_error': 9}
summary = {'verification_version': 'bic_icl_development_repeats_verification_v1', 'status': 'VERIFIED_COMPLETE',
           'verified_at_utc': datetime.now(timezone.utc).isoformat(),
           'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
           'cli_verifications': cli, 'reports': details,
           'primary_files_preserved_from_archive': len(primary_files), 'preserved_files': len(baseline),
           'historical_ledger_records_preserved': len(old_ledger['requests']),
           'source_hashes': len(plan['source_hashes']), 'gate_source_files': len(freeze['gate_source_sha256']),
           'source_runtime_gate_receipt': 'PASS', 'reused_gate_tests': {'unit': 1103, 'leakage': 249},
           'repeat_logical_slots': 324, 'repeat_scientific_attempts': 186, 'independent_duplicates': 36,
           'unresolved_checkpoint_or_http_unknown': 0, 'rotation_canonical_shared_upstream': 'PASS',
           'credential_scopes': len(scopes), 'preflight_pairs_before_first_scope_use': sorted(prior_preflight_pairs),
           'run_http_attempts': len(rows), 'run_http_statuses': dict(Counter(str(r['status']) for r in rows)),
           'new_api_calls_by_agent': 0, 'suites_rerun': False, 'analysis_performed': False,
           'nomination_performed': False, 'confirmation_allowed': False,
           'run_signature': signature, 'plan_sha256': sha(plan_path), 'release_sha256': sha(release_path),
           'technical_gates_sha256': sha(gate_path), 'context_lock_sha256': digest(lock),
           'request_manifest_sha256': digest(manifest), 'ledger_snapshot_sha256': sha(ledger_path)}
(qa / 'repeat_verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf8')
members = {p.relative_to(root).as_posix(): p for p in run.rglob('*.json')
           if p.name not in ('run.owner.json', 'run.recovery.json')}
for path in (plan_path, release_path, gate_path, ledger_path, root / 'docs/plan/week11/.gitattributes'):
    members[path.relative_to(root).as_posix()] = path
for path in gate_path.parent.glob('*.log'):
    members[path.relative_to(root).as_posix()] = path
for name in ('baseline.json', 'verify_repeats.py', 'audit_and_freeze.py', 'cli_results.json',
             'repeat_verification.json', 'verify_report_1.log', 'verify_report_2.log', 'verify_report_3.log'):
    members['qa/' + name] = qa / name
index = {'version': 'bic_icl_development_repeats_freeze_v1', 'summary': summary,
         'previous_evidence': {p.relative_to(root).as_posix(): sha(p) for p in (source_archive, old_archive)},
         'files': {name: sha(path) for name, path in sorted(members.items())}}
target = root / 'docs/plan/week11/validation_gates/development_repeats_v1.zip'
preserved()
with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(members.items()):
        archive.writestr(name, path.read_bytes())
    archive.writestr('manifest.json', json.dumps(index, ensure_ascii=False, indent=2).encode())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(members) + 1
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == value for name, value in index['files'].items())
preserved()
receipt = {'status': 'PASS', 'path': target.relative_to(root).as_posix(), 'sha256': sha(target),
           'entries': len(members) + 1, 'bytes': target.stat().st_size, 'summary': summary}
(qa / 'archive_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps(receipt, ensure_ascii=False), flush=True)

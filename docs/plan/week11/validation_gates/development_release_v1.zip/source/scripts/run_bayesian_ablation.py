"""CLI pilot v1 và cohort bốn mã v2; chế độ kiểm tra không đọc key hoặc gọi API."""

from __future__ import annotations

import argparse
import base64
from io import BytesIO
import json
import os
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import httpx
from dotenv import dotenv_values
from langchain_core.messages import HumanMessage
from langchain_groq import ChatGroq
from PIL import Image

from core.backtest_engine import BacktestEngine
from core.execution_prices import STOCK_SYMBOLS
from core.groq_pacing import GroqPacer, PacedGroqTransport, PilotStop, QUOTA_POLICIES, MODEL_LIMITS, tokenizer_cached
from core.pilot_readiness import INPUT_DIR, build_adapter, prepare_inputs, verify_inputs
from core.prior_backtest import PriorBacktestRunner, canonical_hash
from core.prior_run_lock import PriorRunLock
from utils.graph_setup import SetGraph
from utils.graph_util import TechnicalTools


def make_builder(plan: dict[str, Any], key: str, client: httpx.Client) -> SetGraph:
    """Dùng client ChatGroq thật; transport chung bắt cả structured và fallback."""
    models = plan["signal_config"]["models"]
    def model(role: str) -> ChatGroq:
        llm = ChatGroq(model=models[f"{role}_llm_model"], temperature=models[f"{role}_llm_temperature"],
            max_tokens=models[f"{role}_llm_max_tokens"], api_key=key, max_retries=0,
            http_client=client, **plan["client_options"][role])
        # LangChain tự đổi 0 thành 1e-8 trong constructor; khôi phục đúng giá trị
        # đã khóa trước mọi request và trước validator nghiên cứu.
        llm.temperature = models[f"{role}_llm_temperature"]
        return llm
    return SetGraph(model("agent"), model("graph"), TechnicalTools())


def preflight(builder: SetGraph) -> None:
    """Hai request nhỏ kiểm text/vision thực; không đọc/gọi upstream các cutoff."""
    from utils.historical_api import _invoke_with_retry
    text = _invoke_with_retry(builder.agent_llm.invoke,
        [HumanMessage(content='Return exactly {"ok":true} as JSON, no other text.')], retries=1)
    if json.loads(text.content) != {"ok": True}:
        raise ValueError("Model text không trả JSON hợp lệ khi preflight")
    image = Image.new("RGB", (64, 64), "red")
    stream = BytesIO()
    image.save(stream, format="PNG")
    url = "data:image/png;base64," + base64.b64encode(stream.getvalue()).decode("ascii")
    response = _invoke_with_retry(builder.graph_llm.invoke, [HumanMessage(content=[
        {"type": "text", "text": 'Return exactly {"color":"red"} if the image is red; JSON only.'},
        {"type": "image_url", "image_url": {"url": url}}])], retries=1)
    if json.loads(response.content) != {"color": "red"}:
        raise ValueError("Model vision không nhận đúng ảnh ở preflight")
    print("Preflight text/vision PASS; usage và quota headers đã lưu an toàn", flush=True)


def main() -> None:
    """Mặc định dry-run; chỉ --run/--preflight mới tạo lời gọi LLM có quota."""
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--prepare", action="store_true", help="Khóa input pilot hoặc plan ứng viên kế thừa --plan, không LLM")
    mode.add_argument("--dry-run", action="store_true", help="Xác minh toàn input/plan, không LLM")
    mode.add_argument("--preflight", action="store_true", help="Kiểm text và vision thật qua transport có pacing")
    mode.add_argument("--run", action="store_true", help="Chạy pilot sau preflight thành công")
    mode.add_argument("--verify-only", action="store_true", help="Kiểm semantic checkpoint, không LLM")
    mode.add_argument("--verify-report", action="store_true", help="Tái dựng checkpoint và đối chiếu toàn report cohort, không LLM")
    mode.add_argument("--select-candidate", action="store_true", help="Đề cử development từ checkpoint/report đã verify, không LLM")
    mode.add_argument("--verify-selection", action="store_true", help="Tái tính và kiểm quyết định ứng viên bất biến, không LLM")
    mode.add_argument("--reconcile", action="store_true", help="Đối soát journal offline, không gọi LLM")
    mode.add_argument("--design-calendar", action="store_true", help="Lập lịch mẫu/pilot/smoke offline, chưa tạo plan chạy")
    mode.add_argument("--validate-train", action="store_true", help="Chẩn đoán train PIT offline, không Decision/API")
    mode.add_argument("--verify-train", action="store_true", help="Dựng lại chẩn đoán train và đối chiếu report đã khóa")
    mode.add_argument("--benchmark-prior", action="store_true", help="Đo offline prior public, 100 warm-up/1.000 mẫu mỗi stage")
    mode.add_argument("--verify-performance", action="store_true", help="Kiểm mẫu thô, nguồn/code và semantic report hiệu năng")
    parser.add_argument("--performance-report", type=Path, help="Report hiệu năng bất biến trong outputs/bayesian_benchmark")
    parser.add_argument("--technical-gates", type=Path, help="Receipt bốn gate đúng code/runtime, kèm log đã khóa")
    parser.add_argument("--selection-output", default="candidate_selection_v1.json", help="Đường tương đối mới trong output-dir cho quyết định")
    parser.add_argument("--train-report", type=Path, help="Report train bất biến trong outputs/bayesian_benchmark")
    parser.add_argument("--train-index", help="Index train; đường tương đối trong outputs/bayesian_benchmark/price_features")
    parser.add_argument("--coverage", type=Path, default=ROOT / "outputs/bayesian_benchmark/coverage.json")
    parser.add_argument("--calendar-output", type=Path, help="JSON lịch trong outputs/bayesian_benchmark")
    parser.add_argument("--points-per-quarter", type=int, default=4, help="Mục tiêu mỗi mã/quý khi lập lịch")
    parser.add_argument("--authorize-replay", help="Xác nhận replay đúng UUID attempt unknown đã đối soát")
    parser.add_argument("--replay-reason", help="Lý do xác nhận replay, không ghi thông tin xác thực")
    parser.add_argument("--resume", action="store_true", help="Phục hồi run năm nhánh, không dùng runner Memory Bank")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs/pilot_fpt_run")
    parser.add_argument("--env-file", type=Path, default=ROOT / ".env")
    parser.add_argument("--plan", type=Path, help="Envelope plan cohort v2/v3/v4 đã khóa; nguồn khi prepare")
    parser.add_argument("--candidate-plan", type=Path, help="Đường plan v3 mới khi --prepare --plan PARENT")
    parser.add_argument("--holdout-plan", type=Path, help="Đường plan v4 mới khi prepare từ plan development đã verify")
    parser.add_argument("--development-run", type=Path, help="Run development chứa report và selection đã khóa")
    parser.add_argument("--price-index", default="outputs/bayesian_benchmark/price_features/candidate_index_v1.json",
                        help="Index phụ cho prepare ứng viên; đường tương đối workspace")
    parser.add_argument("--candidate-split", choices=("fixture", "development_2023"),
                        help="Kế thừa lịch development đã khóa; bỏ cờ để giữ lịch parent")
    parser.add_argument("--symbol", action="append", choices=STOCK_SYMBOLS,
                        help="Chọn mã chạy tuần tự; bỏ cờ để chạy đủ bốn mã")
    parser.add_argument("--ledger", type=Path, default=ROOT / "outputs/oos_pilot/api_usage.json",
                        help="Ledger chung của tài khoản; giữ cùng đường dẫn khi resume/đổi key")
    parser.add_argument("--quota-policy", choices=QUOTA_POLICIES, default="request_admission_v2",
                        help="Khóa policy cho run mới; v2 kiểm từng request, có thể dừng giữa điểm")
    args = parser.parse_args()
    selection_mode = args.select_candidate or args.verify_selection
    holdout_prepare = args.prepare and args.plan is not None and args.holdout_plan is not None
    if args.holdout_plan is not None or args.development_run is not None:
        if not holdout_prepare or args.development_run is None or args.candidate_plan or args.candidate_split:
            parser.error("Holdout cần --prepare --plan DEVELOPMENT --holdout-plan NEW --development-run RUN")
    if (args.technical_gates is not None or args.selection_output != "candidate_selection_v1.json") and not (selection_mode or holdout_prepare):
        parser.error("Cờ quyết định chỉ dùng với --select-candidate hoặc --verify-selection")
    if selection_mode:
        if not args.plan or args.symbol or args.resume or args.authorize_replay or args.replay_reason:
            parser.error("Lựa chọn cần --plan toàn cohort, không dùng cờ execute/replay")
        args.verify_report = True
    if args.verify_report:
        if args.plan is None:
            parser.error("--verify-report cần --plan cohort và report.json đã lưu")
        args.verify_only = True
    if args.benchmark_prior or args.verify_performance:
        allowed = {"--benchmark-prior", "--verify-performance", "--performance-report"}
        if any(token.split("=", 1)[0] not in allowed for token in sys.argv[1:] if token.startswith("--")):
            parser.error("Đo hiệu năng chỉ dùng --performance-report, không dùng cờ execute")
        from core.prior_performance import DEFAULT_REPORT, run_performance
        destination = args.performance_report or ROOT / DEFAULT_REPORT
        report = run_performance(destination, verify_only=args.verify_performance)
        print(f"Hiệu năng prior: {report['status']}; report={destination}", flush=True)
        if report["status"] != "PASS":
            raise SystemExit(1)
        return
    if args.performance_report is not None:
        parser.error("--performance-report cần --benchmark-prior hoặc --verify-performance")
    if args.validate_train or args.verify_train:
        allowed = {"--validate-train", "--verify-train", "--train-report", "--train-index"}
        if any(token.split("=", 1)[0] not in allowed for token in sys.argv[1:] if token.startswith("--")):
            parser.error("Validation train chỉ dùng --train-report/--train-index, không dùng cờ execute")
        from core.train_pit_validation import DEFAULT_INDEX, DEFAULT_REPORT, run_train_validation
        destination = args.train_report or ROOT / DEFAULT_REPORT
        report = run_train_validation(destination, index_path=args.train_index or DEFAULT_INDEX,
                                      verify_only=args.verify_train)
        print(f"Train PIT PASS: {report['replayed_count']} replay, {report['query_count']} query; "
              f"Decision=0; report={destination}", flush=True)
        return
    if args.train_report is not None or args.train_index is not None:
        parser.error("Cờ train cần --validate-train hoặc --verify-train")
    if (args.candidate_plan or args.candidate_split or args.price_index != "outputs/bayesian_benchmark/price_features/candidate_index_v1.json") and not (args.prepare and args.plan and args.candidate_plan):
        parser.error("Cờ ứng viên chỉ dùng --prepare --plan PARENT --candidate-plan NEW")
    if args.design_calendar:
        if (args.plan or args.symbol or args.resume or args.authorize_replay or args.replay_reason
                or args.output_dir != ROOT / "outputs/pilot_fpt_run"
                or args.ledger != ROOT / "outputs/oos_pilot/api_usage.json"
                or args.quota_policy != "request_admission_v2" or args.env_file != ROOT / ".env"):
            parser.error("Lập lịch chỉ dùng --coverage/--calendar-output/--points-per-quarter, không dùng cờ execute")
        from core.cohort_calendar import build_locked_calendar
        destination = args.calendar_output or ROOT / "outputs/bayesian_benchmark/calendar.json"
        payload = build_locked_calendar(args.coverage, destination, points_per_quarter=args.points_per_quarter)
        counts = payload["summary"]
        print(f"Lịch dự kiến: {counts['planned_main']}/{counts['target_main']} điểm chính, "
              f"{counts['planned_smoke']} smoke riêng; còn chờ quota/khóa input. Lưu tại {destination}")
        return
    if (args.calendar_output is not None or args.coverage != ROOT / "outputs/bayesian_benchmark/coverage.json"
            or args.points_per_quarter != 4):
        parser.error("Các cờ lịch mẫu cần --design-calendar")
    if (args.authorize_replay or args.replay_reason) and not (args.reconcile and args.authorize_replay and args.replay_reason):
        parser.error("Xác nhận cần --reconcile --authorize-replay UUID --replay-reason LY_DO")
    if args.resume and not (args.run or args.verify_only):
        parser.error("--resume chỉ đi với --run hoặc --verify-only")
    if args.plan:
        execute_cohort(args)
        return
    if args.symbol or args.ledger != ROOT / "outputs/oos_pilot/api_usage.json":
        parser.error("--symbol/--ledger tùy chỉnh cần --plan")
    plan = prepare_inputs() if args.prepare else verify_inputs()
    adapter = build_adapter(plan)
    contexts = [adapter.prepare("FPT", cutoff) for cutoff in plan["cutoffs"]]
    print(f"Input PASS: FPT {len(contexts)} cutoff, {plan['cutoffs'][0]} → {plan['cutoffs'][-1]}; "
          f"plan={canonical_hash(plan)}", flush=True)
    cached = tokenizer_cached()
    print(f"Quota policy: {args.quota_policy}; tokenizer cache: {'PASS' if cached else 'THIẾU/HỎNG'}", flush=True)
    if args.prepare or not (args.preflight or args.run or args.verify_only or args.reconcile):
        return
    offline = args.verify_only or args.reconcile
    if not offline and not cached:
        raise ValueError("Cần chạy py -3.13 scripts/prepare_groq_tokenizer.py trước run; chưa gọi API")
    config = plan["signal_config"]
    # Chế độ verify-only dùng client có transport cấm mạng và không đọc key.
    key = "offline-verifier-no-network"
    if not offline:
        key = dotenv_values(args.env_file).get("GROQ_API_KEY") or os.environ.get("GROQ_API_KEY", "")
        if not key:
            raise ValueError("Thiếu GROQ_API_KEY; đặt riêng trong .env")
    def reject_network(request: httpx.Request) -> httpx.Response:
        raise AssertionError("verify-only không được phép gọi API")
    # Khóa cả quota ledger để không có hai run-dir dùng chung quota sai số.
    with (PriorRunLock(args.ledger.resolve().parent / (args.ledger.name + ".lock"), "shared-account-ledger-v2"),
          PriorRunLock(ROOT / "outputs/oos_pilot/runtime", canonical_hash(plan))):
        # Nạp ledger SAU khi có khóa để không ghi đè usage của tiến trình trước.
        pacer = GroqPacer(ROOT / "outputs/oos_pilot/api_usage.json", policy=args.quota_policy)
        transport = httpx.MockTransport(reject_network) if offline else PacedGroqTransport(pacer)
        with httpx.Client(transport=transport, timeout=90.) as client:
            execute(args, plan, adapter, config, key, pacer, client)


def execute(args: argparse.Namespace, plan: dict[str, Any], adapter: Any,
            config: dict[str, Any], key: str, pacer: GroqPacer, client: httpx.Client) -> None:
    """Thực thi trong khóa quota chung; policy thuộc identity của checkpoint."""
    builder = make_builder(plan, key, client)
    if args.preflight:
        first = len(pacer.state["requests"])
        preflight(builder)
        pacer.state["preflight"] = {"status": "PASS", "plan_sha256": canonical_hash(plan),
            "request_ids": [r["id"] for r in pacer.state["requests"][first:]]}
        pacer.save()
        return
    if args.run:
        proof = pacer.state.get("preflight", {})
        successful = {r["model"] for r in pacer.state["requests"]
            if r["id"] in proof.get("request_ids", []) and r["status"] == 200}
        if (proof.get("status") != "PASS" or proof.get("plan_sha256") != canonical_hash(plan)
                or successful != set(plan["limits"])):
            raise ValueError("Cần --preflight PASS cho cả text và vision trước pilot")
    engine = BacktestEngine({**config["models"], "language": config["language"],
        "alpha_norm_method": config["norm_method"], "alpha_weights": config["alpha_weights"]})
    runner = PriorBacktestRunner(engine, adapter, builder, extra_source_paths=(f"{INPUT_DIR}/plan.json",),
                                 before_point=pacer.before_point, quota_policy=pacer.policy, durable_stages=True)
    def progress(event: dict[str, Any]) -> None:
        print(f"Pilot: {event['completed']}/{event['total']} điểm đủ năm nhánh", flush=True)
    result = runner.run("FPT", output_dir=args.output_dir, cutoffs=tuple(plan["cutoffs"]), step=3,
                        resume=args.resume, verify_only=args.verify_only, callback=progress,
                        reconcile=args.reconcile, authorize_replay=args.authorize_replay, replay_reason=args.replay_reason)
    if args.reconcile:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    print(f"Pilot {result['status']}: {len(result['completed_point_ids'])}/{len(result['planned_point_ids'])} điểm", flush=True)


def execute_cohort(args: argparse.Namespace) -> None:
    """Một CLI cho cohort mới; dry-run/verify không mở env hoặc gọi mạng."""
    from core.research_cohort import read_envelope, validate_plan
    from core.research_invocation import ENABLED, invocation_scope
    from core.pilot_readiness import sha_file
    if args.prepare and not args.candidate_plan and not getattr(args, "holdout_plan", None):
        raise ValueError("Plan cohort phải được khóa trước; không tự chọn lịch hoặc ngưỡng")
    if args.output_dir.resolve() == (ROOT / "outputs/pilot_fpt_run").resolve():
        raise ValueError("Cohort mới cần --output-dir riêng khỏi pilot W4")
    plan = read_envelope(args.plan)
    inputs = plan["inputs"]
    if inputs["limits"] != MODEL_LIMITS:
        raise ValueError("Quota plan khác giới hạn đã khóa")
    if inputs["model"]["freeze_as_of_date"] >= "2023-01-01":
        raise ValueError("Cohort giữ model đóng băng trước 2023")
    checks = {f"{inputs['execution_dir']}/manifest.json": inputs["execution_manifest_sha256"],
              inputs["model"]["artifact_path"]: inputs["model"]["artifact_sha256"],
              inputs["model"]["source_path"]: inputs["model"]["source_sha256"]}
    checks.update({f"{inputs['news_dir']}/{s}.json": proof["snapshot_sha256"] for s, proof in inputs["news_sources"].items()})
    if any(sha_file(ROOT / path) != expected for path, expected in checks.items()):
        raise ValueError("Nguồn/model/tin khác plan đã khóa")
    adapter = build_adapter(inputs)
    if args.prepare:
        if getattr(args, "holdout_plan", None):
            from core.holdout_protocol import prepare_holdout_plan, selection_binding
            from core.prior_run_lock import safe_path
            binding = selection_binding(ROOT, args.plan, args.development_run,
                safe_path(args.development_run, args.selection_output), args.technical_gates, args.ledger)
            prepare_holdout_plan(args.holdout_plan, adapter, binding)
            print(f"Plan holdout v4 đã khóa tại {args.holdout_plan}; chưa tạo manifest hoặc gọi API", flush=True)
            return
        from core.candidate_cohort import prepare_candidate_plan
        plan = prepare_candidate_plan(args.plan, args.candidate_plan, adapter,
            index_path=args.price_index, split=args.candidate_split)
        print(f"Plan sáu ứng viên đã khóa tại {args.candidate_plan}; chưa gọi API", flush=True)
        return
    validate_plan(plan, adapter)
    print(f"Cohort {plan['cohort_id']}: plan/source/lịch PASS; {plan['matrix']}; {plan['split']}", flush=True)
    if not (args.run or args.preflight or args.verify_only or args.reconcile):
        return
    offline = args.verify_only or args.reconcile
    if not offline and plan["split"] == "fixture":
        raise ValueError("Fixture chỉ kiểm offline, không cho gọi API thật")
    if not offline and not tokenizer_cached():
        raise ValueError("Thiếu tokenizer cache; chạy scripts/prepare_groq_tokenizer.py trước")
    key = "offline-verifier-no-network"
    if not offline:
        key = dotenv_values(args.env_file).get("GROQ_API_KEY") or os.environ.get("GROQ_API_KEY", "")
        if not key:
            raise ValueError("Thiếu GROQ_API_KEY")
    ledger = args.ledger.resolve()
    def reject(request: httpx.Request) -> httpx.Response:
        raise AssertionError("Chế độ offline không được gọi mạng")
    with PriorRunLock(ledger.parent / (ledger.name + ".lock"), "shared-account-ledger-v2"):
        pacer = GroqPacer(ledger, policy=args.quota_policy)
        transport = httpx.MockTransport(reject) if offline else PacedGroqTransport(pacer)
        with httpx.Client(transport=transport, timeout=90.) as client:
            builder = make_builder(inputs, key, client)
            if args.preflight:
                token = ENABLED.set(True)
                try:
                    first = len(pacer.state["requests"])
                    with invocation_scope("preflight"):
                        preflight(builder)
                    pacer.state["preflight"] = {"status": "PASS", "plan_sha256": canonical_hash(plan),
                        "request_ids": [r["id"] for r in pacer.state["requests"][first:]]}
                    pacer.save()
                finally:
                    ENABLED.reset(token)
                return
            if args.run:
                proof = pacer.state.get("preflight", {})
                successful = {r["model"] for r in pacer.state["requests"] if r["id"] in proof.get("request_ids", []) and r["status"] == 200}
                if proof.get("plan_sha256") != canonical_hash(plan) or successful != set(inputs["limits"]):
                    raise ValueError("Cần preflight text/vision PASS đúng plan trước run")
            config = inputs["signal_config"]
            engine = BacktestEngine({**config["models"], "language": config["language"],
                "alpha_norm_method": config["norm_method"], "alpha_weights": config["alpha_weights"]})
            runner = PriorBacktestRunner(engine, adapter, builder, before_point=pacer.before_point,
                quota_policy=pacer.policy, durable_stages=True,
                extra_source_paths=(args.plan.resolve().relative_to(ROOT).as_posix(),))
            result = runner.run_cohort(plan, output_dir=args.output_dir, symbols=args.symbol, resume=args.resume,
                verify_only=args.verify_only, reconcile=args.reconcile,
                authorize_replay=args.authorize_replay, replay_reason=args.replay_reason, ledger_path=ledger)
            if not args.reconcile:
                from core.research_metrics import http_telemetry
                from core.research_cohort import save_envelope
                result["telemetry"] = http_telemetry(pacer.state["requests"], result["run_signatures"], pacer.state.get("invocations"))
                if getattr(args, "verify_report", False):
                    from core.paired_candidate_report import read_report
                    read_report(args.output_dir / "report.json", result)
                if getattr(args, "select_candidate", False) or getattr(args, "verify_selection", False):
                    from core.candidate_selection import read_selection, write_selection
                    from core.prior_run_lock import safe_path
                    destination = safe_path(args.output_dir, args.selection_output)
                    operation = read_selection if args.verify_selection else write_selection
                    result = operation(destination, args.output_dir / "report.json", result, gates_path=args.technical_gates)
                if args.run:
                    save_envelope(args.output_dir / "report.json", result)
            print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except PilotStop as error:
        print(f"Pilot dừng có kiểm soát: {error}", flush=True)
        sys.exit(2)
    except KeyboardInterrupt:
        print("Đã ngắt pilot; giữ checkpoint, kiểm --verify-only trước --run --resume", flush=True)
        sys.exit(130)

"""Giữ log và receipt của lượt gate cuối, không thay bằng chứng W10."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
qa = Path(__file__).parent
sys.path.insert(0, str(root))
from core.bic_icl_protocol import CohortSources, code_identity
from core.candidate_selection import read_technical_gates
from core.historical_signals import digest
from core.research_cohort import read_envelope
from core.research_input_lock import _write_once, runtime_identity

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

plan_path = root/'outputs/bayesian_benchmark/bic_icl_v2/development_plan_release_v2.json'
plan = read_envelope(plan_path)
old = read_envelope(root/'outputs/bayesian_benchmark/bic_icl_v2/development_plan_v1.json')
assert [k for k in plan if plan[k] != old[k]] == ['code_sha256']
assert read_technical_gates(root/'docs/plan/week10/validation_gates/revision_v1/technical_gates.json', old)['status'] == 'PASS'
assert plan['code_sha256'] == code_identity() and plan['runtime'] == runtime_identity()
identity = json.loads((qa/'gates_final/identity.json').read_text('utf8'))
assert all(hashlib.sha256((root/n).read_text('utf8').encode()).hexdigest() == h for n,h in identity['files'].items())
summary = json.loads((qa/'gates_final/summary.json').read_text('utf8'))
assert [r['gate'] for r in summary] == ['compileall','unit','e2e','leakage']
assert all(r['exit_code'] == 0 for r in summary)
target = root/'docs/plan/week11/validation_gates/development_v1'
target.mkdir(parents=True,exist_ok=True)
checks = {}
for result in summary:
    name = result['gate']
    source = qa/'gates_final'/(name+'.log')
    if name in ('unit','leakage'):
        inventory = json.loads((qa/f'gates_final/{name}_inventory.json').read_text('utf8'))
        assert inventory['expected'] == inventory['actual']
        results = sorted((json.loads(p.read_text('utf8')) for p in (qa/'gates_final').glob(name+'_*.result.json')),key=lambda r:r['module'])
        assert len(results) == result['modules'] and sum(r['run'] for r in results) == result['tests']
        assert Counter(i for r in results for i in r['ids']) == Counter(inventory['expected'])
        assert all(r['success'] and r['run'] == r['expected'] and all(r[k] == 0 for k in
            ('failures','errors','skipped','expected_failures','unexpected_successes')) for r in results)
        lines = ['Lượt gate cuối: bốn process, chia nguyên module, giữ thứ tự nội bộ.',
            'Multiset ID khớp unittest discover, giữ cả bội số; log worker/inventory trong development_release_v1.zip.',
            'SHA-256 inventory: '+sha(qa/f'gates_final/{name}_inventory.json')]
        lines += [f"{r['module']}: PASS, {r['run']} tests, {r['elapsed_seconds']:.6f}s" for r in results]
        lines += ['',f"Ran {result['tests']} tests in {result['elapsed_seconds']:.6f}s",'', 'OK','']
        source = qa/(name+'_aggregate.log')
        source.write_text('\n'.join(lines),encoding='utf8')
    dest = target/(name+'.log')
    if dest.exists():
        assert dest.read_bytes() == source.read_bytes()
    else:
        dest.write_bytes(source.read_bytes())
    checks[name] = {'status':'PASS','exit_code':0,'log':{'path':dest.name,'sha256':sha(dest)}}
gates = target/'technical_gates.json'
_write_once(gates,{'gate_version':'research_technical_gates_v1','code_sha256':plan['code_sha256'],
    'runtime':plan['runtime'],'checks':checks})
assert read_technical_gates(gates,plan)['status'] == 'PASS'
freeze = {'freeze_version':'bic_icl_development_source_freeze_v1','base_commit':
    subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'plan':{'path':plan_path.relative_to(root).as_posix(),'sha256':sha(plan_path),
        'payload_sha256':digest(plan),'mtime_ns':plan_path.stat().st_mtime_ns},
    'code_normalization':'UTF8_LF','code_sha256':plan['code_sha256'],'runtime':plan['runtime'],
    'gate_source_sha256':identity['files'],'source_hashes':plan['source_hashes'],
    'legacy_plan_changed_fields':['code_sha256'],'protocol_unchanged':True,
    'technical_gates_sha256':sha(gates),'confirmation_allowed':False}
_write_once(qa/'source_freeze.json',freeze)
print({'status':'PASS','gate_tests':[(r['gate'],r.get('tests')) for r in summary],
    'dependencies':len(plan['code_sha256']),'gate_files':len(identity['files']),
    'plan_sha256':sha(plan_path),'technical_gates_sha256':sha(gates)},flush=True)

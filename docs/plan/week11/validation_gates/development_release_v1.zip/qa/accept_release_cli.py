"""CLI thật offline và guard trước credential, giữ nguyên ledger/plan/snapshot."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
qa = Path(__file__).parent
sys.path.insert(0,str(root))
from core.research_cohort import read_envelope
from core.bic_icl_runtime import hashlib_sha
from core.groq_pacing import tokenizer_cached

plan = 'outputs/bayesian_benchmark/bic_icl_v2/development_plan_release_v2.json'
run = 'outputs/bayesian_benchmark/bic_icl_v2/development_run_release_v2'
gates = 'docs/plan/week11/validation_gates/development_v1/technical_gates.json'
release = 'docs/plan/week11/development_release_v1.json'
producer = ['py','-3.13','-X','utf8','scripts/prepare_bic_icl_release.py','--technical-gates',gates]
runner = ['py','-3.13','-X','utf8','scripts/run_bic_icl.py']
payload = read_envelope(root/release)
assert tokenizer_cached(), 'Thiếu cache tokenizer đúng checksum'
protected = [root/plan,root/release,*(root/run/n for n in payload['snapshot_sha256'])]
before = {str(p):(p.read_bytes(),p.stat().st_mtime_ns) for p in protected}
ledger = root/'outputs/oos_pilot/api_usage.json'
ledger_before = ledger.read_bytes()
commands = [
    ('release_help',producer+['--help'],0,None),
    ('runner_help',runner+['--help'],0,None),
    ('prepare',runner+['--prepare','--plan',plan],0,'PREPARED'),
    ('dry_run',runner+['--dry-run','--plan',plan],0,'"status": "PASS"'),
    ('fixture',runner+['--economic-fixture'],0,'PASS'),
    ('verify_release',producer+['--verify-only'],0,'VERIFIED'),
    ('reissue',producer+['--issue'],0,'RELEASED'),
    ('wrong_root',runner+['--preflight','--plan',plan,'--output-dir',
        'outputs/bayesian_benchmark/bic_icl_v2/development_forbidden_before_api',
        '--handoff',release,'--technical-gates',gates,'--env-file',str(qa/'does-not-exist.env')],1,
        'Release khác run root hoặc ledger provider chung'),
    ('missing_release',runner+['--run','--plan',plan,'--output-dir',run,
        '--technical-gates',gates,'--env-file',str(qa/'does-not-exist.env')],1,
        'Chưa có release development'),
]
results=[]
for name,args,expected,marker in commands:
    log=qa/(name+'.log')
    with log.open('wb') as stream:
        proc=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
    content=log.read_text('utf-8-sig')
    assert proc.returncode == expected,(name,proc.returncode,content[-2000:])
    assert marker is None or marker in content,(name,content[-1000:])
    assert ledger.read_bytes() == ledger_before
    assert all((Path(p).read_bytes(),Path(p).stat().st_mtime_ns)==values for p,values in before.items())
    results.append({'name':name,'argv':args,'exit_code':proc.returncode,'log_sha256':hashlib_sha(log)})
    print(name,proc.returncode,flush=True)
assert not (root/'outputs/bayesian_benchmark/bic_icl_v2/development_forbidden_before_api').exists()
assert not (root/run/'decision_blocks').exists()
assert not list((root/run).glob('report_*.json'))
result={'status':'PASS','commands':results,'ledger_bytes_unchanged':True,
    'tokenizer_cache':'PASS',
    'plan_release_snapshot_bytes_and_mtime_unchanged':True,'real_http_calls':0,
    'primary_initialized':False,'confirmation_allowed':False}
(qa/'cli_acceptance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print('PASS: CLI offline/guard và mọi artifact khoa học bất biến',flush=True)

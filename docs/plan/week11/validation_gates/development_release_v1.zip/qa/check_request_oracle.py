"""Oracle độc lập cho rotation, shared-off/alias và duplicate trên 60 point thật."""
from collections import Counter
import json
from pathlib import Path
import sys

root = Path.cwd()
qa = Path(__file__).parent
sys.path[:0] = [str(root/'tests'),str(root)]
from bic_icl_fixture import DecisionFixture
from core.bic_icl_release import request_manifest
from core.historical_signals import digest
from core.research_cohort import read_envelope

plan = read_envelope(root/'outputs/bayesian_benchmark/bic_icl_v2/development_plan_release_v2.json')
frozen = json.loads((qa/'cohort_packets.json').read_text('utf8'))
assert frozen['plan_sha256'] == digest(plan)
packets, lock = frozen['packets'], frozen['context_lock']
sdk = DecisionFixture()
try:
    manifest = request_manifest(plan,packets,lock,sdk.llm)
    assert not sdk.requests
finally:
    sdk.close()
sample = {r['point_id'] for r in lock['repeat_sample']}
counter = Counter()
for r in (0,1,2,3):
    selected = packets if r == 0 else [p for p in packets if p['point_id'] in sample]
    actual = [b for b in manifest['blocks'] if b['repeat_id'] == r]
    assert len(actual) == len(selected)
    for j,(block,packet) in enumerate(zip(actual,selected)):
        others = lock['matrix'][1:]+(['original_duplicate'] if r else [])
        shift = (j if r == 0 else 3*j+r-1) % len(others)
        names = ['original',*others[shift:],*others[:shift]]
        assert block['point_index'] == j and block['point_id'] == packet['point_id']
        assert names == [s['branch_id'] for s in block['requests']]
        previous = []
        original = block['requests'][0]
        for slot in block['requests']:
            name = slot['branch_id']
            request = packet['requests']['original' if name == 'original_duplicate' else name]
            assert slot['request_sha256'] == digest({**request,'branch_id':name})
            source,origin = None,'independent_duplicate' if name == 'original_duplicate' else 'independent'
            if name not in ('original','original_duplicate'):
                if not request['prefix'] and slot['contract'] == original['contract']:
                    source,origin = 'original','shared_original'
                elif name in ('R_pool_stats_only','R_task_stats_only'):
                    for prior in previous:
                        if (prior['branch_id'] in ('R_pool_stats_only','R_task_stats_only')
                                and prior['contract'] == slot['contract']
                                and packet['requests'][prior['branch_id']]['base_evidence_sha256'] == request['base_evidence_sha256']):
                            source,origin = prior['branch_id'],'stats_alias'
                            break
            assert (slot['source_branch'],slot['decision_origin']) == (source,origin)
            previous.append(slot)
            counter[f'{r}:{origin}'] += 1
        if r:
            duplicate = next(s for s in block['requests'] if s['branch_id'] == 'original_duplicate')
            assert duplicate['contract'] == original['contract'] and duplicate['source_branch'] is None
assert manifest['logical_slots'] == 804 and len(manifest['blocks']) == 96
result = {'status':'PASS','blocks':96,'logical_slots':804,'independent_slots':manifest['independent_slots'],
    'slot_counts':dict(sorted(counter.items())),'independent_duplicates':36,'decision_calls':0,
    'request_manifest_sha256':digest(manifest),'context_lock_sha256':digest(lock),'confirmation_allowed':False}
(qa/'request_oracle.json').write_text(json.dumps(result,indent=2),encoding='utf8')
(qa/'request_manifest_expected.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print(result,flush=True)

"""Đóng nguyên byte bằng chứng release và source đã qua gate cuối."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

root=Path.cwd()
qa=Path(__file__).parent
sys.path.insert(0,str(root))
from core.bic_icl_protocol import code_identity
from core.bic_icl_runtime import hashlib_sha
from core.candidate_selection import read_technical_gates
from core.historical_signals import digest
from core.research_cohort import read_envelope
from core.research_input_lock import runtime_identity

freeze=read_envelope(qa/'source_freeze.json')
plan_path=root/freeze['plan']['path']
plan=read_envelope(plan_path)
assert freeze['code_sha256']==code_identity() and freeze['runtime']==runtime_identity()
assert hashlib_sha(plan_path)==freeze['plan']['sha256'] and plan_path.stat().st_mtime_ns==freeze['plan']['mtime_ns']
assert all(hashlib.sha256((root/n).read_text('utf8').encode()).hexdigest()==h for n,h in freeze['gate_source_sha256'].items())
gates=root/'docs/plan/week11/validation_gates/development_v1/technical_gates.json'
assert read_technical_gates(gates,plan)['status']=='PASS'
release_path=root/'docs/plan/week11/development_release_v1.json'
release=read_envelope(release_path)
run=Path(release['run_binding']['run_root'])
manifest=read_envelope(run/'request_manifest.json')
request_oracle=json.loads((qa/'request_oracle.json').read_text('utf8'))
oracle=json.loads((qa/'oracle_result.json').read_text('utf8'))
assert manifest==json.loads((qa/'request_manifest_expected.json').read_text('utf8'))
assert digest(manifest)==request_oracle['request_manifest_sha256']==release['request_manifest_sha256']
assert oracle['context_lock_sha256']==request_oracle['context_lock_sha256']==release['decision_context_lock_sha256']
cli=json.loads((qa/'cli_acceptance.json').read_text('utf8'))
assert cli['status']=='PASS' and cli['real_http_calls']==0
baseline=json.loads((qa/'baseline.json').read_text('utf8'))
unchanged={n:h for n,h in baseline.items() if n!='tests/test_bic_icl_cohort_cli.py'}
assert all((root/n).is_file() and hashlib_sha(root/n)==h for n,h in unchanged.items())
summary=json.loads((qa/'gates_final/summary.json').read_text('utf8'))
integrity={'status':'PASS','old_files_unchanged':len(unchanged),'source_files':len(freeze['source_hashes']),
    'code_dependencies':len(freeze['code_sha256']),'gate_source_files':len(freeze['gate_source_sha256']),
    'plan_changed_fields':['code_sha256'],'scientific_protocol_unchanged':True,
    'blocks':96,'logical_slots':804,'independent_slots':manifest['independent_slots'],
    'real_http_calls':0,'api_release_issued':True,'confirmation_allowed':False}
(qa/'integrity.json').write_text(json.dumps(integrity,indent=2),encoding='utf8')
members={}
for path in (qa/'gates_final').iterdir():
    if path.is_file():
        if '_worker_' in path.name and path.stat().st_mtime_ns < (qa/'gates_final/identity.json').stat().st_mtime_ns:
            continue
        members['qa/gates_final/'+path.name]=path
for name in ('module_worker.py','run_full_gates.py','cohort_oracle.py','oracle_result.json','cohort_packets.json',
    'check_request_oracle.py','request_oracle.json','request_manifest_expected.json','finalize_gates.py',
    'source_freeze.json','accept_release_cli.py','cli_acceptance.json','archive_release.py','integrity.json',
    'test_isolation.log','issue_release.log'):
    members['qa/'+name]=qa/name
for row in cli['commands']:
    members['qa/'+row['name']+'.log']=qa/(row['name']+'.log')
for path in gates.parent.iterdir():
    if path.is_file():members[path.relative_to(root).as_posix()]=path
for path in (release_path,plan_path,root/'docs/plan/week11/.gitattributes'):
    members[path.relative_to(root).as_posix()]=path
for name in release['snapshot_sha256']:
    path=run/name
    assert hashlib_sha(path)==release['snapshot_sha256'][name]
    members[path.relative_to(root).as_posix()]=path
for name in freeze['gate_source_sha256']:
    members['source/'+name]=root/name
index={'version':'bic_icl_development_release_evidence_v1','gate_summary':summary,'integrity':integrity,
    'files':{n:hashlib_sha(p) for n,p in sorted(members.items())}}
target=root/'docs/plan/week11/validation_gates/development_release_v1.zip'
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for n,p in sorted(members.items()):archive.writestr(n,p.read_bytes())
    archive.writestr('manifest.json',json.dumps(index,ensure_ascii=False,indent=2).encode())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist())==len(set(archive.namelist()))==len(members)+1
    assert all(hashlib.sha256(archive.read(n)).hexdigest()==h for n,h in index['files'].items())
result={'status':'PASS','path':target.relative_to(root).as_posix(),'sha256':hashlib_sha(target),
    'entries':len(members)+1,'bytes':target.stat().st_size,'integrity':integrity,
    'plan_sha256':hashlib_sha(plan_path),'release_sha256':hashlib_sha(release_path),
    'technical_gates_sha256':hashlib_sha(gates),'context_lock_sha256':release['decision_context_lock_sha256'],
    'request_manifest_sha256':release['request_manifest_sha256']}
(qa/'archive_receipt.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(result,flush=True)

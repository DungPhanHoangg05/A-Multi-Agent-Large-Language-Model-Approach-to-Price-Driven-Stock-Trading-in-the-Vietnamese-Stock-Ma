# Phase D — kiểm thử, hiệu năng và bàn giao W4

**Trạng thái: Phase D và W3 hoàn thành ngày 05/10/2026, W3-13..16 đã chốt.**
[Biên bản bàn giao W4](week_close_and_handoff.md), [receipt cuối](week_close_review.json)
xác minh API/example, thư mục mới, bốn gate và p95 từng mode. Cap/guard runtime
và giá kiểm định 2023–2024 là đầu việc tiếp theo, ngoài gate offline W3.
Smoke [receipt](prior_smoke.json) không thay benchmark p95 hoặc gate runtime W4.

## W3-13 — hành vi và zero-leakage

- [x] Hợp nhất test truy vấn/mode/stats/prefix đã làm; bổ sung lỗi đầu vào và serializable.
- [x] `tests/test_bayesian_retriever_leakage.py`: mọi mode loại `exit_date == cutoff`,
  `exit_date > cutoff` và episode bắt đầu trước nhưng kết thúc sau cutoff.
- [x] Thêm/đổi record tương lai trong fixture hợp lệ không đổi IDs, stats hoặc prefix
  của query cũ; kiểm cả cache khi lần lượt gọi ngày sau rồi ngày trước.
- [x] Sai hậu điều kiện từ nguồn eligible bị giả lập phải ném lỗi, không silently lọt prior.
- [x] Tách query signals khỏi outcome; kiểm không thay state/record giữa các nhánh.
- [x] Prefix không chứa nhãn kết quả của test point; thống kê không nhìn toàn kho
  khi cutoff lịch sử loại một phần record.

## W3-14 — benchmark retrieval

File đã có `scripts/benchmark_bayesian_retriever.py`, [receipt PASS](retrieval_benchmark.json)
và biên bản hiệu năng bên dưới; giữ các lượt FAIL để đối chiếu.

**Phép đo đề xuất khóa tại W3-01 trước khi chạy benchmark:**

- Dùng kho thật 852 record và query cố định bao phủ bốn mã/bốn regime, K=3;
  ghi nguồn regime của query. Cùng tập query/config cho mọi mode.
- Đo cold load/xác minh kho riêng; hot query gồm lọc eligible, ranking, thống kê,
  metadata và deep copy. Đo formatter riêng và end-to-end retrieval+format riêng.
- Dùng `perf_counter_ns`, 100 lượt warm-up/mode và ít nhất 1.000 lượt đo/mode;
  luân phiên query để không chỉ đo một điểm cache trúng. Ghi query count, cache và
  min/median/p95/max; đo tuần tự để tránh nhiễu tranh tài nguyên.
- **Gate retrieval:** p95 hot query **<30 ms ở từng mode**, không chỉ trung bình gộp.
  Không tính I/O nạp kho/LLM vào gate; vẫn báo thời gian cold load công khai.
- Ghi Python/dependency/CPU/OS, bank hash, seed/config, phương pháp percentile và ngày đo.
  Threshold không đặt làm unit test thời gian dễ chập chờn trên máy khác.

**Tập query và cách tính đã khóa cho lượt chạy:** 16 context `observed` của
[smoke W3-12](prior_smoke.json), một context/mã/regime, với hai scope
`pooled` và `same_symbol`: 32 query/mode, K=3, seed=42. Xếp context theo
symbol/regime rồi scope; mỗi giai đoạn luân phiên `index % 32`, bắt đầu lại ở
index=0 sau warm-up. Mỗi giai đoạn có 100 warm-up và 1.000 mẫu/mode, đo tuần tự.
P95 dùng nearest-rank `ceil(0.95*n)-1` trên mẫu ns đã sắp tăng; xét gate bằng ns
chưa làm tròn. Không bỏ outlier; giữ GC mặc định và không cache kết quả query/ranking.
Gate là p95 retrieval từng mode trên tập query chung; thống kê từng scope để
chẩn đoán, formatter và retrieval+format được báo riêng. Cold load chỉ bao
constructor/xác minh kho/giá/P&L/snapshot, không bao import hoặc preflight.

Script đối chiếu hash archive/giá/kho/model của smoke trước/sau phép đo,
kiểm nguồn tín hiệu/regime PIT từ checkpoint, kiểm ranking/counts/prefix bằng
oracle và receipt đóng băng trước đo. Mọi kết quả đo được đối chiếu ngoài timer;
hot query chặn loader giá, đọc JSON, network, signal extractor, runner và HMM fit.
Mẫu ns thô và môi trường được giữ trong receipt để tính lại percentile.

- [x] Script/receipt tái lập, đủ bốn mode và môi trường.
- [x] Nếu vượt ngưỡng: chỉ tối ưu nút chậm đã đo; không bỏ validation/cutoff/deep copy.
- [x] Sau tối ưu chạy lại test liên quan và benchmark cùng phép đo; không đổi gate
  sau khi nhìn kết quả để báo PASS.

## W3-15 — gate tích hợp

Chạy tại thư mục gốc repo:

```powershell
py -3.13 -m compileall agents core data_manager scripts tests utils
py -3.13 -X utf8 -m unittest discover -s tests -v
py -3.13 scripts/run_end_to_end_test.py
py -3.13 -X utf8 -m unittest discover -s tests -p 'test_*leakage.py' -v
```

- [x] Bốn gate PASS; ghi số test/thời gian/commit, không dùng kết quả W2 thay kết quả W3.
- [x] Diff không đổi engine P&L, upstream ghép cặp, artifact kho/model hoặc cơ chế retry.
- [x] Gate smoke/600 ký tự/6.500 ký tự/30 ms có bằng chứng trước merge. Prompt
  <6.500 là kiểm chứng offline với cap bàn giao; cap/guard runtime vẫn thuộc W4.

Bằng chứng chốt: [receipt tích hợp](integration_gate_review.json),
[ngân sách hiện tại](prompt_budget_review.json), [smoke hiện tại](prior_smoke.json),
[benchmark hiện tại](retrieval_benchmark_integration.json). Chi tiết lượt chạy ở
nhật ký W3-15 cuối file.

## W3-16 — chốt và bàn giao

- [x] Đủ module, formatter, unit/leakage tests, smoke, benchmark, đặc tả đã khóa.
- [x] Ghi API/example cho W4: regime PIT và tín hiệu hiện tại vào query; tasks/stats,
  BRPP/IDs/hash/seed/fallback ra ngoài; Original K=0 không nhận prefix.
- [x] Nêu rõ việc W4 cần làm: trường state, inject Decision, ablation flag, checkpoint
  metadata, paired upstream và chốt giới hạn prompt tại runtime. Theo
  [receipt W3-11](prompt_budget_review.json), cap cũ tổng 4.500 vượt trần khi ghép
  BRPP: phải áp dụng cap bàn giao tổng 4.000 (hoặc kiểm chứng phương án khác) và
  guard `<6500` sau toàn bộ hướng dẫn. Không lấy PASS offline làm PASS runtime.
- [x] Giữ giới hạn tin/độ phủ/gate giá 2023–2024; W3 không phát hành kết quả lợi nhuận OOS.
- [x] Cập nhật README W3, kế hoạch tổng và biên bản chốt; Conventional Commit/merge
  từ nhánh task vào `develop` sau đủ gate; không đưa mã tuần/ngày vào commit message.

Nghiệm thu/bàn giao: [biên bản W3-16](week_close_and_handoff.md). Thư mục tuần
theo cấu trúc người dùng đã chuyển là `docs/plan/week<N>/`; các tuần sau tiếp tục
dùng cùng cây thư mục. Receipt cuối giữ ánh xạ path cũ và hash bằng chứng.

## Kết quả và nhật ký

### 05/10/2026 — W3-13 hoàn thành

**Đầu ra:** mở rộng `tests/test_bayesian_retriever_leakage.py` thêm mười test
`BayesianPriorPipelineLeakageTests`; thêm hai test trong
`tests/test_bayesian_prior_behavior.py`. Fixture chung `tests/bayesian_test_support.py`
có hai mã/tám record, giá và lịch phiên giả lập, nhãn sinh bằng
`compute_round_trip_net_return`; constructor vẫn chạy schema/validator kinh tế thật.
Không sửa code runtime, kho/model, P&L hoặc cơ chế gọi LLM.

#### Phạm vi kiểm chứng

| Yêu cầu | Bằng chứng trong test mới |
| --- | --- |
| Exit bằng cutoff, vắt ngang và sau cutoff | `test_equal_exit_straddling_and_future_query_are_excluded_from_final_evidence`: bốn mode × hai scope × K=1..3, đối chiếu cả tasks/stats/BRPP; n=0/N/A tại exit đầu |
| Thêm tương lai không đổi query cũ | `test_valid_future_append_does_not_change_ids_stats_scores_seed_or_prefix`: record mới qua validator thật; chỉ hash kho đổi |
| Sửa tương lai hợp lệ không đổi query cũ | `test_valid_future_price_signal_regime_and_outcome_changes_leave_old_prefix_unchanged`: sửa giá sau cutoff, tín hiệu/regime của chu kỳ chưa đóng, sinh lại nhãn bằng engine; kiểm cả bốn mode/hai scope |
| Ngày sau rồi ngày trước | `test_late_queries_then_early_queries_cannot_reuse_future_stats_or_prefix`: query sau có nhiều history hơn; query cũ nhận lại nguyên bundle, không dùng pool/stats/prefix ngày sau |
| Source/bộ chọn/population sai phải gây lỗi | Ba test `test_poisoned_eligible_sources_fail_before_prefix_in_every_mode_and_scope`, `test_corrupt_selectors_cannot_inject_a_future_task_into_prefix`, `test_poisoned_statistics_population_fails_after_selection_before_prefix`: future/equal/duplicate/unknown ID/NaN/scope/regime/nhãn sai → ValueError **trước formatter**, không lọc âm thầm |
| Query không cung cấp outcome | `test_query_outcome_and_query_id_cannot_appear_in_prior_evidence`: query có WIN ở tương lai nhưng bị loại; prior cùng mã chỉ 1/2 WIN, ngày/ID query không vào prefix hoặc selected IDs |
| Cách ly nhánh và input | `test_branch_mutations_do_not_change_shared_query_bank_or_other_bundles`: cùng object tín hiệu cho các nhánh; sửa tasks/stats/metadata nhánh trả về không đổi query, kho, nhánh khác hoặc lần truy vấn mới |
| Không ranking bằng nhãn | `test_past_labels_change_evidence_but_never_select_winners_by_outcome`: đổi giá/nhãn **đã đóng** hợp lệ thì stats/BRPP đổi, nhưng IDs/scores/seed giữ nguyên; không đòi evidence bất biến khi lịch sử đã biết thay đổi |
| Validation và JSON toàn pipeline | Hai test behavior: 56 cấu hình input sai bị từ chối trước truy cập pool, kể cả K=0; 256 tổ hợp mode/scope/regime/K=0..3 serialize JSON strict bằng kiểu Python gốc, không I/O query hoặc sửa input |

Các test cũ giữ nguyên; dùng `unittest discover` để hợp nhất suite, không copy hoặc
viết lại test thuật toán. Phạm vi các file và số test method:

| File `tests/` | Số test | Phạm vi |
| --- | ---: | --- |
| `test_bayesian_retriever.py` | 11 | Kho/QA/query/pool/hậu điều kiện nền |
| `test_bayesian_recent_random.py` | 7 | Thứ tự/seed/RNG/thiếu mẫu/metadata |
| `test_bayesian_similarity.py` | 9 | Score/alias/tie-break/không ranking bằng outcome |
| `test_bayesian_regime_selection.py` | 9 | Population cùng regime/scope và bộ chọn Bayesian |
| `test_bayesian_statistics.py` | 11 | Counts/mẫu số/null/zero-return/deep copy |
| `test_bayesian_prior_prefix.py` | 13 | Template/schema/nhãn/600/NFC/lỗi formatter |
| `test_bayesian_prompt_budget.py` | 9 | Biên 600/prompt VI-EN/ngân sách bàn giao W4 |
| `test_bayesian_prior_smoke.py` | 6 | Receipt kho thật/nguồn PIT/biên/từ chối bằng chứng sai |
| `test_bayesian_retriever_leakage.py` | 18 | Tám test nền và mười test toàn pipeline |
| `test_bayesian_prior_behavior.py` | 2 | Validation/JSON toàn pipeline |
| **Tổng** | **95** | Unit/API độc lập và kiểm chứng offline |

Lệnh chạy suite hợp nhất:

```powershell
py -3.13 -X utf8 -m unittest discover -s tests -p 'test_bayesian*.py' -v
```

**Kết quả W3-13:** suite **95/95** test Bayesian PASS (3,854 giây); cả bốn gate
tích hợp task PASS:

| Gate | Kết quả |
| --- | --- |
| Compileall `agents core data_manager scripts tests utils` | PASS |
| Unit tests toàn hệ thống | **330/330 PASS**, 48,346 giây |
| E2E xác định | **PASS**, 7,2 giây |
| `test_*leakage.py` toàn hệ thống | **56/56 PASS**, 5,360 giây |

Lệnh bốn gate là khối trong mục W3-15 phía trên; kết quả này là lượt tích hợp
**W3-13**, chưa đánh dấu W3-15 hoàn thành. Hash nguồn/bằng chứng receipt W3-11/12,
liên kết Markdown và `git diff --check` được kiểm trước commit.
Nhánh `test/prior-zero-leakage-suite` tích hợp sau gate. Phải chạy lại gate chốt
tuần sau benchmark W3-14 và mọi tối ưu cần thiết. Chưa có phép đo p95 hoặc bàn giao
chốt W3-16; ngân sách runtime W4/gate giá kiểm định 2023–2024 và giới hạn thiếu tin
vẫn còn. Các receipt trước được giữ nguyên vì code/corpus được chúng xác minh không đổi.

### 05/10/2026 — W3-14: benchmark và tối ưu theo profile

Các lượt đo dùng cùng cấu hình đã khóa, không bỏ mẫu ngoại lai hay đổi ngưỡng.
Lượt đầu được giữ ở [baseline](retrieval_benchmark_baseline.json); sau tối ưu
sao chép giữ ở [lượt sao chép](retrieval_benchmark_copy.json). Cả hai FAIL và
không được dùng làm bằng chứng gate PASS.

| Mode | p95 baseline (ms) | p95 sau tối ưu sao chép (ms) |
| --- | ---: | ---: |
| bayesian_regime | 65,811 | 34,304 |
| random | 44,009 | 32,105 |
| recent | 64,646 | 34,868 |
| similarity | 73,237 | 41,645 |

[Profile](retrieval_profile.json) của 64 query pooled (bốn mode × 16 context)
ghi tổng 17,126 giây dưới cProfile; `deepcopy` chiếm 12,697 giây (~74,1%),
`_assert_pool` 3,263 giây (~19,1%, gồm so snapshot). Thời gian profile có overhead,
chỉ dùng xác định nút chậm, không xét gate bằng số này.

- `copy_historical_records`: với schema phẳng và lá bất biến, tạo mới list,
  dict record, dict tín hiệu và dict outcome. Không chia sẻ dữ liệu khả biến.
  Record khác cấu trúc hoặc chứa kiểu khác đi qua `deepcopy`, không ép kiểu hay
  tự sửa lỗi; validator và đối chiếu snapshot vẫn từ chối như trước.
- `_matches_snapshot`: kiểm key/kiểu/giá trị các lá ngay tại vòng lặp, chỉ đệ quy
  ở dict con, tránh lời gọi hàm/generator cho từng scalar. Giữ kiểm đầy đủ từng
  trường, không dùng hash thay cho đối chiếu dữ liệu và không cache query/stats.
- Các receipt W3-11/W3-12 được giữ như snapshot của phiên bản trước tối ưu.
  Benchmark mới kiểm nguồn PIT/hash của archive không đổi và dùng oracle độc lập
  để đối chiếu output hiện tại với smoke cũ. Khi chạy lại verifier đầy đủ W3-12,
  phải chạy lại kiểm ngân sách W3-11 trước vì hash module đã thay đổi; không bỏ guard hash.

**Kết quả cuối — [receipt PASS](retrieval_benchmark.json):**

| Mode | Retrieval min / median / p95 / max (ms) | Formatter p95 (ms) | Retrieval+format p95 (ms) |
| --- | --- | ---: | ---: |
| bayesian_regime | 2,393 / 7,554 / **15,809** / 23,508 | 0,119 | 16,442 |
| random | 2,342 / 6,926 / **14,812** / 20,807 | 0,046 | 14,913 |
| recent | 2,310 / 6,805 / **14,179** / 21,416 | 0,044 | 14,382 |
| similarity | 3,167 / 10,141 / **18,239** / 159,908 | 0,041 | 18,372 |

Gate là **p95**, không phải mọi mẫu <30 ms; mẫu max/outlier vẫn được giữ.
Mỗi scope có 500 mẫu/mode/giai đoạn; p95 pooled lần lượt
16,237 / 15,633 / 14,500 / 18,785 ms (scope chỉ là chẩn đoán bổ sung).
Cold constructor **9.155,388 ms** (baseline 18.000,227 ms), không đưa vào gate.
Đo trên Windows 11 build 26200, CPU Intel64 Family 6 Model 183 Stepping 1,
24 CPU logic, Python **3.13.5**, NumPy 2.1.2/Pandas 2.3.3/SciPy 1.16.1/hmmlearn 0.3.3;
GC bật. Tải nền/CPU có thể ảnh hưởng thời gian; số đo chỉ áp dụng môi trường/lượt
chạy được ghi, không khẳng định p95 trên máy khác hoặc hiệu quả giao dịch.

Hash kho vẫn `09b48c6192a092b562173e8b3b7eceb44025c6e02454093e34214a730a460949`.
Không thay nhãn P&L, snapshot nguồn, model, kho, retry hay upstream. Receipt lưu
hash nguồn code hiện tại và 12.000 mẫu ns (4 mode × 3 giai đoạn × 1.000).
Chín test mới kiểm timer/rotation/p95/gate nghiêm ngặt, context PIT,
bản sao sâu/nhánh dự phòng và so snapshot chặn NumPy/NaN/sai key/giá trị.

**Lệnh chạy lại** (đóng các tiến trình test/benchmark cạnh tranh, cần archive
local đã đóng băng; dùng tên receipt mới để không ghi đè bằng chứng):

```powershell
py -3.13 -X utf8 scripts/benchmark_bayesian_retriever.py --output docs/plan/week3/retrieval_benchmark_rerun.json
```

Mặc định `--warmup 100 --samples 1000`; CLI từ chối giảm dưới mức đã khóa.
Nếu gate FAIL vẫn ghi receipt và thoát mã 1. Không chạy runner tạo episode,
không fit model hoặc gọi API để bổ sung dữ liệu còn thiếu.

**Bốn gate tích hợp W3-14:**

| Gate | Kết quả |
| --- | --- |
| Compileall `agents core data_manager scripts tests utils` | PASS |
| Unit tests toàn hệ thống | **339/339 PASS**, 49,850 giây (gồm **104** test Bayesian) |
| E2E xác định | **PASS**, 7,0 giây |
| `test_*leakage.py` toàn hệ thống | **56/56 PASS**, 5,206 giây |

Lệnh là khối bốn gate ở mục W3-15. Đây là lượt tích hợp task **W3-14**;
W3-15/W3-16 còn việc chốt bằng chứng/bàn giao và chưa được đánh dấu hoàn thành.
Nhánh `test/retriever-performance-benchmark` tích hợp vào `develop` sau gate;
không push. Ngân sách prompt runtime W4 và gate giá kiểm định 2023–2024 vẫn chưa mở.

### 05/10/2026 — W3-15 hoàn thành: gate tích hợp sau tối ưu

**Phiên bản kiểm:** commit nền `5e720ab` trên nhánh `test/prior-integration-gates`.
Task chỉ thay tài liệu/receipt; không thay file đã track trong `agents`, `core`,
`data_manager`, `scripts`, `tests`, `utils`, `data`, `outputs`. Hash các file này và
bằng chứng kho/giá/archive/model được kiểm trước/sau bốn gate, không chỉ xem diff.
[Receipt chốt](integration_gate_review.json) giữ lệnh chính xác, mã thoát, thời gian,
hash log và hash nguồn/bằng chứng. Log đầy đủ nằm trong thư mục tạm được ghi trong
receipt, không đưa log test hoặc archive chạy LLM lên Git.

#### Kiểm lại bằng chứng offline

Chạy tuần tự, benchmark kết thúc trước khi bắt đầu các gate để không tranh tài nguyên:

```powershell
py -3.13 -X utf8 scripts/verify_prior_prompt_budget.py
py -3.13 -X utf8 scripts/verify_bayesian_prior.py
py -3.13 -X utf8 scripts/benchmark_bayesian_retriever.py --output docs/plan/week3/retrieval_benchmark_integration.json
```

Đây là lệnh của lượt chốt đã ghi; nếu đo lại, chọn tên `--output` mới.
Benchmark từ chối ghi đè receipt có sẵn để giữ bằng chứng các lượt trước.

- Ngân sách: **1.024 ca PASS**, prompt bàn giao tối đa **6.086**; mọi ca dự phòng
  BRPP đúng **600** ký tự có prompt <6.500, tối đa **6.289**. Cap runtime được
  hoàn trả sau phép kiểm, `runtime_budget_gate_passed=false` vẫn giữ nguyên.
- Smoke: **288 query + 288 lượt lặp PASS** trên 32 context/bốn mode/hai scope,
  BRPP tối đa **373**. Context và kết quả bằng bản trước tối ưu; chỉ đổi hash nguồn,
  hash receipt ngân sách và liên kết bàn giao. Không gọi API/fit HMM/tạo episode.
- Lưu nguyên bản trước refresh ở [ngân sách cũ](prompt_budget_review_before_integration.json)
  và [smoke cũ](prior_smoke_before_integration.json). Receipt benchmark W3-14 giữ
  nguyên như kết quả lịch sử trên bằng chứng cũ; receipt mới dùng hash bằng chứng
  hiện tại. Không tắt guard hash hoặc sửa kết quả cũ để nhận PASS.

| Mode | P95 retrieval chốt (ms) | Gate <30 ms |
| --- | ---: | --- |
| bayesian_regime | 15,522 | PASS |
| random | 13,823 | PASS |
| recent | 13,912 | PASS |
| similarity | 18,299 | PASS |

Giữ phép đo W3-14: 100 warm-up, 1.000 mẫu/mode/giai đoạn, 32 query/mode,
K=3/seed=42, p95 nearest-rank, không loại outlier/cache query. Cold constructor
**8.772,802 ms**, formatter và retrieval+format báo riêng trong receipt;
không tính cold load vào gate, không diễn giải thời gian thành hiệu quả giao dịch.

#### Kết quả bốn gate

| Gate | Kết quả | Thời gian bộ kiểm báo (s) | Thời gian toàn tiến trình (s) |
| --- | --- | ---: | ---: |
| Compileall | PASS | — | 0,152 |
| Unit tests | **339/339 PASS**, gồm 104 Bayesian | 56,360 | 66,063 |
| E2E xác định | PASS | 7,0 | 14,985 |
| `test_*leakage.py` | **56/56 PASS** | 5,196 | 13,403 |

Lệnh là khối bốn gate ở mục W3-15. Thời gian toàn tiến trình bao gồm khởi động/import;
không dùng thời gian unit/leakage của W3-14 hoặc W2 thay lượt chốt này.
Mỗi gate có mã thoát 0 và output thành công; các file được bảo vệ không đổi.
Không mở gate giá 2023–2024, không chạy giao dịch OOS; W4 còn phải áp dụng cap
bàn giao tổng 4.000 và guard prompt cuối `<6500`. **W3-16 còn mở** để chốt
deliverables/API/example và biên bản bàn giao. Nhánh task tích hợp vào `develop`
sau gate theo AGENTS.md, không push.

### 05/10/2026 — W3-16 hoàn thành: chốt tuần và đồng bộ thư mục

Đã bàn giao [deliverables/API/example và thứ tự W4](week_close_and_handoff.md).
Ví dụ replay trong tài liệu được chạy với network bị chặn, đủ bốn mode và
Original K=0 PASS. Dữ liệu/query thật lấy từ context smoke đã xác minh;
không gọi LLM, không fit HMM hoặc tạo episode.

W2/W3 được giữ tại vị trí người dùng chuyển `docs/plan/week2` và
`docs/plan/week3`. Có 12 file Python đổi các literal đường dẫn, đã đối chiếu
với Git nền để xác nhận ngoài đường dẫn không có thay đổi code. Liên kết tài liệu
được rebase; AGENTS.md ghi quy ước các tuần sau. `.gitattributes` bảo toàn byte
receipt JSON tại vị trí mới. Các snapshot JSON cũ giữ nguyên nội dung/byte;
primary ngân sách/smoke refresh có bản lưu trước, metadata path mới và hash mới.

| Kiểm chứng cuối | Kết quả |
| --- | --- |
| Ngân sách prompt offline | 1.024 ca PASS, max 6.086; dự phòng đủ BRPP 600 max 6.289 |
| Smoke trên kho 852 | 288 query + 288 lượt lặp PASS, BRPP max 373, context/output không đổi |
| P95 Bayesian / Random / Recent / Similarity | 15,483 / 13,874 / 13,981 / 17,621 ms, tất cả <30 ms |
| Compileall | PASS, toàn tiến trình 0,148 giây |
| Unit tests | **339/339 PASS**, bộ kiểm 48,904 giây; toàn tiến trình 57,283 giây |
| E2E xác định | **PASS**, bộ kiểm 7,4 giây; toàn tiến trình 15,389 giây |
| Leakage | **56/56 PASS**, bộ kiểm 5,129 giây; toàn tiến trình 13,509 giây |

[Receipt chốt tuần](week_close_review.json) ghi commit nền `9c24790`, cấu hình
đường dẫn, hash nguồn/archived JSON, kết quả example, mã thoát/lệnh và hash log.
[Benchmark mới](retrieval_benchmark_week_close.json) giữ cùng phép đo W3-14 và
mẫu ns thô; cold constructor 9.190,219 ms, formatter/toàn chuỗi báo riêng.
Nguồn code, kho/giá/model và receipt được kiểm hash trước/sau gate.

**W3 hoàn thành 16/16 task.** Runtime W4 vẫn cần state/graph/Decision/paired
checkpoint và cap/guard cuối `<6500`; giá kiểm định 2023–2024 còn gate riêng.
Giới hạn tin NEUTRAL và kho phủ 2020–2022 giữ nguyên. Nhánh
`docs/prior-handoff-close` tích hợp vào `develop` sau đủ gate, không push.

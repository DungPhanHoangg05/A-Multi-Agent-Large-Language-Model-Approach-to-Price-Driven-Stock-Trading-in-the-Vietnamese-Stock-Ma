# Phase B — State, ngân sách prompt và graph

**Trạng thái: W4-05..08 hoàn thành, Phase B 4/4 ngày 06/10/2026;
Gate B PASS offline graph/prompt với verifier/retriever fixture.** [Checklist W4](README.md).
Đầu vào: Gate A và các policy W3. Test mới dưới đây là tên dự kiến;
tái sử dụng test ablation/paired/token hiện có khi phù hợp.

## W4-05 — State/config và validator

**Phụ thuộc:** Gate A. **File chính:** `agents/agent_state.py`,
`utils/graph_setup.py`; helper cấu hình riêng chỉ thêm khi cần.

- [x] Thêm trường theo hợp đồng W4-02 vào đúng TypedDict mà graph thực tế dùng,
  bao gồm `BacktestAgentState`; tránh LangGraph lọc mất prior/provenance.
- [x] Cài parser/validator `prior_config` độc lập với `resolve_ablation_config`;
  default disabled, tên mode/scope/K/seed đúng policy đã khóa.
- [x] Chuẩn hóa dữ liệu JSON về scalar Python/ngày ISO, bản sao task/stats/metadata
  độc lập; giữ DataFrame và đối tượng runtime ngoài phần JSON checkpoint.
- [x] Đường flag off không đòi artifact mới hoặc đọc kho; không nhận prefix còn
  sót từ nhánh trước. Đường enabled không chấp nhận context chưa xác minh nguồn.
- [x] Test schema xuyên graph, flag off/Original, invalid bool/K/mode/scope,
  input thiếu, conflict config và deep copy bằng fixture nhỏ.

**Nghiệm thu 05/10/2026:** `tests/test_prior_runtime_config.py` **28 test PASS**;
bốn ablation cũ và `include_alpha` vẫn đúng hợp đồng. Compileall/**367 unit**/
E2E/**56 leakage** PASS; xem [biên bản](state_config_runtime.md) và
[receipt mới](state_config_runtime_review.json). Kho/spec/receipt Phase A giữ nguyên.

Enabled/Original được parser chấp nhận khi hợp lệ, nhưng graph production
dừng trước node nếu chưa có adapter xác minh nguồn PIT (W4-09). Kiểm
shape/ngày/tín hiệu không là xác minh nguồn. Caller nghiên cứu phải kiểm
state thô trước bộ lọc channel của LangGraph; graph nghiên cứu ở W4-08 còn mở.

## W4-06 — Cap/guard trên prompt runtime

**Phụ thuộc:** W4-05. **File chính:** `agents/decision_agent.py`,
`tests/test_backtest_token_budget.py`, `tests/test_bayesian_prompt_budget.py`.

- [x] Áp dụng cap bàn giao: trend/pattern/indicator 800 mỗi báo cáo, alpha 1.100,
  sentiment 500 (tổng 4.000); giữ `_distill_report`, `_cap_report` và các trường
  tín hiệu/conflict gate/hợp đồng kinh tế được distill giữ lại.
- [x] Chốt phạm vi cap theo hợp đồng: ưu tiên cấu hình backtest phù hợp; rà tác
  động nếu hằng cap dùng chung với đường live. Không hứa prompt giữ nguyên byte
  khi report dài bị cap mới; ghi thay đổi và kiểm hồi quy nội dung bắt buộc.
- [x] Thêm guard `len(final_prompt) < 6500` ở đường backtest, sau BRPP và mọi
  hướng dẫn/schema được thêm vào chuỗi prompt, trước `_invoke_with_retry`.
- [x] Prompt vượt trần báo lỗi độ dài/cấu hình có chẩn đoán; không gọi API, không
  truncate BRPP, xóa task hoặc trả quyết định cash để che lỗi.
- [x] Kiểm VI/EN, daily `1d`/`1 ngày`, đủ/thiếu report, report bão hòa, Unicode,
  stock name dài, reserve BRPP đủ 600; biên 6.499 được phép, 6.500 bị chặn.
- [x] Sửa log ngưỡng cũ 7.500 thành ngưỡng thực tế; ghi riêng cap report,
  prefix length và prompt length. Token/quota thực tế chưa được suy ra từ ký tự.

**Nghiệm thu 06/10/2026:** [biên bản](runtime_prompt_budget.md),
[receipt runtime](runtime_prompt_budget_review.json) PASS: **11 test ngân sách**,
**192 ca node thật**, max 5.688; dự phòng 600 max 6.289. Builder thật tại
6.499/6.500, overflow trước wrapper/API ở text/structured, giữ hợp đồng kinh tế/
conflict, cap live và input. Compileall/**375 unit**/E2E/**56 leakage** PASS.

Guard nằm sau builder hoàn chỉnh; BRPP được kiểm bằng fixture mở rộng template
ở bước này. Chèn BRPP/reasoning production thuộc W4-07 và phải đo lại budget.
Receipt W3/Phase A/W4-05 giữ nguyên; Gate B và budget toàn luồng prior còn mở.

## W4-07 — BRPP và hướng dẫn reasoning

**Phụ thuộc:** W4-06. **File chính:** `agents/decision_agent.py`;
test dự kiến `tests/test_decision_prior_integration.py`.

- [x] Dùng `format_compact_prior_prefix(tasks, stats)` từ module W3; không tự
  tính lại thống kê hoặc xây template khác trong Decision Agent.
- [x] Chèn BRPP trước báo cáo đầu tiên (`### [1]`), đúng một lần. Khi disabled/
  Original prefix rỗng, không để marker, stats hoặc instructions prior còn sót.
- [x] Hướng dẫn dùng regime/stats như bối cảnh rồi đọc tín hiệu hiện tại; prior
  không là quyết định thay agent, không là posterior LLM đã hiệu chuẩn.
- [x] Giữ counts/mẫu số/None và tình trạng thiếu tin; không biến missing thành 0%,
  thêm smoothing hoặc diễn giải WIN/LOSS lịch sử thành nhãn của query.
- [x] Empty/partial hợp lệ giữ nguyên metadata; input/schema/provenance lỗi phải
  dừng. Guard BRPP ≤600 và guard tổng prompt vẫn chạy trên prompt cuối.
- [x] Kiểm cả structured output và đường text hiện có: đều qua `_invoke_with_retry`;
  schema LONG/SHORT và format retry không đổi, lỗi API/output không bị nuốt.

**Nghiệm thu 06/10/2026:** [biên bản](decision_prior_integration.md),
[receipt](decision_prior_integration_review.json): **11 test mới**, năm nhánh,
VI/EN, K=0..3, text/structured, empty/partial/overflow PASS; **128 ca đo runtime**
max 6.264, prefix đúng 600 + reasoning max 6.467. Compileall/**386 unit**/
E2E/**56 leakage** PASS, giữ kho và các receipt trước.

Factory thêm hook verifier nguồn tin cậy; thiếu verifier hoặc source lỗi dừng
trước formatter/API. Verifier fixture chỉ nghiệm thu node/JSON/prompt, không
chứng minh source PIT. Graph vẫn chặn enabled; W4-08/09 tiếp tục nối graph/adapter.

## W4-08 — Ranh giới graph và tương thích

**Phụ thuộc:** W4-05, W4-07. **File chính:** `utils/graph_setup.py`.

- [x] Truyền prior config/state qua graph; kiểm đủ key sau compile/invoke.
- [x] Tạo ranh giới chuẩn bị Full (Alpha/Sentiment) và Decision riêng để caller
  W4-10 có thể dùng chung reports mà không kích hoạt Alpha mỗi nhánh. Giữ
  `compile_upstream()` cho Indicator → Pattern → Trend.
- [x] Chốt node chuẩn bị prior sau khi đủ tín hiệu; chỉ một nơi chịu trách nhiệm
  retrieve/format để không gọi hai lần ở graph và engine. Caller xác minh PIT.
- [x] Giữ `compile_decision()`/`set_graph()` và tham số cũ có hành vi hợp lệ khi
  prior disabled; cấu hình nghiên cứu Full không đổi `ABLATION_CONFIGS`.
- [x] Tổ hợp chưa được đặc tả bị từ chối rõ, không lặng lẽ bỏ prior hoặc bật
  Alpha/Sentiment mà người dùng đã tắt.
- [x] Test topology/thứ tự và số lần gọi node bằng mock, đủ bốn ablation cũ;
  nhánh mới vào Decision nhận đúng Full reports và prior metadata.

**Nghiệm thu:** node không chạy ngoài thứ tự, prior không mất khỏi state,
đường cũ PASS E2E xác định, API graph mới dùng được từ W4-10.

**Nghiệm thu 06/10/2026:** [biên bản/API](graph_prior_integration.md),
[receipt](graph_prior_integration_review.json): **13 test mới**, **128 ca graph thật**,
Full/upstream một lần cho năm Decision fixture; retrieve/format một lần mỗi nhánh,
verifier trước query và sau result. Max prompt **6.264**, BRPP 600 + reasoning
**6.467**; compileall/**399 unit**/E2E/**56 leakage** PASS.
`invoke`/async/stream kiểm state thô, các channel/report/metadata và deep copy PASS.
Adapter nguồn PIT thật và điều phối engine/checkpoint thuộc W4-09..12.

## Gate B và cập nhật tiến độ

- [x] W4-05..08 PASS state/config, Decision runtime budget và graph compatibility.
- [x] Prefix đúng vị trí/một lần; Original rỗng; tất cả API đi qua retry wrapper.
- [x] Guard thực thi trước LLM, không chỉ kiểm prompt ghép thử bên ngoài runtime.

Ba điều kiện PASS trên node/graph thật bằng verifier/retriever/LLM fixture;
**Gate B PASS_OFFLINE_GRAPH_PROMPT_FIXTURES**, chưa mở gate nguồn W4-09.

Ghi nhật ký từng task: ngày, nhánh/commit, file, lệnh/test, kết quả và giới hạn;
cập nhật [README](README.md). Gate B chưa đồng nghĩa tích hợp backtest/resume đã PASS.
